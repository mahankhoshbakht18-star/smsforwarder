# گزارش نسخه 2.5.0 — اتصال MahanBot

## تغییرات اصلی

- افزودن بخش مستقل «اتصال OTP به MahanBot» در تنظیمات.
- ثبت کد ملی متقاضی فعال.
- ثبت نشانی MahanBot، کلید دستگاه و عبارت شناسایی پیامک.
- درخواست مجوز `RECEIVE_SMS` از خود کاربر.
- نمایش گفت‌وگوی رضایت پیش از فعال‌سازی.
- استخراج OTP چهار تا هشت رقمی روی خود گوشی.
- ارسال فقط کد ملی، OTP، زمان و شناسه‌های ناشناس دستگاه/پیام.
- عدم ارسال متن کامل پیامک و شماره فرستنده.
- نگهداری کلید MahanBot با Android Keystore.
- شناسه پایدار و تصادفی دستگاه.
- کنترل HTTPS برای Release و اجازه HTTP فقط برای Debug روی localhost/LAN خصوصی.
- مهاجرت Room از نسخه 5 به 6.
- خارج‌کردن کد ملی و رضایت MahanBot از فایل Backup.
- خاموش‌شدن فوری انتقال در صورت لغو رضایت.
- تست اتصال و تشخیص وجود کد ملی در MahanBot.

## Build

کد نسخه 2.5.0 و Workflow ساخت GitHub Actions آماده است. در محیط بازبینی، Gradle Wrapper نتوانست فایل Gradle 8.11.1 را دریافت کند، زیرا دسترسی اینترنت و Android SDK موجود نبود؛ بنابراین APK جدید در این محیط تولید نشده است.

Workflow موجود پس از Push اجرا می‌کند:

```text
./gradlew --no-daemon clean :app:testDebugUnitTest :app:assembleDebug
```

Artifact خروجی:

```text
SMSForwardManager-2.5.0-MahanBot-debug.apk
```

## بررسی‌های انجام‌شده

- XML منابع: معتبر.
- Kotlin خالص Endpoint Validator: کامپایل موفق با `kotlinc`.
- کنترل عدم وجود `body` و `sender` در Payload: موفق.
- کنترل وجود رضایت، NID و Device Key: موفق.
- کنترل حذف NID و Consent از Backup: موفق.
- کنترل توازن ساختاری فایل‌های Kotlin اصلاح‌شده: موفق.
