# Archived version-1 build record

> Historical only. It does not verify the current 2.0.1 source. See `BUILD_VERIFICATION_V2.md` and `../BUILD_REPORT.md`.

# Build verification — version 1.0.0

Validated on 2026-07-11 with JDK 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2 and Android SDK 35.

## Successful tasks

```text
:app:clean
:app:compileDebugKotlin
:app:testDebugUnitTest
:app:assembleDebug
```

The clean combined test and APK build completed with `BUILD SUCCESSFUL`. The last completed Android Lint analysis reported 0 errors; the remaining informational warnings concern available dependency updates and optional build-performance migration from kapt to KSP.

## APK

```text
File: app/build/outputs/apk/debug/app-debug.apk
Application ID: ir.smsforwardmanager.debug
Version: 1.0.0-debug (versionCode 10)
minSdk: 29
targetSdk: 35
SHA-256: f9f93e62ea03614c9a04357169ce81d0df264d41696a96cb088af9bc2d4a776a
Signature: APK Signature Scheme v2 verified
```

## Permission audit

The packaged APK requests `RECEIVE_SMS`, `SEND_SMS` and `READ_PHONE_STATE`. WorkManager contributes its normal scheduling permissions such as wake lock, network-state observation and boot rescheduling.

The APK does **not** request `android.permission.INTERNET`; therefore it cannot open Internet sockets through Android's standard permission model.
