# SMS delivery-report correction

The earlier implementation treated a raw value `0` as an error and displayed `SMS_DELIVERY_RESULT_0`. That mixed two different value domains:

- Broadcast `resultCode` for the **sent** callback (`Activity.RESULT_OK` means accepted by the SMS stack).
- TP-Status read from the **delivery-report PDU** (`SmsMessage.STATUS_COMPLETE`, value `0`, means delivered).

Version 2.0.1 uses separate receivers and reads the PDU in the delivery receiver. Every multipart segment has an independent request code and a `(attempt_id, part_index)` database row. Conditional SQL updates make duplicate broadcasts idempotent.

Final parent states include:

- `SENT_WAITING_DELIVERY`
- `DELIVERED`
- `SENT_DELIVERY_UNKNOWN`
- `PARTIALLY_FAILED`
- `FAILED`

If no delivery report arrives within 24 hours, the message remains sent and changes to delivery-unknown; it is not marked as a send failure.
