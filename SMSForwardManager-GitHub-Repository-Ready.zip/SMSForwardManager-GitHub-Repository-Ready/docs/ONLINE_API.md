# Online forwarding API contract

The app posts to the exact owner-configured HTTPS URL. Cleartext HTTP, localhost, loopback/private IPv4 literals, URL user-info and redirects are rejected.

## Request

```http
POST /api/v1/messages/forward HTTP/1.1
Content-Type: application/json; charset=utf-8
Accept: application/json
Authorization: Bearer YOUR_TOKEN
Idempotency-Key: sfm-INCOMING_MESSAGE_ID-ATTEMPT_ID
User-Agent: SMSForwardManager/2.0.1
```

`Authorization` is omitted when no token is configured.

```json
{
  "messageId": "sfm-42-105",
  "sender": "MYGOV",
  "destination": "09123456789",
  "message": "Forwarded content",
  "receivedAt": 1783843200000,
  "deviceName": "Manufacturer Model",
  "ruleId": 7
}
```

## Successful response

Any `2xx` response is accepted. Empty/non-JSON bodies are allowed. Recommended response:

```json
{
  "success": true,
  "referenceId": "msg_01JXYZ"
}
```

If JSON contains `"success": false`, the app treats the request as rejected. Reference aliases also accepted: `reference`, `message_id`, `messageId`, `id`.

## Retry and fallback

- Retryable: network I/O, timeout, HTTP 408, 425, 429 and 5xx.
- Non-retryable: invalid endpoint, missing source row, explicit server rejection, and most 4xx responses.
- Internet-only uses WorkManager retry up to the configured limit.
- Internet→SIM falls back to SMS after an Internet failure.
- SIM→Internet uses the API only when all SMS parts fail.
- The server must persist `Idempotency-Key` results to prevent duplicate processing.

## Server security checklist

- Valid TLS certificate and TLS 1.2+.
- Long random bearer token with rotation/revocation support.
- Destination allowlist and per-device rate limits.
- Idempotency storage with an expiry window.
- Never store tokens or full sensitive message content in access logs.
- Return generic errors; do not expose internal stack traces.
