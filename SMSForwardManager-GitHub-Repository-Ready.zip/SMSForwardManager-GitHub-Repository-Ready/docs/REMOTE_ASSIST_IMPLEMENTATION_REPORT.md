# Remote Assist implementation report

## Delivered source components

- Operator session screen integrated into the existing Kotlin/Compose app.
- Separate `companion` Android application module with visible MediaProjection sharing.
- Pause, resume and stop controls in both Companion UI and its foreground notification.
- Ephemeral WebSocket/JPEG relay and text guidance.
- Node.js session/signaling server with HMAC role tokens, expiry and rate limits.
- Same-origin operator web panel and customer join page.
- Optional Supabase audit schema with RLS and retention function.
- Versioned Persian consent text, architecture and test plan.

## Deliberately excluded

- Accessibility Service or input injection;
- `FLAG_SECURE` bypass;
- screen-overlay control arrows over third-party apps;
- hidden capture or notification suppression;
- Play Protect/store-review evasion;
- raw national-ID logging;
- storage or recording of screen frames;
- banking password, OTP, PIN or credential collection.

## Transport limits

The MVP sends a maximum 720px-wide JPEG every 500ms. This is intended for supervised functional testing, not high-frame-rate video. Production scale should use an audited WebRTC/SFU transport after the functional and compliance model is accepted.
