# Package structure — 2.4.0

- `core/model`: delivery, rule, queue, theme and language enums.
- `core/util`: OTP extraction, phone normalization, rule matching, fingerprinting, SIM discovery and sensitive-content detection/masking.
- `data/local`: Room database, migrations, entities, DAOs and converters.
- `data/repository`: rule/settings/log persistence and masked export.
- `domain/processor`: message matching, routing, limits and queue creation.
- `network`: HTTPS API contract, connectivity and endpoint validation.
- `security`: Android Keystore encrypted API-token storage.
- `sms`: receivers, WorkManager jobs, multipart delivery tracking, foreground status and boot restoration.
- `backup`: versioned non-secret backup and restore.
- `ui/dashboard`, `ui/rules`, `ui/logs`, `ui/settings`, `ui/about`: main customer application UI.
- `ui/remote`: customer request loading, consent and active-share controls.
- `remote/customer`: deep-link data, session API, MediaProjection foreground service and share state.
- `remote-assist-server/public/admin.html`: operator session creation.
- `remote-assist-server/public/operator.html`: operator live viewer and guidance.
- `remote-assist-server`: Node.js HTTPS/WebSocket session and relay service.

Only the `:app` Android module is included and only one APK is built.
