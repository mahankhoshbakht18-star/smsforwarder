# Remote Assist architecture — unified customer app

## Scope

Smart SMS Manager is installed on the customer phone. The same APK handles SMS forwarding and customer-side Remote Assist. The internet-cafe operator uses a browser panel and does not install a separate Android operator app.

Remote Assist provides visible screen sharing and short text guidance. The customer performs all interactions and can pause or stop sharing at any time.

## Components

```mermaid
flowchart LR
    A[Operator browser /admin.html] -->|Create one-time session| B[Remote Assist server]
    B -->|Customer join link| C[Smart SMS Manager APK]
    C -->|Consent + visible MediaProjection frames| B
    B -->|Ephemeral relay| D[Operator browser /operator.html]
    D -->|Text guidance| B
```

1. `app`: customer-side Android APK containing SMS forwarding and Remote Assist.
2. `remote-assist-server/public/admin.html`: operator session-creation panel.
3. `remote-assist-server/public/operator.html`: live browser viewer and text-guidance console.
4. `remote-assist-server`: token issuance, session state, ephemeral WebSocket relay and optional event audit.

## Session sequence

1. The operator opens `/admin.html` and creates a short-lived request using the server admin key.
2. The server returns separate expiring client and operator tokens.
3. The customer receives only the customer join URL.
4. `join.html` opens `smsforwardremote://join?server=...&token=...`.
5. Android routes the link to `MainActivity`, which navigates to Remote Assist and loads the immutable request.
6. The customer checks all consent items and approves the request.
7. Android displays its own MediaProjection confirmation.
8. `ScreenShareService` starts as a visible foreground service and opens the client WebSocket.
9. Frames are encoded only while an operator socket is connected and sharing is not paused.
10. The operator views frames in `/operator.html` and may send bounded text guidance.
11. Customer stop, operator end, projection revocation, expiry or task removal terminates sharing.

## Android module layout

```text
app/
├── sms/                         SMS receive/forward services and workers
├── ui/remote/                   Customer join, request review and consent UI
└── remote/customer/
    ├── RemoteJoinInput.kt
    ├── RemoteSessionApi.kt
    ├── ScreenShareService.kt
    └── ShareSessionState.kt
```

The removed `companion` Gradle module is no longer part of `settings.gradle.kts`.

## Permissions

The single app declares the existing telephony permissions required for its SMS-forwarding purpose plus:

- `INTERNET` and `ACCESS_NETWORK_STATE`;
- `POST_NOTIFICATIONS`;
- `FOREGROUND_SERVICE_MEDIA_PROJECTION`.

The app does not declare an Accessibility service or overlay permission for Remote Assist.

## Transport

The current MVP uses bounded JPEG frames over WebSocket. Frames are relayed in memory and are not stored by the supplied server. The transport is isolated inside `ScreenShareService.RemoteSocket`, so a future WebRTC transport can replace it without changing consent and foreground-service rules.
