# Verification status — 2.0.1

Static resource and Kotlin-structure checks passed, as documented in `../BUILD_REPORT.md`. A full Gradle compile, Room schema export/migration instrumentation test and APK installation could not be performed in the current offline environment because neither the Android SDK nor Gradle 8.11.1 is cached.

Required release commands:

```bash
./gradlew --no-daemon clean testDebugUnitTest assembleDebug --stacktrace
```

Then install `app/build/outputs/apk/debug/app-debug.apk` on Android 11+ and validate SIM 1, SIM 2, multipart callbacks, delivery unknown timeout, Internet-only, both fallback orders, reboot and denied permissions.
