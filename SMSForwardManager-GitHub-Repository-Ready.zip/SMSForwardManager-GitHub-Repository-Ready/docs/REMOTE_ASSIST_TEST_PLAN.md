# Remote Assist test plan — 2.3.0 unified APK

## Build verification

```bash
./build_all.sh
```

Expected artifact:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Customer-phone checks

1. Install the APK on Android 10, 13 and 14/15 test devices.
2. Grant SMS, phone and notification permissions through the normal app flow.
3. Confirm incoming-message matching and forwarding still operate.
4. Open a generated customer URL and verify Smart SMS Manager opens directly on Remote Assist.
5. Verify requester, purpose, code and expiry are shown before consent.
6. Cancel Android MediaProjection and confirm no foreground capture service starts.
7. Approve capture and confirm a persistent notification appears immediately.
8. Verify pause/resume/stop from both the app and notification.
9. Verify the UI distinguishes relay connection from operator connection.
10. Rotate the device and confirm server/token/session state is retained by the ViewModel.
11. Confirm protected target screens appear according to Android platform protection.

## Operator-browser checks

1. Open `/admin.html` over HTTPS.
2. Verify an invalid admin key cannot create a session.
3. Create a valid session and copy/share the customer link.
4. Open the private operator link in a separate browser tab.
5. Confirm frames arrive only after customer consent and capture confirmation.
6. Send a short instruction and verify it appears in the customer app and notification.
7. End the session and confirm both sockets close.

## Regression checks

- `settings.gradle.kts` contains only `include(":app")`.
- No `companion` output path is referenced by build scripts or CI.
- No Android admin key, operator token store or native operator viewer remains in the app source.
- Persian and English string resources contain the same key set.
- Node syntax checks include `public/admin.js`.
