# Editing and building on an Android phone

## AndroidIDE

1. Extract the project ZIP to internal storage.
2. Open the folder containing `settings.gradle.kts` in AndroidIDE.
3. Keep Internet access available for the first Gradle/dependency download.
4. Use JDK 17 for the project when AndroidIDE asks.
5. Sync Gradle, then run `assembleDebug` or the **Build APK** action.
6. The APK should appear under `app/build/outputs/apk/debug/`.

Recommended free space: at least 8 GB. Disable battery optimization for AndroidIDE during a long build. Do not edit the project directly inside the ZIP.

Useful companions: Termux for Git/sha256, Acode for quick text edits, and a private Git repository for version history.

Before installing over an existing release build, confirm that the application ID and signing key match. The debug build uses the `.debug` suffix and normally installs as a separate app.
