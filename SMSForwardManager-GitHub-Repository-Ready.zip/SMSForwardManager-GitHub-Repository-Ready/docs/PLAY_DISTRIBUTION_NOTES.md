# Google Play distribution notes

There is no legitimate technical method to guarantee approval or to make sensitive behavior "undetectable". The release strategy is transparent behavior, minimal permissions and accurate declarations.

## Separate listings

- **Remote Assist Companion** has no SMS, Accessibility, overlay, camera, microphone, contacts or storage permission. Its MediaProjection foreground notification is always visible.
- **Smart SMS Manager** still declares `RECEIVE_SMS` and `SEND_SMS` for its original core feature. Google Play applies a separate restricted SMS/Call Log policy to these permissions. Remote Assist does not create an exemption.

Do not merge the customer-facing Companion into the SMS APK. A customer should never have to install unrelated SMS permissions to join a support session.

## Required release work

- Publish a clear privacy policy and complete the Data Safety form from actual server behavior.
- Show the in-app prominent disclosure before requesting MediaProjection/notification access.
- Keep the foreground notification, launcher icon and stop control visible.
- Declare every SDK and every collected/processed field accurately.
- Do not describe this feature as bank-controlled or bank-approved without a written integration agreement.
- Do not collect passwords, OTPs, PINs, dynamic codes or protected screen content.
- Use only production HTTPS and a verified Android App Link.
- Provide reviewer instructions and a non-sensitive demo account/session.
- Review whether the original SMS app qualifies for Play's restricted SMS permission policy or requires redesign/distribution through an appropriate managed channel.

Official references:

- Android user-data disclosure and consent: <https://support.google.com/googleplay/android-developer/answer/10144311>
- SMS and Call Log permission policy: <https://support.google.com/googleplay/android-developer/answer/10208820>
- Android MediaProjection foreground-service behavior: <https://developer.android.com/media/grow/media-projection>

Store compliance and banking/provider permission are release gates, not features that code can bypass.
