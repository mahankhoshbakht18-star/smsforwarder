import crypto from 'node:crypto';

const ROLES = new Set(['client', 'operator']);

function encodedJson(value) {
  return Buffer.from(JSON.stringify(value), 'utf8').toString('base64url');
}

export function safeEqual(left, right) {
  const leftBuffer = Buffer.from(String(left ?? ''), 'utf8');
  const rightBuffer = Buffer.from(String(right ?? ''), 'utf8');
  if (leftBuffer.length !== rightBuffer.length) return false;
  return crypto.timingSafeEqual(leftBuffer, rightBuffer);
}

export function createAccessToken({ sessionId, role, ttlSeconds }, secret, nowMs = Date.now()) {
  if (!ROLES.has(role)) throw new Error('invalid token role');
  const issuedAt = Math.floor(nowMs / 1000);
  const payload = {
    v: 1,
    sid: sessionId,
    role,
    iat: issuedAt,
    exp: issuedAt + ttlSeconds,
    jti: crypto.randomBytes(16).toString('base64url'),
  };
  const encoded = encodedJson(payload);
  const signature = crypto.createHmac('sha256', secret).update(encoded).digest('base64url');
  return `${encoded}.${signature}`;
}

export function verifyAccessToken(token, secret, nowMs = Date.now()) {
  const [encoded, providedSignature, extra] = String(token ?? '').split('.');
  if (!encoded || !providedSignature || extra) throw new Error('invalid token');
  const expectedSignature = crypto.createHmac('sha256', secret).update(encoded).digest('base64url');
  if (!safeEqual(providedSignature, expectedSignature)) throw new Error('invalid token');

  let payload;
  try {
    payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
  } catch {
    throw new Error('invalid token');
  }
  const nowSeconds = Math.floor(nowMs / 1000);
  if (
    payload?.v !== 1 ||
    typeof payload.sid !== 'string' ||
    !ROLES.has(payload.role) ||
    !Number.isInteger(payload.iat) ||
    payload.iat > nowSeconds + 60 ||
    !Number.isInteger(payload.exp) ||
    payload.exp <= nowSeconds ||
    payload.exp <= payload.iat ||
    typeof payload.jti !== 'string' ||
    payload.jti.length < 16
  ) {
    throw new Error('expired or invalid token');
  }
  return payload;
}

export function hashSubjectReference(reference, secret) {
  const normalized = String(reference ?? '').trim().replace(/\s+/g, '').toLowerCase();
  if (!normalized) return null;
  return crypto.createHmac('sha256', secret).update(normalized).digest('hex');
}

export function sha256Text(value) {
  return crypto.createHash('sha256').update(String(value), 'utf8').digest('hex');
}

export function randomSessionCode() {
  return crypto.randomInt(100000, 1000000).toString();
}
