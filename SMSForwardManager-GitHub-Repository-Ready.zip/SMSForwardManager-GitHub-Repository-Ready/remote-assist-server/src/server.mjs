import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocket, WebSocketServer } from 'ws';
import {
  createAccessToken,
  hashSubjectReference,
  randomSessionCode,
  safeEqual,
  sha256Text,
  verifyAccessToken,
} from './security.mjs';
import { SessionStore } from './store.mjs';

export const CONSENT_VERSION = 'fa-IR-v1';
export const CONSENT_NOTICE_FA = [
  'من درخواست‌کننده، هدف و مدت نگهداری این جلسه را مشاهده کردم.',
  'می‌دانم اشتراک صفحه فقط با تأیید رسمی اندروید و اعلان دائمی فعال می‌شود.',
  'می‌توانم هر زمان اشتراک را مکث یا متوقف کنم.',
  'رمز، رمز پویا، OTP، PIN و اطلاعات محرمانه بانکی را با متصدی به اشتراک نمی‌گذارم.',
  'صفحه‌های محافظت‌شده توسط برنامه مقصد ضبط یا دور زده نمی‌شوند.',
].join(' ');

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDirectory = path.resolve(__dirname, '../public');

function requiredSecret(name) {
  const value = String(process.env[name] ?? '');
  if (value.length < 32) throw new Error(`${name} must contain at least 32 characters`);
  return value;
}

function integerEnv(name, fallback, min, max) {
  const parsed = Number.parseInt(process.env[name] ?? '', 10);
  const value = Number.isFinite(parsed) ? parsed : fallback;
  return Math.min(max, Math.max(min, value));
}

const config = {
  port: integerEnv('PORT', 8080, 1, 65535),
  publicBaseUrl: String(process.env.PUBLIC_BASE_URL ?? 'http://127.0.0.1:8080').replace(/\/$/, ''),
  adminApiKey: requiredSecret('ADMIN_API_KEY'),
  tokenSecret: requiredSecret('TOKEN_SECRET'),
  subjectHashSecret: requiredSecret('SUBJECT_HASH_SECRET'),
  sessionTtlMinutes: integerEnv('SESSION_TTL_MINUTES', 15, 5, 60),
  maxSessionTtlMinutes: integerEnv('MAX_SESSION_TTL_MINUTES', 60, 5, 180),
  allowedOrigins: new Set(
    String(process.env.ALLOWED_OPERATOR_ORIGINS ?? '')
      .split(',')
      .map((value) => value.trim())
      .filter(Boolean),
  ),
};

if (process.env.NODE_ENV === 'production' && !config.publicBaseUrl.startsWith('https://')) {
  throw new Error('PUBLIC_BASE_URL must use HTTPS in production');
}

const store = new SessionStore({
  supabaseUrl: process.env.SUPABASE_URL,
  supabaseServiceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY,
});
const sockets = new Map();
const sessionCreationWindows = new Map();

function requestIp(request) {
  const forwarded = String(request.headers['x-forwarded-for'] ?? '').split(',')[0].trim();
  return forwarded || request.socket.remoteAddress || 'unknown';
}

function allowSessionCreation(request, nowMs = Date.now()) {
  const ip = requestIp(request);
  const current = sessionCreationWindows.get(ip);
  if (!current || nowMs - current.startedAt >= 60_000) {
    sessionCreationWindows.set(ip, { startedAt: nowMs, count: 1 });
    return true;
  }
  current.count += 1;
  return current.count <= 20;
}

function securityHeaders(response, contentType = 'application/json; charset=utf-8') {
  response.setHeader('Content-Type', contentType);
  response.setHeader('Cache-Control', 'no-store');
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('Referrer-Policy', 'no-referrer');
  response.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  response.setHeader('X-Frame-Options', 'DENY');
  if (process.env.NODE_ENV === 'production') {
    response.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  response.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; img-src 'self' blob:; style-src 'self'; script-src 'self'; connect-src 'self' wss: ws:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  );
}

function json(response, status, body) {
  securityHeaders(response);
  response.writeHead(status);
  response.end(JSON.stringify(body));
}

async function readJson(request, maxBytes = 16 * 1024) {
  let size = 0;
  const chunks = [];
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maxBytes) throw new Error('request body too large');
    chunks.push(chunk);
  }
  if (chunks.length === 0) return {};
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function bearerToken(request) {
  const value = String(request.headers.authorization ?? '');
  return value.startsWith('Bearer ') ? value.slice(7).trim() : '';
}

function cleanText(value, maxLength, fieldName) {
  const cleaned = String(value ?? '').trim().replace(/[\u0000-\u001f\u007f]/g, ' ');
  if (!cleaned || cleaned.length > maxLength) throw new Error(`invalid ${fieldName}`);
  return cleaned;
}

function publicSession(session) {
  return {
    id: session.id,
    code: session.code,
    requesterName: session.requesterName,
    purpose: session.purpose,
    status: session.status,
    consentVersion: session.consentVersion,
    consentNotice: CONSENT_NOTICE_FA,
    createdAt: session.createdAt,
    expiresAt: session.expiresAt,
    retentionUntil: session.retentionUntil,
    consentedAt: session.consentedAt,
    startedAt: session.startedAt,
    endedAt: session.endedAt,
  };
}

function authorizedSession(request, expectedRole = null) {
  const payload = verifyAccessToken(bearerToken(request), config.tokenSecret);
  if (expectedRole && payload.role !== expectedRole) throw new Error('forbidden');
  const session = store.get(payload.sid);
  if (!session) throw new Error('session not found');
  if (Date.parse(session.expiresAt) <= Date.now() && session.status !== 'ended') {
    void store.update(session.id, { status: 'expired', endedAt: new Date().toISOString() });
    throw new Error('session expired');
  }
  return { payload, session };
}

function sessionSockets(sessionId) {
  if (!sockets.has(sessionId)) {
    sockets.set(sessionId, { client: null, operator: null, shareState: 'stopped' });
  }
  return sockets.get(sessionId);
}

async function serveStatic(response, fileName, contentType) {
  try {
    const content = await fs.readFile(path.join(publicDirectory, fileName));
    securityHeaders(response, contentType);
    response.writeHead(200);
    response.end(content);
  } catch {
    json(response, 404, { error: 'not found' });
  }
}

async function handleRequest(request, response) {
  const url = new URL(request.url, config.publicBaseUrl);
  try {
    if (request.method === 'GET' && url.pathname === '/health') {
      return json(response, 200, { status: 'ok', time: new Date().toISOString() });
    }
    if (request.method === 'GET' && url.pathname === '/') {
      return serveStatic(response, 'index.html', 'text/html; charset=utf-8');
    }
    if (request.method === 'GET' && url.pathname === '/admin.html') {
      return serveStatic(response, 'admin.html', 'text/html; charset=utf-8');
    }
    if (request.method === 'GET' && url.pathname === '/admin.js') {
      return serveStatic(response, 'admin.js', 'text/javascript; charset=utf-8');
    }
    if (request.method === 'GET' && url.pathname === '/operator.html') {
      return serveStatic(response, 'operator.html', 'text/html; charset=utf-8');
    }
    if (request.method === 'GET' && url.pathname === '/operator.js') {
      return serveStatic(response, 'operator.js', 'text/javascript; charset=utf-8');
    }
    if (request.method === 'GET' && url.pathname === '/join.html') {
      return serveStatic(response, 'join.html', 'text/html; charset=utf-8');
    }
    if (request.method === 'GET' && url.pathname === '/join.js') {
      return serveStatic(response, 'join.js', 'text/javascript; charset=utf-8');
    }
    if (request.method === 'GET' && url.pathname === '/styles.css') {
      return serveStatic(response, 'styles.css', 'text/css; charset=utf-8');
    }

    if (request.method === 'POST' && url.pathname === '/api/sessions') {
      if (!allowSessionCreation(request)) {
        return json(response, 429, { error: 'rate limit exceeded' });
      }
      if (!safeEqual(request.headers['x-admin-key'], config.adminApiKey)) {
        return json(response, 401, { error: 'unauthorized' });
      }
      const body = await readJson(request);
      const requesterName = cleanText(body.requesterName, 80, 'requesterName');
      const purpose = cleanText(body.purpose, 300, 'purpose');
      const requestedTtl = Number.parseInt(body.ttlMinutes, 10);
      const ttlMinutes = Number.isFinite(requestedTtl)
        ? Math.min(config.maxSessionTtlMinutes, Math.max(5, requestedTtl))
        : config.sessionTtlMinutes;
      const retentionMinutes = Math.min(
        24 * 60,
        Math.max(ttlMinutes, Number.parseInt(body.retentionMinutes, 10) || 60),
      );
      const now = Date.now();
      let code = randomSessionCode();
      while ([...store.sessions.values()].some((session) => session.code === code)) {
        code = randomSessionCode();
      }
      const session = {
        id: crypto.randomUUID(),
        code,
        requesterName,
        purpose,
        subjectReferenceHash: hashSubjectReference(body.subjectReference, config.subjectHashSecret),
        status: 'created',
        consentVersion: CONSENT_VERSION,
        consentNoticeHash: sha256Text(CONSENT_NOTICE_FA),
        createdAt: new Date(now).toISOString(),
        expiresAt: new Date(now + ttlMinutes * 60_000).toISOString(),
        retentionUntil: new Date(now + retentionMinutes * 60_000).toISOString(),
        consentedAt: null,
        startedAt: null,
        endedAt: null,
        lastEventAt: new Date(now).toISOString(),
      };
      await store.create(session);
      await store.addEvent(session.id, 'operator', 'session_created');
      const ttlSeconds = ttlMinutes * 60;
      const clientToken = createAccessToken({ sessionId: session.id, role: 'client', ttlSeconds }, config.tokenSecret);
      const operatorToken = createAccessToken({ sessionId: session.id, role: 'operator', ttlSeconds }, config.tokenSecret);
      return json(response, 201, {
        session: publicSession(session),
        clientToken,
        operatorToken,
        clientJoinUrl: `${config.publicBaseUrl}/join.html#server=${encodeURIComponent(config.publicBaseUrl)}&token=${encodeURIComponent(clientToken)}`,
        operatorUrl: `${config.publicBaseUrl}/operator.html#token=${encodeURIComponent(operatorToken)}`,
      });
    }

    if (request.method === 'GET' && url.pathname === '/api/session') {
      const { session } = authorizedSession(request);
      return json(response, 200, { session: publicSession(session) });
    }

    if (request.method === 'POST' && url.pathname === '/api/consent') {
      const { session } = authorizedSession(request, 'client');
      const body = await readJson(request);
      if (body.accepted !== true || body.consentVersion !== CONSENT_VERSION) {
        return json(response, 400, { error: 'explicit current-version consent is required' });
      }
      if (['ended', 'expired', 'revoked'].includes(session.status)) {
        return json(response, 409, { error: 'session is not active' });
      }
      const consentedAt = new Date().toISOString();
      const updated = await store.update(session.id, { status: 'consented', consentedAt });
      await store.addEvent(session.id, 'client', 'consent_accepted', { state: CONSENT_VERSION });
      return json(response, 200, { session: publicSession(updated) });
    }

    if (request.method === 'POST' && url.pathname === '/api/events') {
      const { payload, session } = authorizedSession(request);
      const body = await readJson(request);
      const allowedEvents = new Set(['share_started', 'share_paused', 'share_resumed', 'share_stopped']);
      if (!allowedEvents.has(body.eventType)) return json(response, 400, { error: 'invalid event' });
      if (payload.role !== 'client') return json(response, 403, { error: 'client role required' });
      if (body.eventType === 'share_started' && !session.consentedAt) {
        return json(response, 409, { error: 'consent required' });
      }
      await store.addEvent(session.id, payload.role, body.eventType, body.metadata);
      const patch = {};
      if (body.eventType === 'share_started') {
        patch.status = 'active';
        patch.startedAt = session.startedAt ?? new Date().toISOString();
      }
      if (body.eventType === 'share_stopped') {
        patch.status = 'ended';
        patch.endedAt = new Date().toISOString();
      }
      const updated = Object.keys(patch).length > 0 ? await store.update(session.id, patch) : session;
      return json(response, 200, { session: publicSession(updated) });
    }

    const endMatch = url.pathname.match(/^\/api\/sessions\/([0-9a-f-]+)\/end$/i);
    if (request.method === 'POST' && endMatch) {
      const { payload, session } = authorizedSession(request, 'operator');
      if (payload.sid !== endMatch[1] || session.id !== endMatch[1]) {
        return json(response, 403, { error: 'forbidden' });
      }
      const endedAt = new Date().toISOString();
      const updated = await store.update(session.id, { status: 'ended', endedAt });
      await store.addEvent(session.id, 'operator', 'session_ended');
      const peers = sessionSockets(session.id);
      peers.client?.close(1000, 'session ended');
      peers.operator?.close(1000, 'session ended');
      sockets.delete(session.id);
      return json(response, 200, { session: publicSession(updated) });
    }

    return json(response, 404, { error: 'not found' });
  } catch (error) {
    const message = String(error?.message ?? 'request failed');
    const status = /unauthorized|token|forbidden/.test(message) ? 401
      : /not found/.test(message) ? 404
        : /expired|not active/.test(message) ? 409
          : 400;
    return json(response, status, { error: message });
  }
}

const server = http.createServer((request, response) => {
  void handleRequest(request, response);
});
const webSocketServer = new WebSocketServer({ noServer: true, maxPayload: 1_200_000 });

function originAllowed(origin) {
  if (!origin) return true;
  if (config.allowedOrigins.size > 0) return config.allowedOrigins.has(origin);
  try {
    return new URL(origin).origin === new URL(config.publicBaseUrl).origin;
  } catch {
    return false;
  }
}

server.on('upgrade', (request, socket, head) => {
  const url = new URL(request.url, config.publicBaseUrl);
  if (url.pathname !== '/ws' || !originAllowed(request.headers.origin)) {
    socket.destroy();
    return;
  }
  webSocketServer.handleUpgrade(request, socket, head, (webSocket) => {
    webSocketServer.emit('connection', webSocket, request);
  });
});

webSocketServer.on('connection', (webSocket) => {
  let auth = null;
  let frameWindowStartedAt = Date.now();
  let framesInWindow = 0;
  let instructionWindowStartedAt = Date.now();
  let instructionsInWindow = 0;
  const authenticationTimeout = setTimeout(() => webSocket.close(1008, 'authentication required'), 5_000);

  webSocket.on('message', async (data, isBinary) => {
    try {
      if (!auth) {
        if (isBinary) throw new Error('authentication required');
        const message = JSON.parse(data.toString('utf8'));
        if (message.type !== 'authenticate') throw new Error('authentication required');
        const payload = verifyAccessToken(message.token, config.tokenSecret);
        const session = store.get(payload.sid);
        if (!session || Date.parse(session.expiresAt) <= Date.now()) throw new Error('session expired');
        if (payload.role === 'client' && !session.consentedAt) throw new Error('consent required');
        if (['ended', 'expired', 'revoked'].includes(session.status)) throw new Error('session ended');
        auth = payload;
        clearTimeout(authenticationTimeout);
        const peers = sessionSockets(payload.sid);
        peers[payload.role]?.close(1000, 'replaced by a new connection');
        peers[payload.role] = webSocket;
        webSocket.send(JSON.stringify({ type: 'authenticated', role: payload.role, session: publicSession(session) }));
        const otherRole = payload.role === 'client' ? 'operator' : 'client';
        const otherSocket = peers[otherRole];
        webSocket.send(JSON.stringify({
          type: 'peerState',
          role: otherRole,
          state: otherSocket?.readyState === WebSocket.OPEN ? 'connected' : 'disconnected',
        }));
        if (payload.role === 'operator') {
          webSocket.send(JSON.stringify({ type: 'shareState', state: peers.shareState }));
        }
        otherSocket?.send(JSON.stringify({ type: 'peerState', role: payload.role, state: 'connected' }));
        await store.addEvent(payload.sid, payload.role, 'socket_connected');
        return;
      }

      const session = store.get(auth.sid);
      if (!session || ['ended', 'expired', 'revoked'].includes(session.status)) {
        throw new Error('session ended');
      }
      const peers = sessionSockets(auth.sid);

      if (isBinary) {
        if (auth.role !== 'client' || !session.consentedAt) throw new Error('binary frames not allowed');
        const now = Date.now();
        if (now - frameWindowStartedAt >= 1_000) {
          frameWindowStartedAt = now;
          framesInWindow = 0;
        }
        framesInWindow += 1;
        if (framesInWindow > 4) return;
        if (peers.operator?.readyState === WebSocket.OPEN) peers.operator.send(data, { binary: true });
        return;
      }

      const message = JSON.parse(data.toString('utf8'));
      if (auth.role === 'operator' && message.type === 'instruction') {
        const now = Date.now();
        if (now - instructionWindowStartedAt >= 10_000) {
          instructionWindowStartedAt = now;
          instructionsInWindow = 0;
        }
        instructionsInWindow += 1;
        if (instructionsInWindow > 10) throw new Error('instruction rate limit exceeded');
        const text = cleanText(message.text, 200, 'instruction');
        if (peers.client?.readyState === WebSocket.OPEN) {
          peers.client.send(JSON.stringify({ type: 'instruction', text, at: new Date().toISOString() }));
        }
        await store.addEvent(auth.sid, 'operator', 'instruction_sent');
        return;
      }
      if (auth.role === 'client' && message.type === 'shareState') {
        const allowedStates = new Set(['active', 'paused', 'stopped']);
        if (!allowedStates.has(message.state)) throw new Error('invalid share state');
        peers.shareState = message.state;
        if (peers.operator?.readyState === WebSocket.OPEN) {
          peers.operator.send(JSON.stringify({ type: 'shareState', state: message.state }));
        }
        return;
      }
      throw new Error('unsupported message');
    } catch (error) {
      webSocket.send(JSON.stringify({ type: 'error', message: String(error?.message ?? 'socket error') }));
      if (!auth) webSocket.close(1008, 'authentication failed');
    }
  });

  webSocket.on('close', () => {
    clearTimeout(authenticationTimeout);
    if (!auth) return;
    const peers = sockets.get(auth.sid);
    if (peers) {
      if (peers[auth.role] === webSocket) peers[auth.role] = null;
      const otherRole = auth.role === 'client' ? 'operator' : 'client';
      peers[otherRole]?.send(JSON.stringify({ type: 'peerState', role: auth.role, state: 'disconnected' }));
      if (!peers.client && !peers.operator) sockets.delete(auth.sid);
    }
    void store.addEvent(auth.sid, auth.role, 'socket_disconnected');
  });
});

setInterval(() => {
  const removed = store.purgeExpired();
  for (const sessionId of removed) {
    const peers = sockets.get(sessionId);
    peers?.client?.close(1000, 'session data expired');
    peers?.operator?.close(1000, 'session data expired');
    sockets.delete(sessionId);
  }
  const cutoff = Date.now() - 5 * 60_000;
  for (const [ip, window] of sessionCreationWindows.entries()) {
    if (window.startedAt < cutoff) sessionCreationWindows.delete(ip);
  }
}, 60_000).unref();
server.listen(config.port, () => {
  console.log(JSON.stringify({ event: 'server_started', port: config.port }));
});

export { server };
