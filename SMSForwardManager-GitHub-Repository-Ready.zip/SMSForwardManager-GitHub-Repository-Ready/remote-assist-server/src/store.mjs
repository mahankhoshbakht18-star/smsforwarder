import { createClient } from '@supabase/supabase-js';

function safeMetadata(metadata) {
  if (!metadata || typeof metadata !== 'object' || Array.isArray(metadata)) return {};
  const allowed = ['state', 'reason', 'network', 'frameWidth', 'frameHeight'];
  return Object.fromEntries(
    allowed
      .filter((key) => key in metadata)
      .map((key) => [key, String(metadata[key]).slice(0, 120)]),
  );
}

export class SessionStore {
  constructor({ supabaseUrl, supabaseServiceRoleKey } = {}) {
    this.sessions = new Map();
    this.supabase = supabaseUrl && supabaseServiceRoleKey
      ? createClient(supabaseUrl, supabaseServiceRoleKey, {
          auth: { persistSession: false, autoRefreshToken: false },
        })
      : null;
  }

  async create(session) {
    this.sessions.set(session.id, structuredClone(session));
    if (this.supabase) {
      const { error } = await this.supabase.from('remote_assist_sessions').insert({
        id: session.id,
        session_code: session.code,
        requester_name: session.requesterName,
        purpose: session.purpose,
        subject_reference_hash: session.subjectReferenceHash,
        status: session.status,
        consent_version: session.consentVersion,
        consent_notice_hash: session.consentNoticeHash,
        created_at: session.createdAt,
        expires_at: session.expiresAt,
        retention_until: session.retentionUntil,
      });
      if (error) throw new Error(`session persistence failed: ${error.code ?? 'unknown'}`);
    }
    return structuredClone(session);
  }

  get(sessionId) {
    const session = this.sessions.get(sessionId);
    return session ? structuredClone(session) : null;
  }

  async update(sessionId, patch) {
    const current = this.sessions.get(sessionId);
    if (!current) return null;
    const updated = { ...current, ...patch, lastEventAt: new Date().toISOString() };
    this.sessions.set(sessionId, updated);
    if (this.supabase) {
      const dbPatch = {
        status: updated.status,
        consented_at: updated.consentedAt,
        started_at: updated.startedAt,
        ended_at: updated.endedAt,
        last_event_at: updated.lastEventAt,
      };
      const { error } = await this.supabase
        .from('remote_assist_sessions')
        .update(dbPatch)
        .eq('id', sessionId);
      if (error) throw new Error(`session update failed: ${error.code ?? 'unknown'}`);
    }
    return structuredClone(updated);
  }

  async addEvent(sessionId, actor, eventType, metadata = {}) {
    const event = {
      session_id: sessionId,
      actor,
      event_type: eventType,
      metadata: safeMetadata(metadata),
      created_at: new Date().toISOString(),
    };
    if (this.supabase) {
      const { error } = await this.supabase.from('remote_assist_events').insert(event);
      if (error) throw new Error(`event persistence failed: ${error.code ?? 'unknown'}`);
    }
    return event;
  }

  purgeExpired(nowMs = Date.now()) {
    const removedSessionIds = [];
    for (const [id, session] of this.sessions.entries()) {
      const retentionUntil = Date.parse(session.retentionUntil);
      if (Number.isFinite(retentionUntil) && retentionUntil <= nowMs) {
        this.sessions.delete(id);
        removedSessionIds.push(id);
      }
    }
    return removedSessionIds;
  }
}
