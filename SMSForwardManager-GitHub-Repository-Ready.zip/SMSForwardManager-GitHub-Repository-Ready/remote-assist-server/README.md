# Remote Assist Server 1.2

Browser-operated session creation and viewing for the unified customer-side Smart SMS Manager APK.

## Pages

- `/admin.html` — operator enters the server admin key and creates a one-time session.
- `/join.html` — customer landing page that opens the Android deep link.
- `/operator.html` — private live viewer and text-guidance console.

## Local development

```bash
cp .env.example .env
npm install
npm run check
npm test
npm start
```

Use three unrelated random secrets of at least 32 characters. Release Android builds require an HTTPS public base URL.

## API flow

1. `/admin.html` sends `POST /api/sessions` with `X-Admin-Key`.
2. The operator sends only `clientJoinUrl` to the customer.
3. The customer link opens Smart SMS Manager, which retrieves the request and records explicit consent.
4. Android MediaProjection starts only after Android system confirmation and a visible foreground notification.
5. The operator opens `operatorUrl` and receives ephemeral frames through WebSocket.
6. Guidance is text-only and either side can end the session.

The admin key is not included in the Android APK. The browser page does not persist it to localStorage or sessionStorage.
