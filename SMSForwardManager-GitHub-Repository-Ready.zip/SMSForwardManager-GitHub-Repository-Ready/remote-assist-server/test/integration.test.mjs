import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { WebSocket } from 'ws';

const ADMIN_KEY = 'integration-admin-key-with-32-plus-characters';

function waitForMessage(socket, predicate) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      cleanup();
      reject(new Error('websocket message timeout'));
    }, 5_000);
    const onMessage = (data, isBinary) => {
      if (!predicate(data, isBinary)) return;
      cleanup();
      resolve({ data, isBinary });
    };
    const onError = (error) => {
      cleanup();
      reject(error);
    };
    const cleanup = () => {
      clearTimeout(timeout);
      socket.off('message', onMessage);
      socket.off('error', onError);
    };
    socket.on('message', onMessage);
    socket.on('error', onError);
  });
}

async function openAndAuthenticate(url, token) {
  const socket = new WebSocket(url);
  await once(socket, 'open');
  const authenticated = waitForMessage(socket, (data, isBinary) => {
    if (isBinary) return false;
    return JSON.parse(data.toString()).type === 'authenticated';
  });
  socket.send(JSON.stringify({ type: 'authenticate', token }));
  await authenticated;
  return socket;
}

test('consented client frames and operator instructions relay without persistence', async (context) => {
  const port = 21000 + Math.floor(Math.random() * 1000);
  const baseUrl = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ['src/server.mjs'], {
    cwd: new URL('..', import.meta.url),
    env: {
      ...process.env,
      PORT: String(port),
      PUBLIC_BASE_URL: baseUrl,
      ADMIN_API_KEY: ADMIN_KEY,
      TOKEN_SECRET: 'integration-token-secret-with-32-plus-characters',
      SUBJECT_HASH_SECRET: 'integration-subject-secret-with-32-characters',
      SUPABASE_URL: '',
      SUPABASE_SERVICE_ROLE_KEY: '',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  context.after(() => child.kill('SIGTERM'));
  await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('server start timeout')), 5_000);
    child.stdout.on('data', (chunk) => {
      if (!chunk.toString().includes('server_started')) return;
      clearTimeout(timeout);
      resolve();
    });
    child.once('exit', (code) => reject(new Error(`server exited early: ${code}`)));
  });

  const createdResponse = await fetch(`${baseUrl}/api/sessions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Admin-Key': ADMIN_KEY },
    body: JSON.stringify({ requesterName: 'Integration Cafe', purpose: 'Non-sensitive integration test' }),
  });
  assert.equal(createdResponse.status, 201);
  const created = await createdResponse.json();
  const consentResponse = await fetch(`${baseUrl}/api/consent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${created.clientToken}` },
    body: JSON.stringify({ accepted: true, consentVersion: 'fa-IR-v1' }),
  });
  assert.equal(consentResponse.status, 200);

  const wsUrl = `ws://127.0.0.1:${port}/ws`;
  const operator = await openAndAuthenticate(wsUrl, created.operatorToken);
  const client = await openAndAuthenticate(wsUrl, created.clientToken);
  context.after(() => operator.close());
  context.after(() => client.close());

  const expectedFrame = Buffer.from('synthetic-non-image-test-frame');
  const framePromise = waitForMessage(operator, (data, isBinary) => {
    return isBinary && Buffer.compare(Buffer.from(data), expectedFrame) === 0;
  });
  client.send(expectedFrame);
  const receivedFrame = await framePromise;
  assert.equal(receivedFrame.isBinary, true);

  const instructionPromise = waitForMessage(client, (data, isBinary) => {
    if (isBinary) return false;
    const message = JSON.parse(data.toString());
    return message.type === 'instruction' && message.text === 'Tap the visible continue button yourself.';
  });
  operator.send(JSON.stringify({
    type: 'instruction',
    text: 'Tap the visible continue button yourself.',
  }));
  await instructionPromise;
});
