import test from 'node:test';
import assert from 'node:assert/strict';
import { createAccessToken, hashSubjectReference, verifyAccessToken } from '../src/security.mjs';

const secret = 'a-strong-test-secret-with-more-than-32-characters';

test('access token validates and preserves the bounded claims', () => {
  const now = Date.parse('2026-07-16T10:00:00Z');
  const token = createAccessToken({ sessionId: 'session-1', role: 'client', ttlSeconds: 60 }, secret, now);
  const payload = verifyAccessToken(token, secret, now + 30_000);
  assert.equal(payload.sid, 'session-1');
  assert.equal(payload.role, 'client');
});

test('expired and modified access tokens are rejected', () => {
  const now = Date.parse('2026-07-16T10:00:00Z');
  const token = createAccessToken({ sessionId: 'session-1', role: 'operator', ttlSeconds: 1 }, secret, now);
  assert.throws(() => verifyAccessToken(token, secret, now + 2_000));
  assert.throws(() => verifyAccessToken(`${token}x`, secret, now));
});

test('subject reference is normalized and irreversibly keyed', () => {
  assert.equal(hashSubjectReference(' 001 234 ', secret), hashSubjectReference('001234', secret));
  assert.notEqual(hashSubjectReference('001234', secret), hashSubjectReference('001235', secret));
});
