create extension if not exists pgcrypto;

create table if not exists public.remote_assist_sessions (
    id uuid primary key,
    session_code text not null,
    requester_name text not null,
    purpose text not null,
    subject_reference_hash text,
    status text not null check (status in ('created', 'consented', 'active', 'ended', 'expired', 'revoked')),
    consent_version text not null,
    consent_notice_hash text not null,
    created_at timestamptz not null,
    expires_at timestamptz not null,
    retention_until timestamptz not null,
    consented_at timestamptz,
    started_at timestamptz,
    ended_at timestamptz,
    last_event_at timestamptz not null default now()
);

create unique index if not exists remote_assist_sessions_code_idx
    on public.remote_assist_sessions (session_code);
create index if not exists remote_assist_sessions_retention_idx
    on public.remote_assist_sessions (retention_until);

create table if not exists public.remote_assist_events (
    id bigint generated always as identity primary key,
    session_id uuid not null references public.remote_assist_sessions(id) on delete cascade,
    actor text not null check (actor in ('client', 'operator', 'system')),
    event_type text not null,
    metadata jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now()
);

create index if not exists remote_assist_events_session_idx
    on public.remote_assist_events (session_id, created_at);

alter table public.remote_assist_sessions enable row level security;
alter table public.remote_assist_events enable row level security;

-- No browser/mobile policy is created. Only the server-side Supabase service role may access these tables.

create or replace function public.purge_expired_remote_assist_data()
returns bigint
language plpgsql
security definer
set search_path = public
as $$
declare
    deleted_count bigint;
begin
    delete from public.remote_assist_sessions
    where retention_until <= now();
    get diagnostics deleted_count = row_count;
    return deleted_count;
end;
$$;

revoke all on function public.purge_expired_remote_assist_data() from public, anon, authenticated;
