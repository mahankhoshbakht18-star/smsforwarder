const form = document.querySelector('#session-form');
const createButton = document.querySelector('#create');
const statusElement = document.querySelector('#form-status');
const resultSection = document.querySelector('#result');
const summaryElement = document.querySelector('#session-summary');
const clientLinkElement = document.querySelector('#client-link');
const operatorLinkElement = document.querySelector('#operator-link');
const copyClientButton = document.querySelector('#copy-client');
const shareClientButton = document.querySelector('#share-client');
const openOperatorButton = document.querySelector('#open-operator');

let latestSession = null;

function setStatus(message, isError = false) {
  statusElement.textContent = message;
  statusElement.classList.toggle('error', isError);
}

function boundedInteger(value, minimum, maximum, fallback) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(maximum, Math.max(minimum, parsed));
}

async function copyText(value) {
  if (!value) return false;
  try {
    await navigator.clipboard.writeText(value);
    return true;
  } catch {
    const temporary = document.createElement('textarea');
    temporary.value = value;
    temporary.setAttribute('readonly', '');
    temporary.style.position = 'fixed';
    temporary.style.opacity = '0';
    document.body.appendChild(temporary);
    temporary.select();
    const copied = document.execCommand('copy');
    temporary.remove();
    return copied;
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  resultSection.hidden = true;
  latestSession = null;
  createButton.disabled = true;
  setStatus('در حال ساخت جلسه…');

  const adminKey = document.querySelector('#admin-key').value.trim();
  const requesterName = document.querySelector('#requester-name').value.trim();
  const purpose = document.querySelector('#purpose').value.trim();
  const subjectReference = document.querySelector('#subject-reference').value.trim();
  const ttlMinutes = boundedInteger(document.querySelector('#ttl').value, 5, 60, 15);
  const retentionMinutes = boundedInteger(
    document.querySelector('#retention').value,
    ttlMinutes,
    1440,
    Math.max(60, ttlMinutes),
  );

  if (adminKey.length < 32 || requesterName.length < 2 || purpose.length < 5) {
    setStatus('کلید مدیریت، نام درخواست‌کننده و هدف جلسه را بررسی کنید.', true);
    createButton.disabled = false;
    return;
  }

  try {
    const response = await fetch('/api/sessions', {
      method: 'POST',
      cache: 'no-store',
      headers: {
        'Content-Type': 'application/json',
        'X-Admin-Key': adminKey,
      },
      body: JSON.stringify({
        requesterName,
        purpose,
        subjectReference,
        ttlMinutes,
        retentionMinutes,
      }),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(payload.error || `HTTP ${response.status}`);
    }

    latestSession = payload;
    clientLinkElement.value = payload.clientJoinUrl;
    operatorLinkElement.value = payload.operatorUrl;
    summaryElement.textContent = `کد جلسه: ${payload.session.code} — انقضا: ${payload.session.expiresAt}`;
    resultSection.hidden = false;
    setStatus('جلسه با موفقیت ساخته شد.');
    resultSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (error) {
    setStatus(`ساخت جلسه ناموفق بود: ${error.message || 'خطای ناشناخته'}`, true);
  } finally {
    createButton.disabled = false;
  }
});

copyClientButton.addEventListener('click', async () => {
  const copied = await copyText(clientLinkElement.value);
  setStatus(copied ? 'لینک مشتری کپی شد.' : 'کپی لینک انجام نشد.', !copied);
});

shareClientButton.addEventListener('click', async () => {
  const url = clientLinkElement.value;
  if (!url) return;
  if (navigator.share) {
    try {
      await navigator.share({
        title: 'لینک همراهی از راه دور',
        text: 'برای ورود به جلسه همراهی، این لینک را روی گوشی مشتری باز کنید.',
        url,
      });
      return;
    } catch (error) {
      if (error?.name === 'AbortError') return;
    }
  }
  const copied = await copyText(url);
  setStatus(copied ? 'لینک مشتری کپی شد.' : 'اشتراک‌گذاری انجام نشد.', !copied);
});

openOperatorButton.addEventListener('click', () => {
  const url = latestSession?.operatorUrl;
  if (!url) return;
  window.open(url, '_blank', 'noopener,noreferrer');
});
