const values = new URLSearchParams(location.hash.slice(1));
const server = values.get('server') ?? `${location.protocol}//${location.host}`;
const token = values.get('token') ?? '';
const statusElement = document.querySelector('#status');

document.querySelector('#open').addEventListener('click', () => {
  if (!token) {
    statusElement.textContent = 'توکن جلسه وجود ندارد.';
    return;
  }
  location.href = `smsforwardremote://join?server=${encodeURIComponent(server)}&token=${encodeURIComponent(token)}`;
});

document.querySelector('#copy').addEventListener('click', async () => {
  if (!token) return;
  await navigator.clipboard.writeText(JSON.stringify({ server, token }));
  statusElement.textContent = 'اطلاعات جلسه کپی شد؛ آن را فقط داخل Companion وارد کنید.';
});
