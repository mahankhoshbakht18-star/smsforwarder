const statusElement = document.querySelector('#status');
const screenElement = document.querySelector('#screen');
const instructionElement = document.querySelector('#instruction');
const sendButton = document.querySelector('#send');
const endButton = document.querySelector('#end');

const fragment = new URLSearchParams(location.hash.slice(1));
const token = fragment.get('token') ?? '';
let socket;
let sessionId;
let currentImageUrl;

function setStatus(value) {
  statusElement.textContent = value;
}

function connect() {
  if (!token) {
    setStatus('توکن متصدی در لینک وجود ندارد.');
    return;
  }
  const scheme = location.protocol === 'https:' ? 'wss:' : 'ws:';
  socket = new WebSocket(`${scheme}//${location.host}/ws`);
  socket.binaryType = 'blob';
  socket.addEventListener('open', () => {
    socket.send(JSON.stringify({ type: 'authenticate', token }));
  });
  socket.addEventListener('message', (event) => {
    if (event.data instanceof Blob) {
      if (currentImageUrl) URL.revokeObjectURL(currentImageUrl);
      currentImageUrl = URL.createObjectURL(event.data);
      screenElement.src = currentImageUrl;
      return;
    }
    const message = JSON.parse(event.data);
    if (message.type === 'authenticated') {
      sessionId = message.session.id;
      setStatus(`متصل — ${message.session.requesterName}: ${message.session.purpose}`);
    } else if (message.type === 'peerState') {
      setStatus(message.state === 'connected' ? 'گوشی مراجعه‌کننده متصل شد.' : 'گوشی مراجعه‌کننده قطع شد.');
    } else if (message.type === 'shareState') {
      setStatus(message.state === 'paused' ? 'اشتراک توسط مراجعه‌کننده مکث شد.' : `وضعیت اشتراک: ${message.state}`);
    } else if (message.type === 'error') {
      setStatus(`خطا: ${message.message}`);
    }
  });
  socket.addEventListener('close', () => setStatus('اتصال پایان یافت.'));
  socket.addEventListener('error', () => setStatus('اتصال امن برقرار نشد.'));
}

sendButton.addEventListener('click', () => {
  const text = instructionElement.value.trim();
  if (!text || socket?.readyState !== WebSocket.OPEN) return;
  socket.send(JSON.stringify({ type: 'instruction', text }));
  instructionElement.value = '';
});

endButton.addEventListener('click', async () => {
  if (!sessionId || !token) return;
  endButton.disabled = true;
  try {
    await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/end`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
    });
  } finally {
    socket?.close();
    setStatus('جلسه توسط متصدی پایان یافت.');
  }
});

window.addEventListener('beforeunload', () => {
  if (currentImageUrl) URL.revokeObjectURL(currentImageUrl);
  socket?.close();
});

connect();
