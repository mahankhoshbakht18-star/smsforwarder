# Build report — SMSForwardManager 2.3.0 unified customer APK

## Completed source changes

- One Android module and one APK.
- Customer-side Remote Assist merged into the main app.
- Deep-link handling and automatic Remote Assist navigation.
- MediaProjection foreground service moved into `:app`.
- Operator/admin Android code removed.
- Browser admin session-creation panel added to the Node server.
- CI and local build scripts changed to produce only `app-debug.apk`.
- Version updated to `2.3.0` (`versionCode 25`).

## Verification required by CI

- Android unit tests.
- Android debug APK compilation.
- Node syntax checks and integration tests.
- APK SHA-256 artifact generation.
