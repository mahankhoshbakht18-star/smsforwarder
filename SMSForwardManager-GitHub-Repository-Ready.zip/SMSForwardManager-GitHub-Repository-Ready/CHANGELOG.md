# Changelog

## 2.5.0 — MahanBot OTP integration

- Added explicit-consent OTP handoff to MahanBot by active national ID.
- Added encrypted MahanBot device key, endpoint validation, and connection test.
- Added Room migration 5→6 and privacy-safe backup behavior.
- Added local-only HTTP support for debug builds and HTTPS-only release behavior.
- Added OTP freshness, deduplication, and one-time consumption contract on the MahanBot side.

# نسخه 2.4.0 — بازطراحی رابط کاربری

- جایگزینی اصطلاح «قوانین» با «الگوهای انتقال» در رابط فارسی.
- تم برند فیروزه‌ای MahanVIP با کارت‌های گرد، حاشیه ظریف و آیکون‌های واضح.
- فرم افزودن الگوی انتقال ساده و کوتاه شد؛ تنظیمات حرفه‌ای در بخش جمع‌شونده قرار گرفت.
- جست‌وجوی الگوهای انتقال جمع‌وجور و دارای پاک‌سازی سریع شد.
- روش‌های ارتباط فقط به سیم‌کارت، اینترنت و سیم‌کارت و اینترنت محدود شد.
- بخش درباره برنامه با نام تیم MahanVIP، تماس امیر نرانی و پشتیبانی تلگرام به‌روزرسانی شد.
- نسخه برنامه به 2.4.0 (کد 26) ارتقا یافت.

# Changelog

## 2.3.0 — 2026-07-17

- Replaced the two-APK operator/Companion design with one customer-facing Android APK.
- Merged MediaProjection sharing, one-time session loading, consent and pause/resume/stop controls into the main SMS app.
- Removed Android-side session creation, bootstrap admin-key storage, native operator viewer and operator WebSocket code.
- Added direct `smsforwardremote://join` deep-link handling and automatic navigation to Remote Assist.
- Added a web operator administration page for session creation, customer-link sharing and private console launch.
- Updated manifests, foreground-service permissions, build scripts, CI artifact naming and documentation for one APK.
- Fixed the duplicated `LoadingScreen` declaration present in the 2.2.0 source package.
- Kept Remote Assist observation-only with visible Android capture and text guidance.

## 2.2.0 — 2026-07-17

- Promoted Remote Assist to a permanent primary navigation destination and moved About into Settings.
- Added a native operator console inside the Android operator app: live frame viewing, customer/relay state, text guidance, reconnect and session termination.
- Added encrypted local storage for the Remote Assist admin key using Android Keystore.
- Added server health testing and automatic operator WebSocket connection after session creation.
- Fixed Companion deep-link token loss after Activity recreation and added automatic session loading.
- Corrected Companion connection reporting by separating secure-relay and operator-console states.
- Reduced Companion CPU usage by encoding frames only while an operator is actually connected.
- Added a dedicated Companion Material 3 theme and clearer live-session status UI.
- Hardened the relay server with session-creation rate limiting, role checks for share events, token claim validation, socket-state replay/cleanup and production HSTS.
- Kept Remote Assist observation-only: no Accessibility Service, touch injection, hidden capture or protected-screen bypass.

## 2.1.0

- Added a consent-first Remote Assist session screen for operators.
- Added a separate low-permission Companion APK with visible MediaProjection sharing, pause and stop.
- Added an ephemeral Node.js WebSocket/JPEG relay, operator panel and optional Supabase audit schema.
- Added versioned consent, architecture, security boundary and device test documentation.
- Explicitly excluded Accessibility touch injection, `FLAG_SECURE` bypass, hidden capture and credential/OTP collection.

## 2.0.1 — 2026-07-12

### Fixed

- Corrected SMS sent and delivery result handling.
- Removed the false red `SMS_DELIVERY_RESULT_0` status from the UI.
- Interpreted PDU `SmsMessage.STATUS_COMPLETE` (`0`) as successful delivery.
- Separated sent and delivery receivers.
- Added unique sent/delivery `PendingIntent` request codes for every multipart part.
- Added idempotent per-part tracking so duplicate broadcasts do not increase counters.
- Fixed multipart sent/delivered counters and “delivery unknown” timeout behavior.
- Fixed a duplicate local declaration in `SettingsViewModel` and mismatched braces in `LogsScreen` found during structural validation.

### Added

- Four global delivery routes and matching per-rule overrides.
- Retrofit/OkHttp HTTPS forwarding with idempotency and redirect blocking.
- Persistent Room/WorkManager queue, manual retry/cancel and configurable retry limits.
- Rule blocked phrases, schedules, daily limits, prefix/suffix and a non-sending rule test dialog.
- Compact rule actions including report navigation.
- App lock, secure API-token storage, sensitive-message blocking and masked logs.
- Per-part SMS status table and Room migrations 3→4 and 4→5.
- Daily log cleanup, JSON log export, backup schema 3 and bilingual strings.
- About screen crediting **Amir Narani**.

### Changed

- Database version: 5.
- App version: 2.0.1 (`versionCode 21`).
- Foreground-service type changed to `remoteMessaging`, matching message transfer behavior.
