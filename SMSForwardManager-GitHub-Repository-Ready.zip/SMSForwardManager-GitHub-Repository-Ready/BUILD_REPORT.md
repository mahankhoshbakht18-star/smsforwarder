# Build report — SMSForwardManager 2.0.1

Date: 2026-07-12

## Project configuration

- Application ID: `ir.smsforwardmanager`
- Debug application ID: `ir.smsforwardmanager.debug`
- Version name/code: `2.0.1` / `21`
- Java source/target: 17
- Gradle wrapper: 8.11.1
- Android Gradle Plugin: 8.9.2
- Kotlin: 2.1.21
- Compose BOM: 2025.06.01
- `compileSdk`: 35
- `targetSdk`: 35
- `minSdk`: 29
- Room database version: 5

## Environment available here

- Runtime JDK: OpenJDK 21.0.10
- Local command-line Kotlin compiler: 1.9.0
- Android SDK: not installed/cached
- Gradle 8.11.1 distribution: not cached
- Outbound dependency download: unavailable

## Checks completed

- Original source backed up before edits.
- All Android resource XML files parsed successfully.
- Persian/English string and plural key parity passed.
- All referenced app string/plural resources exist.
- Kotlin delimiter/structure scan passed; no parser-level brace/declaration errors remain.
- Pure Kotlin checks passed for OTP extraction, phone normalization, sensitive detection/masking and HTTPS endpoint validation.
- Source scan confirmed no `fallbackToDestructiveMigration()` call.
- Source scan confirmed no embedded API token or private key.
- Critical delivery path reviewed: separate sent/delivery receivers, PDU status parsing, unique multipart intents and idempotent per-part SQL updates.

## Full build attempt

Intended command:

```bash
./gradlew --no-daemon clean testDebugUnitTest assembleDebug --stacktrace
```

The Gradle wrapper cannot start compilation in this environment because it must download Gradle 8.11.1 from `services.gradle.org`, while outbound network access is unavailable. The wrapper stopped with `java.net.UnknownHostException: services.gradle.org` before project compilation. No Android SDK is present either. The captured output is included as `BUILD_ATTEMPT.log`.

## Result

- Gradle sync: **not completed in this environment**
- Unit/instrumentation tests: **not run by Gradle here**
- APK: **not produced**
- Device/emulator installation: **not performed**
- Remaining release gate: run the command above on Android Studio/AndroidIDE with SDK 35 and Internet access, fix any compiler/device-specific issue, then verify the generated APK on Android 11 and a dual-SIM Xiaomi device.

This report deliberately does not claim a successful APK build or device test.
