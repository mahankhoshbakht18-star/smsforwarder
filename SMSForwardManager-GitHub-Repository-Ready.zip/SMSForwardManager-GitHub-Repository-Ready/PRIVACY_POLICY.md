# Privacy policy — Smart SMS Manager

Last updated: 2026-07-12

Smart SMS Manager processes incoming SMS messages locally to evaluate rules created by the device owner. In SIM-only mode, message forwarding is performed through the selected SIM. In Internet-enabled modes, only content matched by an enabled rule is sent to the HTTPS endpoint configured by the owner.

## Local data

The app may store rules, destinations, incoming-message metadata, forwarding payloads, status counters and local logs in its Room database. Sensitive numeric codes are masked in the visible history and JSON log export. The owner can delete individual logs, clear history or erase all app data.

## Credentials

The optional API token is encrypted with a key held by Android Keystore. It is not stored in Room, written to Logcat or included in JSON backups.

## Backups

App backup/restore includes rules and non-secret settings. API tokens, app-lock state and encryption keys are excluded. Message history is not part of the rule backup.

## Permissions

- `RECEIVE_SMS`: receive SMS for rule evaluation.
- `SEND_SMS`: send through a SIM when a SIM route is selected.
- `READ_PHONE_STATE`: list active SIM subscriptions for user selection.
- `INTERNET` and `ACCESS_NETWORK_STATE`: HTTPS delivery and connectivity checks.
- `POST_NOTIFICATIONS` and foreground-service permissions: visible forwarding status.
- `USE_BIOMETRIC`: optional app lock.
- `RECEIVE_BOOT_COMPLETED`: restore visible status after reboot when enabled.

## Consent and transparency

The application must be used only on devices and accounts owned by the user or managed with explicit authorization. It does not hide its launcher icon, forwarding status or service notification. Sensitive login, one-time and banking codes are blocked by default and require an explicit per-rule confirmation.

## Third parties

The app does not contain advertising or analytics SDKs. Any server that receives messages is selected and controlled by the device owner; that server’s operator is responsible for its own retention and security practices.

Designer: Amir Narani

## Remote Assist module

Remote Assist creates short-lived sessions for visible screen sharing and text guidance. The customer must accept a versioned disclosure and Android's own MediaProjection confirmation. A foreground notification remains visible and provides pause/stop controls.

The supplied relay forwards low-rate screen frames in memory and does not store them. Protected content remains subject to Android and destination-app security controls. The feature does not contain an Accessibility Service, touch injection, overlay control, background capture or a mechanism to bypass `FLAG_SECURE`.

Session audit data may include requester, immutable purpose, timestamps, consent version/hash, status and a keyed hash of an optional case reference. Raw national ID, passwords, PINs, OTPs, dynamic banking codes, role tokens and image frames must not be stored in application or server logs.

The customer Companion is a separate application and does not request SMS, contacts, storage, Accessibility, camera or microphone access. Production sessions require an operator-controlled HTTPS server and a retention policy shown before consent.
