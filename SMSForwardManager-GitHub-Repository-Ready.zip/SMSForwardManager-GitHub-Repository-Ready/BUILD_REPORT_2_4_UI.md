# SMSForwardManager 2.4.0 — UI and Product Update

## Delivered

- Single customer Android application (`:app`).
- Persian user-facing term changed from «قوانین» to «الگوهای انتقال».
- Fixed turquoise Material 3 theme with bordered cards, rounded surfaces, and contextual icons.
- Compact transfer-pattern search with quick clear and collapsible filters.
- Simplified transfer-pattern editor: essential fields remain visible; low-frequency options are grouped in a collapsible advanced section.
- Only three visible connection choices: SIM, Internet, and SIM + Internet.
- About screen credits MahanVIP Team and includes Amir Narani, `09154372582`, Telegram support `Tel.me@cofenetonline25802`, and the requested thank-you message.

## Static validation

- Android XML resources parse successfully.
- Persian and English resources contain 485 matching keys.
- 354 `R.string` references resolve.
- 80 Kotlin files passed structural truncation/delimiter checks.
- Three Remote Assist server JavaScript files passed `node --check`.
- No Accessibility control or gesture-injection API is present.

## Build status

The APK was not compiled in this runtime because the Gradle distribution and Maven dependencies were not cached and runtime DNS access to `services.gradle.org` was unavailable. No unverified APK is included.

Build command:

```bash
./gradlew --no-daemon clean :app:assembleDebug
```
