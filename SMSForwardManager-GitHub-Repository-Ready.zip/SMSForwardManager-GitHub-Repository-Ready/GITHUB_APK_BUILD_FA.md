# ساخت APK نصب‌شدنی با GitHub Actions

Workflow پروژه JDK 17، Android SDK API 35 و Gradle 8.11.1 را در GitHub Runner آماده می‌کند، تست‌ها را اجرا می‌کند و APK دیباگ امضاشده و قابل نصب می‌سازد.

خروجی:

`SMSForwardManager-2.5.1-MahanBot-debug.apk`

مسیر دریافت در GitHub:

`Actions → Build installable Android APK → آخرین اجرای موفق → Artifacts`

APK دیباگ با کلید موقت استاندارد Android امضا می‌شود و برای نصب مستقیم و تست عملی مناسب است. برای انتشار عمومی، Release باید با Keystore خصوصی دائمی امضا شود.
