# Smart SMS Manager 2.4.0

A unified Persian/English Android application installed on the **customer phone**. It manages owner-authorized SMS forwarding and also accepts short-lived Remote Assist links for visible, observation-only screen sharing.

## Product architecture

- **One Android APK:** SMS receiver, transfer patterns, logs, settings and customer-side Remote Assist.
- **Operator web panel:** creates one-time sessions, sends the customer link, displays the permitted screen stream and sends short text guidance.
- **Remote Assist server:** HTTPS/WebSocket relay with role-specific expiring tokens and optional Supabase event audit.

There is no second Companion APK and no operator/admin key inside the Android app.

## SMS delivery routes

1. **SIM** — forwards through the selected SIM.
2. **Internet** — sends matched content to the configured HTTPS API.
3. **SIM + Internet** — uses the Internet route first and falls back to SIM when the API cannot complete the transfer.

Legacy route values from older backups are normalized to one of these three visible choices.

## Implemented Android capabilities

- Incoming SMS receiver, sender/keyword filters, blocked phrases and duplicate detection.
- Room queue, WorkManager retry scheduling and multipart SMS sent/delivery tracking.
- Per-pattern schedules, daily limits, prefix/suffix and SIM selection.
- HTTPS forwarding with idempotency keys, redirect blocking and encrypted API token storage.
- Sensitive login/OTP/banking-code forwarding blocked by default unless explicitly authorized per rule.
- Visible ongoing notification while automatic forwarding is enabled.
- App lock using supported biometrics or the device credential.
- Masked local history, export, backup and restore.
- Material 3, RTL/LTR, Persian/English and light/dark/system themes.
- Customer-side Remote Assist deep link handling through `smsforwardremote://join`.
- Explicit request review and consent before Android MediaProjection confirmation.
- Visible screen-sharing foreground service with pause, resume and stop controls.
- Separate relay/operator connection status and text-only operator guidance.
- Protected Android screens remain protected by the platform.

## Operator workflow

1. Open `https://YOUR_ASSIST_DOMAIN/admin.html`.
2. Enter the server admin key, requester name, purpose and expiry.
3. Send the generated **customer link**.
4. The link opens Smart SMS Manager on the customer phone and loads the request automatically.
5. After customer approval and Android confirmation, open the generated private operator link.
6. View the permitted screen frames and send short guidance from the browser.

## Android and build configuration

- `minSdk 29` — Android 10.
- `targetSdk 35`, `compileSdk 35`.
- JDK 17 project target.
- Gradle 8.11.1, Android Gradle Plugin 8.9.2, Kotlin 2.1.21.
- App version `2.4.0`, version code `26`.

Build:

```bash
./build_all.sh
```

Expected APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Main documentation

- [`docs/ONLINE_API.md`](docs/ONLINE_API.md)
- [`docs/REMOTE_ASSIST_ARCHITECTURE.md`](docs/REMOTE_ASSIST_ARCHITECTURE.md)
- [`docs/REMOTE_ASSIST_TEST_PLAN.md`](docs/REMOTE_ASSIST_TEST_PLAN.md)
- [`PRIVACY_POLICY.md`](PRIVACY_POLICY.md)
- [`BUILD_REPORT_2_3_UNIFIED.md`](BUILD_REPORT_2_3_UNIFIED.md)
