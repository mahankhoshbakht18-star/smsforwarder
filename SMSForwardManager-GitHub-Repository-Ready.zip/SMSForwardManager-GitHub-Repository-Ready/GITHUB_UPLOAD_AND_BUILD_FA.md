# آپلود و ساخت APK در GitHub

1. در مخزن `mahankhoshbakht18-star/mahanbot` شاخه `android-apk-build` را انتخاب کنید.
2. گزینه `Add file` و سپس `Upload files` را بزنید.
3. فایل `SMSForwardManager-2.5.1-GitHubBuild-source.zip` را بدون تغییر نام در ریشه شاخه آپلود کنید.
4. Commit را روی همان شاخه انجام دهید.
5. Workflow با نام `Build installable Android APK` خودکار اجرا می‌شود.
6. پس از سبز شدن Build، در صفحه همان Run از بخش `Artifacts` فایل `SMSForwardManager-2.5.1-MahanBot-installable-apk` را دانلود کنید.
7. داخل Artifact فایل نصب‌شدنی `SMSForwardManager-2.5.1-MahanBot-debug.apk` و فایل `SHA256SUMS.txt` قرار دارد.

این APK به‌صورت Debug امضا شده و برای نصب مستقیم و تست عملی مناسب است. نسخه انتشار عمومی باید بعداً با Keystore خصوصی دائمی امضا شود.
