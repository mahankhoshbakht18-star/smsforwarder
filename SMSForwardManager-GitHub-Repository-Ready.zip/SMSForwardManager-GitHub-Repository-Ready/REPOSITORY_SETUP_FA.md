# راه‌اندازی مخزن مستقل SMSForwardManager

نام پیشنهادی مخزن:

`mahankhoshbakht18-star/SMSForwardManager`

نوع پیشنهادی: **Private**

پس از Push روی شاخه `main`، Workflow زیر خودکار اجرا می‌شود:

`.github/workflows/build-debug-apk.yml`

Artifact خروجی:

`SMSForwardManager-2.5.1-installable-apk`

فایل نصب:

`SMSForwardManager-2.5.1-MahanBot-debug.apk`
