@echo off
setlocal

call gradlew.bat --no-daemon clean :app:testDebugUnitTest :app:assembleDebug
if errorlevel 1 exit /b %errorlevel%

echo Unified customer APK: app\build\outputs\apk\debug\app-debug.apk
endlocal
