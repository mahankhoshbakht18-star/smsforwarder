# Upgrade notes — Smart SMS Manager 2.0.1

The application uses explicit Room migrations and does not call `fallbackToDestructiveMigration()`.

Migration chain:

- 1→2: language and multipart counters.
- 2→3: online delivery settings and delivery-channel snapshots.
- 3→4: secure/retry settings, per-part status table, and repair of old `SMS_DELIVERY_RESULT_0` rows.
- 4→5: blocked phrases, per-rule route, schedules, daily limit and prefix/suffix fields.

Existing rules, destinations, incoming messages and forward logs are preserved by the migration SQL. Before installing over an earlier build, keep an exported app backup and a copy of the old APK.

Because the debug application ID is `ir.smsforwardmanager.debug`, it installs separately from a release build using `ir.smsforwardmanager`.
