# Build and verification report — 2.1.0 Remote Assist

Date: 2026-07-16

## Source baseline

- Received archive: `SMSForwardManager-v2.0-final-source.zip`
- Actual platform: Native Android, Kotlin, Jetpack Compose (not Flutter)
- Existing app preserved as the operator module; no SMS database migration was introduced.
- Added independent `:companion` application module and `remote-assist-server`.

## Completed checks

- All Android resource/manifest XML files parse successfully.
- Default and Persian resource keys match for both Android modules.
- Every new `R.string` reference resolves to a declared resource.
- New Kotlin source delimiter/structure scan passes.
- Companion manifest permission boundary passes: no SMS, Accessibility, overlay, contacts, camera, microphone or storage permission.
- Source scan confirms no Accessibility Service, input injection or secure-screen bypass implementation.
- Node.js syntax checks pass for server and browser JavaScript.
- Node.js unit/integration tests: 4 passed, 0 failed.
- Integration test verifies consent, role authentication, binary frame relay and operator-to-customer instruction relay.
- `npm audit --omit=dev`: 0 known vulnerabilities.
- REST smoke test verifies session creation, summary, consent transition and absence of raw subject reference in responses.

## Android build attempt

Command attempted:

```bash
GRADLE_USER_HOME=/workspace/scratch/e55bec5d8520/.gradle \
./gradlew --no-daemon projects
```

The Gradle wrapper attempted to download Gradle 8.11.1 from `services.gradle.org`, but this execution environment blocks that network route and contains no Android SDK or cached Gradle distribution. The build stopped before Gradle configuration/Android compilation with `java.net.SocketException: Network is unreachable`.

Therefore:

- Android Gradle compilation: **not completed in this environment**
- APK generation: **not completed in this environment**
- Installation/device test: **not completed in this environment**

No APK is claimed as produced or install-ready by this report.

## Build on Windows/Android Studio

Requirements:

- Android Studio with Android SDK Platform 35 and Build Tools 35;
- JDK 17 (Android Studio embedded JDK is suitable);
- Internet access for the first Gradle/dependency sync.

From the project root:

```bat
build_all.bat
```

Expected debug outputs:

- `app\build\outputs\apk\debug\app-debug.apk`
- `companion\build\outputs\apk\debug\companion-debug.apk`

The included GitHub Actions workflow performs the same build when the project is pushed to a private repository and the workflow is manually run.

## Mandatory device gates

Follow `docs/REMOTE_ASSIST_TEST_PLAN.md` with non-sensitive test screens. A real bank workflow must not be used until Android compilation succeeds, the complete device matrix passes, the server is behind HTTPS, and the applicable provider/legal review is complete.
