#!/usr/bin/env bash
set -euo pipefail

./gradlew --no-daemon clean \
  :app:testDebugUnitTest \
  :app:assembleDebug

echo "Unified customer APK: app/build/outputs/apk/debug/app-debug.apk"
