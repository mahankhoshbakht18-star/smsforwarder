# SMS Forward Manager — گزارش تاریخی فاز ۱

> این فایل فقط سابقه بیلد اولیه را نگه می‌دارد و مشخصات نسخه نهایی نیست. برای نسخه کامل 1.0، قابلیت‌ها، تست و راهنمای نصب به `README.md` مراجعه کنید.

## وضعیت

فاز معماری و دیتابیس تکمیل شده است. پروژه برای Android 10 تا Android 15 تنظیم شده:

- `minSdk = 29`
- `targetSdk = 35`
- `compileSdk = 35`
- JDK 17
- Kotlin 2.1.21
- Android Gradle Plugin 8.9.2
- Gradle 8.11.1

## اجزای آماده

- Version Catalog کامل در `gradle/libs.versions.toml`
- Jetpack Compose + Material 3
- Hilt
- Room با schema version 1
- WorkManager (وابستگی آماده برای فاز ۲)
- Kotlin Serialization (وابستگی آماده برای Export/Import)
- هفت Entity نرمال‌شده
- هفت DAO
- Relation/Projectionهای قوانین و گزارش‌ها
- TypeConverterهای مقاوم در برابر مقدار enum ناشناخته
- ماژول Hilt برای Database و تمام DAOها
- تست واحد TypeConverterها
- Manifest بدون مجوز اینترنت و با backup سیستمی غیرفعال
- فایل schema واقعی Room در `app/schemas/.../1.json`
- Gradle Wrapper کامل شامل `gradlew` و `gradle-wrapper.jar`

## تأیید بیلد

فرمان زیر با JDK 17 و Android SDK 35 اجرا و با وضعیت `BUILD SUCCESSFUL` تمام شد:

```bash
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

در این اعتبارسنجی، تولید کدهای Room، پردازش annotationهای Hilt، کامپایل Kotlin،
کامپایل Java، تست واحد و تولید APK دیباگ همگی موفق بودند.

## تصمیم‌های امنیتی تثبیت‌شده

1. مجوز `INTERNET` عمداً وجود ندارد.
2. Android Auto Backup خاموش است تا متن پیامک و قوانین وارد فضای پشتیبان ابری نشوند.
3. متن هر پیام فقط در دیتابیس خصوصی sandbox برنامه ذخیره می‌شود.
4. fingerprint یکتا، پردازش دوباره یک پیام چندبخشی یا تحویل تکراری Broadcast را مهار می‌کند.
5. حذف قانون یا مقصد، تاریخچه ارسال را حذف نمی‌کند؛ snapshot شماره مقصد در لاگ می‌ماند.
6. هیچ destructive migration برای نسخه‌های آینده فعال نشده است.

## مرحله بعد

در فاز ۲، Repositoryها، RuleMatcher، استخراج OTP، `SMSReceiver`، صف WorkManager،
ارسال چندبخشی، دریافت نتیجه SENT/DELIVERED و مجوزهای Android 10 تا 15 اضافه می‌شوند.
