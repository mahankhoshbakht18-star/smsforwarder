package ir.smsforwardmanager.sms

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.hilt.android.AndroidEntryPoint
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.core.model.ForwardStatus
import ir.smsforwardmanager.data.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class SmsSentReceiver : BroadcastReceiver() {
    @Inject lateinit var tracker: SmsDeliveryTracker
    @Inject lateinit var scheduler: ForwardingScheduler
    @Inject lateinit var settingsRepository: SettingsRepository

    override fun onReceive(context: Context, intent: Intent) {
        val attemptId = intent.getLongExtra(ForwardingWorker.EXTRA_ATTEMPT_ID, -1L)
        val partIndex = intent.getIntExtra(ForwardingWorker.EXTRA_PART_INDEX, -1)
        if (attemptId <= 0 || partIndex < 0) return

        val pendingResult = goAsync()
        val sentResult = resultCode
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val successful = sentResult == Activity.RESULT_OK
                val update = tracker.recordSent(
                    attemptId = attemptId,
                    partIndex = partIndex,
                    resultCode = sentResult,
                    successful = successful,
                    errorKey = if (successful) null else SmsResultKeys.sentErrorKey(sentResult),
                ) ?: return@launch

                if (!update.changed) return@launch

                when {
                    update.attempt.status == ForwardStatus.SENT_WAITING_DELIVERY ->
                        scheduler.enqueueDeliveryTimeout(attemptId)

                    update.aggregate.failedSentParts >= update.aggregate.totalParts &&
                        update.aggregate.sentParts == 0 -> {
                        if (update.attempt.deliveryMode == DeliveryMode.SMS_THEN_INTERNET) {
                            scheduler.enqueueInternetFallback(attemptId)
                        } else {
                            val settings = settingsRepository.get()
                            if (update.attempt.attemptCount < settings.maxSendAttempts) {
                                scheduler.enqueueRetry(attemptId, settings.retryDelaySeconds.toLong())
                            }
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
