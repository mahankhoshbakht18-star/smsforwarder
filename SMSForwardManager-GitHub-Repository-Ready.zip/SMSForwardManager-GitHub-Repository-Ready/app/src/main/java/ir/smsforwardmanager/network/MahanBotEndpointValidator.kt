package ir.smsforwardmanager.network

import ir.smsforwardmanager.BuildConfig
import java.net.URI

object MahanBotEndpointValidator {
    fun normalize(value: String): String? = runCatching {
        val input = value.trim()
        if (input.isBlank()) return null
        val uri = URI(input)
        val host = uri.host?.lowercase()?.trim().orEmpty()
        if (host.isBlank() || uri.userInfo != null || uri.fragment != null) return null
        val scheme = uri.scheme?.lowercase().orEmpty()
        val allowed = scheme == "https" ||
            (BuildConfig.DEBUG && scheme == "http" && isLocalOrPrivateLiteral(host))
        if (!allowed) return null
        val path = uri.path.orEmpty().trim().trimEnd('/')
        val normalizedPath = when {
            path.isBlank() -> "/api/v1/sms/otp"
            path.endsWith("/api/v1/sms/otp") -> path
            else -> "$path/api/v1/sms/otp"
        }
        URI(
            scheme,
            null,
            host,
            uri.port,
            normalizedPath,
            null,
            null,
        ).toString()
    }.getOrNull()

    fun statusUrl(value: String): String? = normalize(value)?.let { "$it/status" }

    fun isValid(value: String): Boolean = normalize(value) != null

    private fun isLocalOrPrivateLiteral(host: String): Boolean {
        if (host == "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) return true
        if (host == "::1" || host == "0:0:0:0:0:0:0:1") return true
        if (host.startsWith("127.") || host == "0.0.0.0") return true
        if (host.startsWith("10.") || host.startsWith("192.168.")) return true
        val chunks = host.split('.')
        if (chunks.size == 4) {
            val first = chunks[0].toIntOrNull()
            val second = chunks[1].toIntOrNull()
            if (first == 172 && second != null && second in 16..31) return true
        }
        return false
    }
}
