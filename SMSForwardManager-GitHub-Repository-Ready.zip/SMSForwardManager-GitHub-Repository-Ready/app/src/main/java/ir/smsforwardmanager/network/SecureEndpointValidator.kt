package ir.smsforwardmanager.network

import java.net.URI

object SecureEndpointValidator {
    fun isValid(value: String): Boolean = runCatching {
        val uri = URI(value.trim())
        val host = uri.host?.lowercase()?.trim().orEmpty()
        uri.scheme.equals("https", ignoreCase = true) &&
            host.isNotBlank() &&
            uri.userInfo == null &&
            !isLocalOrPrivateLiteral(host)
    }.getOrDefault(false)

    private fun isLocalOrPrivateLiteral(host: String): Boolean {
        if (host == "localhost" || host.endsWith(".localhost") || host.endsWith(".local")) return true
        if (host == "::1" || host == "0:0:0:0:0:0:0:1") return true
        if (host.startsWith("127.") || host == "0.0.0.0") return true
        if (host.startsWith("10.") || host.startsWith("192.168.")) return true
        val chunks = host.split('.')
        if (chunks.size == 4) {
            val first = chunks[0].toIntOrNull()
            val second = chunks[1].toIntOrNull()
            if (first == 172 && second != null && second in 16..31) return true
        }
        return false
    }
}
