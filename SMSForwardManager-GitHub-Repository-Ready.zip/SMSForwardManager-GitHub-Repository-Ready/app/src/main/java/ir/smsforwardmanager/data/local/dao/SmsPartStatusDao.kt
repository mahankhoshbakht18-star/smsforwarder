package ir.smsforwardmanager.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import ir.smsforwardmanager.data.local.entity.SmsPartStatusEntity
import ir.smsforwardmanager.data.local.relation.SmsPartAggregate

@Dao
interface SmsPartStatusDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(parts: List<SmsPartStatusEntity>)

    @Query("DELETE FROM sms_part_status WHERE attempt_id = :attemptId")
    suspend fun deleteForAttempt(attemptId: Long): Int

    @Query(
        """
        UPDATE sms_part_status
        SET sent_status = 'SENT',
            sent_result_code = :resultCode,
            sent_at = :eventAt,
            last_error = NULL,
            updated_at = :eventAt
        WHERE attempt_id = :attemptId
          AND part_index = :partIndex
          AND sent_status != 'SENT'
        """,
    )
    suspend fun markSent(
        attemptId: Long,
        partIndex: Int,
        resultCode: Int,
        eventAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE sms_part_status
        SET sent_status = 'FAILED',
            sent_result_code = :resultCode,
            last_error = :errorKey,
            updated_at = :eventAt
        WHERE attempt_id = :attemptId
          AND part_index = :partIndex
          AND sent_status = 'PENDING'
        """,
    )
    suspend fun markSentFailed(
        attemptId: Long,
        partIndex: Int,
        resultCode: Int,
        errorKey: String,
        eventAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE sms_part_status
        SET delivery_status = 'DELIVERED',
            delivery_status_code = :statusCode,
            delivered_at = :eventAt,
            last_error = NULL,
            updated_at = :eventAt
        WHERE attempt_id = :attemptId
          AND part_index = :partIndex
          AND delivery_status != 'DELIVERED'
        """,
    )
    suspend fun markDelivered(
        attemptId: Long,
        partIndex: Int,
        statusCode: Int?,
        eventAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE sms_part_status
        SET delivery_status = 'FAILED',
            delivery_status_code = :statusCode,
            last_error = :errorKey,
            updated_at = :eventAt
        WHERE attempt_id = :attemptId
          AND part_index = :partIndex
          AND delivery_status NOT IN ('DELIVERED', 'FAILED')
        """,
    )
    suspend fun markDeliveryFailed(
        attemptId: Long,
        partIndex: Int,
        statusCode: Int?,
        errorKey: String,
        eventAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE sms_part_status
        SET delivery_status = 'UNKNOWN',
            delivery_status_code = :statusCode,
            last_error = NULL,
            updated_at = :eventAt
        WHERE attempt_id = :attemptId
          AND part_index = :partIndex
          AND delivery_status = 'PENDING'
        """,
    )
    suspend fun markDeliveryUnknown(
        attemptId: Long,
        partIndex: Int,
        statusCode: Int?,
        eventAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE sms_part_status
        SET delivery_status = 'UNKNOWN',
            last_error = NULL,
            updated_at = :eventAt
        WHERE attempt_id = :attemptId
          AND delivery_status = 'PENDING'
        """,
    )
    suspend fun markAllPendingDeliveryUnknown(
        attemptId: Long,
        eventAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        SELECT
            COALESCE(MAX(total_parts), 0) AS totalParts,
            COALESCE(SUM(CASE WHEN sent_status = 'SENT' THEN 1 ELSE 0 END), 0) AS sentParts,
            COALESCE(SUM(CASE WHEN sent_status = 'FAILED' THEN 1 ELSE 0 END), 0) AS failedSentParts,
            COALESCE(SUM(CASE WHEN delivery_status = 'DELIVERED' THEN 1 ELSE 0 END), 0) AS deliveredParts,
            COALESCE(SUM(CASE WHEN delivery_status = 'FAILED' THEN 1 ELSE 0 END), 0) AS failedDeliveryParts,
            COALESCE(SUM(CASE WHEN delivery_status = 'UNKNOWN' THEN 1 ELSE 0 END), 0) AS unknownDeliveryParts,
            COALESCE(SUM(CASE WHEN delivery_status = 'PENDING' THEN 1 ELSE 0 END), 0) AS pendingDeliveryParts
        FROM sms_part_status
        WHERE attempt_id = :attemptId
        """,
    )
    suspend fun aggregate(attemptId: Long): SmsPartAggregate
}
