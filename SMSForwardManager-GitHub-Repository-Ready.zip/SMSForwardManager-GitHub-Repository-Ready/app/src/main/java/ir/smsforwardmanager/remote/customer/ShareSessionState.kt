package ir.smsforwardmanager.remote.customer

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class ShareUiState(
    val running: Boolean = false,
    val paused: Boolean = false,
    val relayConnected: Boolean = false,
    val operatorConnected: Boolean = false,
    val statusMessage: String? = null,
    val instruction: String? = null,
)

object ShareSessionState {
    private val mutableState = MutableStateFlow(ShareUiState())
    val state: StateFlow<ShareUiState> = mutableState.asStateFlow()

    fun update(transform: (ShareUiState) -> ShareUiState) {
        mutableState.value = transform(mutableState.value)
    }

    fun reset(message: String? = null) {
        mutableState.value = ShareUiState(statusMessage = message)
    }
}
