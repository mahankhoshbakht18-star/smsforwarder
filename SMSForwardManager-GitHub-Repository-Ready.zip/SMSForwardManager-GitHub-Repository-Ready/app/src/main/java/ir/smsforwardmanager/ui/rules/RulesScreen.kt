package ir.smsforwardmanager.ui.rules

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PauseCircle
import androidx.compose.material.icons.outlined.Sms
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import ir.smsforwardmanager.R
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.core.model.ForwardMode
import ir.smsforwardmanager.core.model.RuleDeliveryMode
import ir.smsforwardmanager.core.util.RuleMatcher
import ir.smsforwardmanager.data.local.relation.RuleWithDetails
import ir.smsforwardmanager.ui.components.ChoiceChips

private enum class RuleStatusFilter { ALL, ACTIVE, INACTIVE }

private fun requiredPermissionsFor(mode: DeliveryMode): Array<String> = buildList {
    add(Manifest.permission.RECEIVE_SMS)
    if (mode != DeliveryMode.INTERNET_ONLY) {
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.SEND_SMS)
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        add(Manifest.permission.POST_NOTIFICATIONS)
    }
}.toTypedArray()

@Composable
fun RulesScreen(
    onAddRule: () -> Unit,
    onEditRule: (Long) -> Unit,
    onViewLogs: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: RulesViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val requiredPermissions = remember(state.settings.deliveryMode) {
        requiredPermissionsFor(state.settings.deliveryMode)
    }
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var permissionsGranted by remember(state.settings.deliveryMode) { mutableStateOf(requiredPermissions.all {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { result -> permissionsGranted = requiredPermissions.all { result[it] == true } }
    DisposableEffect(lifecycleOwner, state.settings.deliveryMode) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permissionsGranted = requiredPermissions.all {
                    ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    var ruleToDelete by remember { mutableStateOf<RuleWithDetails?>(null) }
    var ruleToTest by remember { mutableStateOf<RuleWithDetails?>(null) }
    var confirmEnableForwarding by remember { mutableStateOf(false) }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var statusFilter by rememberSaveable { mutableStateOf(RuleStatusFilter.ALL) }
    var filtersExpanded by rememberSaveable { mutableStateOf(false) }
    val visibleRules = remember(state.rules, searchQuery, statusFilter) {
        val normalizedQuery = searchQuery.trim().lowercase()
        state.rules
            .filter { details ->
                val matchesQuery = normalizedQuery.isEmpty() ||
                    details.rule.name.lowercase().contains(normalizedQuery) ||
                    details.rule.senderPattern.orEmpty().lowercase().contains(normalizedQuery) ||
                    details.keywords.any { it.value.lowercase().contains(normalizedQuery) } ||
                    details.destinationLinks.any {
                        it.destination.label.lowercase().contains(normalizedQuery) ||
                            it.destination.phoneNumber.contains(normalizedQuery)
                    }
                val matchesStatus = when (statusFilter) {
                    RuleStatusFilter.ALL -> true
                    RuleStatusFilter.ACTIVE -> details.rule.isEnabled
                    RuleStatusFilter.INACTIVE -> !details.rule.isEnabled
                }
                matchesQuery && matchesStatus
            }
            .sortedWith(
                compareByDescending<RuleWithDetails> { it.rule.priority }
                    .thenBy { it.rule.name.lowercase() },
            )
    }
    Box(modifier = modifier.fillMaxSize()) {
        if (state.isLoading) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 112.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.rules_title), style = MaterialTheme.typography.headlineMedium)
                            Text(
                                stringResource(R.string.rules_subtitle),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        AssistChip(
                            onClick = {},
                            label = {
                                Text(
                                    stringResource(
                                        when (state.settings.deliveryMode) {
                                            DeliveryMode.SMS_ONLY -> R.string.delivery_sms_only_short
                                            DeliveryMode.INTERNET_ONLY -> R.string.delivery_internet_only_short
                                            DeliveryMode.INTERNET_THEN_SMS,
                                            DeliveryMode.SMART,
                                            DeliveryMode.SMS_THEN_INTERNET -> R.string.delivery_sms_and_internet
                                        },
                                    ),
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    if (state.settings.deliveryMode == DeliveryMode.SMS_ONLY) {
                                        Icons.Outlined.Lock
                                    } else {
                                        Icons.Outlined.Cloud
                                    },
                                    contentDescription = null,
                                )
                            },
                        )
                    }
                }
                item {
                    MasterForwardingCard(
                        enabled = state.settings.masterForwardingEnabled,
                        onEnabledChange = { enabled ->
                            if (enabled) confirmEnableForwarding = true else viewModel.setMasterEnabled(false)
                        },
                    )
                }
                item {
                    PermissionCard(
                        granted = permissionsGranted,
                        onGrant = { permissionLauncher.launch(requiredPermissions) },
                    )
                }
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().animateContentSize(),
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    modifier = Modifier.weight(1f).heightIn(min = 50.dp),
                                    placeholder = { Text(stringResource(R.string.search_conditions_compact)) },
                                    leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                                    trailingIcon = if (searchQuery.isNotBlank()) {
                                        {
                                            IconButton(onClick = { searchQuery = "" }) {
                                                Icon(Icons.Outlined.Close, contentDescription = stringResource(R.string.clear_search))
                                            }
                                        }
                                    } else null,
                                    singleLine = true,
                                    shape = MaterialTheme.shapes.extraLarge,
                                )
                                IconButton(onClick = { filtersExpanded = !filtersExpanded }) {
                                    Icon(
                                        Icons.Outlined.Tune,
                                        contentDescription = stringResource(R.string.search_filters),
                                        tint = if (filtersExpanded) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                    )
                                }
                            }
                            AnimatedVisibility(visible = filtersExpanded) {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    ChoiceChips(
                                        options = listOf(
                                            RuleStatusFilter.ALL to stringResource(R.string.filter_all_rules),
                                            RuleStatusFilter.ACTIVE to stringResource(R.string.active),
                                            RuleStatusFilter.INACTIVE to stringResource(R.string.inactive),
                                        ),
                                        selected = statusFilter,
                                        onSelected = { statusFilter = it },
                                    )
                                }
                            }
                        }
                    }
                }
                if (state.rules.isEmpty()) {
                    item { EmptyRulesCard(onAddRule) }
                } else if (visibleRules.isEmpty()) {
                    item { NoMatchingRulesCard() }
                } else {
                    items(visibleRules, key = { it.rule.id }) { details ->
                        RuleCard(
                            details = details,
                            deliveryMode = state.settings.deliveryMode,
                            onToggle = { viewModel.setRuleEnabled(details.rule.id, it) },
                            onEdit = { onEditRule(details.rule.id) },
                            onCopy = {
                                viewModel.duplicateRule(
                                    details,
                                    context.getString(R.string.rule_copy_name, details.rule.name),
                                )
                            },
                            onTest = { ruleToTest = details },
                            onViewLogs = onViewLogs,
                            onDelete = { ruleToDelete = details },
                        )
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            onClick = onAddRule,
            icon = { Icon(Icons.Outlined.Add, contentDescription = null) },
            text = { Text(stringResource(R.string.add_rule)) },
        )
    }



    if (confirmEnableForwarding) {
        AlertDialog(
            onDismissRequest = { confirmEnableForwarding = false },
            title = { Text(stringResource(R.string.forwarding_consent_title)) },
            text = { Text(stringResource(R.string.forwarding_consent_text)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmEnableForwarding = false
                    viewModel.setMasterEnabled(true)
                }) { Text(stringResource(R.string.forwarding_consent_accept)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmEnableForwarding = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }

    ruleToTest?.let { details ->
        RuleTestDialog(
            details = details,
            onDismiss = { ruleToTest = null },
        )
    }

    ruleToDelete?.let { details ->
        AlertDialog(
            onDismissRequest = { ruleToDelete = null },
            title = { Text(stringResource(R.string.delete_rule_question, details.rule.name)) },
            text = { Text(stringResource(R.string.delete_rule_desc)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteRule(details.rule.id)
                    ruleToDelete = null
                }) { Text(stringResource(R.string.delete_rule)) }
            },
            dismissButton = {
                TextButton(onClick = { ruleToDelete = null }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun MasterForwardingCard(enabled: Boolean, onEnabledChange: (Boolean) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (enabled) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceContainerHigh,
        ),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = if (enabled) Icons.Outlined.CheckCircle else Icons.Outlined.PauseCircle,
                contentDescription = null,
                tint = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.master_title), style = MaterialTheme.typography.titleMedium)
                Text(
                    stringResource(if (enabled) R.string.master_on_desc else R.string.master_off_desc),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Switch(checked = enabled, onCheckedChange = onEnabledChange)
        }
    }
}

@Composable
private fun PermissionCard(granted: Boolean, onGrant: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.Sms, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Column(modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.permissions_title), style = MaterialTheme.typography.titleSmall)
                Text(
                    stringResource(if (granted) R.string.permissions_granted else R.string.permissions_missing),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (!granted) Button(onClick = onGrant) { Text(stringResource(R.string.grant_permissions)) }
        }
    }
}

@Composable
private fun EmptyRulesCard(onAddRule: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Icons.Outlined.Sms, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.no_rules_title), style = MaterialTheme.typography.titleMedium)
            Text(
                stringResource(R.string.no_rules_desc),
                modifier = Modifier.padding(top = 6.dp),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(onClick = onAddRule, modifier = Modifier.padding(top = 16.dp)) {
                Text(stringResource(R.string.add_rule))
            }
        }
    }
}

@Composable
private fun NoMatchingRulesCard() {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Text(
            stringResource(R.string.no_matching_rules),
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun RuleTestDialog(
    details: RuleWithDetails,
    onDismiss: () -> Unit,
) {
    var sender by rememberSaveable(details.rule.id) { mutableStateOf("") }
    var message by rememberSaveable(details.rule.id) { mutableStateOf("") }
    var result by remember(details.rule.id) { mutableStateOf<Boolean?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.test_rule_title, details.rule.name)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    stringResource(R.string.test_rule_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = sender,
                    onValueChange = {
                        sender = it
                        result = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.test_sender)) },
                    singleLine = true,
                )
                OutlinedTextField(
                    value = message,
                    onValueChange = {
                        message = it
                        result = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.test_message)) },
                    minLines = 3,
                )
                result?.let { matches ->
                    Text(
                        text = stringResource(
                            if (matches) R.string.rule_test_matches else R.string.rule_test_no_match,
                        ),
                        color = if (matches) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.error
                        },
                        style = MaterialTheme.typography.titleSmall,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = message.isNotBlank(),
                onClick = {
                    result = RuleMatcher.matches(
                        ruleDetails = details,
                        sender = sender,
                        message = message,
                    )
                },
            ) { Text(stringResource(R.string.run_test)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) }
        },
    )
}

@Composable
private fun RuleCard(
    details: RuleWithDetails,
    deliveryMode: DeliveryMode,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onCopy: () -> Unit,
    onTest: () -> Unit,
    onViewLogs: () -> Unit,
    onDelete: () -> Unit,
) {
    val rule = details.rule
    var expanded by rememberSaveable(rule.id) { mutableStateOf(false) }
    val senderText = stringResource(
        R.string.sender_summary,
        rule.senderPattern ?: stringResource(R.string.any_sender),
    )
    val destinationText = pluralStringResource(
        R.plurals.destination_count,
        details.destinationLinks.size,
        details.destinationLinks.size,
    )
    val keywordText = pluralStringResource(
        R.plurals.keyword_count,
        details.keywords.size,
        details.keywords.size,
    )
    val contentModeText = stringResource(
        if (rule.forwardMode == ForwardMode.FULL_MESSAGE) R.string.full_message else R.string.otp_only,
    )
    val effectiveDeliveryMode = when (rule.deliveryModeOverride) {
        RuleDeliveryMode.USE_GLOBAL -> deliveryMode
        RuleDeliveryMode.SMS_ONLY -> DeliveryMode.SMS_ONLY
        RuleDeliveryMode.INTERNET_ONLY -> DeliveryMode.INTERNET_ONLY
        RuleDeliveryMode.INTERNET_THEN_SMS -> DeliveryMode.INTERNET_THEN_SMS
        RuleDeliveryMode.SMS_THEN_INTERNET -> DeliveryMode.SMS_THEN_INTERNET
    }
    val deliveryText = stringResource(
        when (effectiveDeliveryMode) {
            DeliveryMode.SMS_ONLY -> R.string.delivery_sms_only_short
            DeliveryMode.INTERNET_ONLY -> R.string.delivery_internet_only_short
            DeliveryMode.INTERNET_THEN_SMS,
            DeliveryMode.SMART,
            DeliveryMode.SMS_THEN_INTERNET -> R.string.delivery_sms_and_internet
        },
    )
    val statusText = stringResource(if (rule.isEnabled) R.string.active else R.string.inactive)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clickable { expanded = !expanded },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        rule.name,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        "$statusText • $deliveryText",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (rule.isEnabled) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                    )
                }
                Switch(checked = rule.isEnabled, onCheckedChange = onToggle)
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        if (expanded) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                        contentDescription = stringResource(
                            if (expanded) R.string.rule_collapse else R.string.rule_expand,
                        ),
                    )
                }
            }

            Text(
                "$senderText • $destinationText • $contentModeText",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )

            if (expanded) {
                HorizontalDivider(modifier = Modifier.padding(top = 4.dp))
                Text(
                    "$keywordText • $deliveryText",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.Start,
                ) {
                    TextButton(onClick = onTest) {
                        Icon(Icons.Outlined.Science, contentDescription = null)
                        Text(stringResource(R.string.test_rule), modifier = Modifier.padding(start = 6.dp))
                    }
                    TextButton(onClick = onViewLogs) {
                        Icon(Icons.Outlined.History, contentDescription = null)
                        Text(stringResource(R.string.view_reports), modifier = Modifier.padding(start = 6.dp))
                    }
                    TextButton(onClick = onEdit) {
                        Icon(Icons.Outlined.Edit, contentDescription = null)
                        Text(stringResource(R.string.edit_rule), modifier = Modifier.padding(start = 6.dp))
                    }
                    TextButton(onClick = onCopy) {
                        Icon(Icons.Outlined.ContentCopy, contentDescription = null)
                        Text(stringResource(R.string.copy_rule), modifier = Modifier.padding(start = 6.dp))
                    }
                    TextButton(onClick = onDelete) {
                        Icon(Icons.Outlined.Delete, contentDescription = null)
                        Text(stringResource(R.string.delete_rule), modifier = Modifier.padding(start = 6.dp))
                    }
                }
            }
        }
    }
}
