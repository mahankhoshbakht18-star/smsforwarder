package ir.smsforwardmanager.data.local.relation

import ir.smsforwardmanager.core.model.DeliveryMethod
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.core.model.ForwardStatus

data class ForwardLogRow(
    val attemptId: Long,
    val messageId: Long,
    val ruleId: Long?,
    val ruleName: String?,
    val receivedAt: Long,
    val sender: String,
    val originalMessage: String,
    val destination: String,
    val forwardedMessage: String,
    val deliveryMode: DeliveryMode,
    val deliveredVia: DeliveryMethod?,
    val remoteReference: String?,
    val status: ForwardStatus,
    val attemptCount: Int,
    val partCount: Int,
    val sentPartCount: Int,
    val deliveredPartCount: Int,
    val errorCode: Int?,
    val errorMessage: String?,
    val queuedAt: Long,
    val sentAt: Long?,
    val deliveredAt: Long?,
)
