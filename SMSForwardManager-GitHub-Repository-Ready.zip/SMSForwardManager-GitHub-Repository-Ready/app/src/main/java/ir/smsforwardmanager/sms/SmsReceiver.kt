package ir.smsforwardmanager.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import android.telephony.SubscriptionManager
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isEmpty()) return

        val sender = messages.firstNotNullOfOrNull { it.originatingAddress }.orEmpty()
        val body = messages.joinToString(separator = "") { it.messageBody.orEmpty() }
        if (sender.isBlank() || body.isBlank()) return

        val subscriptionId = intent.getIntExtra(
            SubscriptionManager.EXTRA_SUBSCRIPTION_INDEX,
            SubscriptionManager.INVALID_SUBSCRIPTION_ID,
        ).takeIf(SubscriptionManager::isValidSubscriptionId)
        val slotIndex = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            intent.getIntExtra(
                SubscriptionManager.EXTRA_SLOT_INDEX,
                SubscriptionManager.INVALID_SIM_SLOT_INDEX,
            ).takeIf { it != SubscriptionManager.INVALID_SIM_SLOT_INDEX }
        } else {
            null
        }

        val work = OneTimeWorkRequestBuilder<IncomingSmsWorker>()
            .setInputData(
                Data.Builder()
                    .putString(IncomingSmsWorker.KEY_SENDER, sender)
                    .putString(IncomingSmsWorker.KEY_BODY, body)
                    .putLong(IncomingSmsWorker.KEY_RECEIVED_AT, messages.minOf { it.timestampMillis })
                    .putInt(
                        IncomingSmsWorker.KEY_SUBSCRIPTION_ID,
                        subscriptionId ?: SubscriptionManager.INVALID_SUBSCRIPTION_ID,
                    )
                    .putInt(
                        IncomingSmsWorker.KEY_SIM_SLOT_INDEX,
                        slotIndex ?: SubscriptionManager.INVALID_SIM_SLOT_INDEX,
                    )
                    .build(),
            )
            .addTag("incoming-sms")
            .build()

        WorkManager.getInstance(context).enqueue(work)
    }
}
