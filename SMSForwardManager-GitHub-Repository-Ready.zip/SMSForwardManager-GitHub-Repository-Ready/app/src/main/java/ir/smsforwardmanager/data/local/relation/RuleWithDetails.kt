package ir.smsforwardmanager.data.local.relation

import androidx.room.Embedded
import androidx.room.Relation
import ir.smsforwardmanager.data.local.entity.DestinationEntity
import ir.smsforwardmanager.data.local.entity.RuleDestinationCrossRef
import ir.smsforwardmanager.data.local.entity.RuleEntity
import ir.smsforwardmanager.data.local.entity.RuleKeywordEntity

data class RuleDestinationWithDestination(
    @Embedded
    val link: RuleDestinationCrossRef,
    @Relation(
        parentColumn = "destination_id",
        entityColumn = "id",
    )
    val destination: DestinationEntity,
)

data class RuleWithDetails(
    @Embedded
    val rule: RuleEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "rule_id",
    )
    val keywords: List<RuleKeywordEntity>,
    @Relation(
        entity = RuleDestinationCrossRef::class,
        parentColumn = "id",
        entityColumn = "rule_id",
    )
    val destinationLinks: List<RuleDestinationWithDestination>,
)

