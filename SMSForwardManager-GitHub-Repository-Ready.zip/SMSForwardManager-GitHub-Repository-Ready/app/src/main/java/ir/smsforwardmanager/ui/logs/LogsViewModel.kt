package ir.smsforwardmanager.ui.logs

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.smsforwardmanager.data.local.relation.ForwardLogRow
import ir.smsforwardmanager.data.repository.LogRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface LogsEvent {
    data class Exported(val count: Int) : LogsEvent
    data object ExportFailed : LogsEvent
}

@HiltViewModel
class LogsViewModel @Inject constructor(
    private val repository: LogRepository,
) : ViewModel() {
    private val _events = MutableSharedFlow<LogsEvent>()
    val events: SharedFlow<LogsEvent> = _events.asSharedFlow()
    val logs: StateFlow<List<ForwardLogRow>> = repository.observeLogs().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList(),
    )

    fun export(uri: Uri) {
        viewModelScope.launch {
            runCatching { repository.export(uri) }
                .onSuccess { _events.emit(LogsEvent.Exported(it)) }
                .onFailure { _events.emit(LogsEvent.ExportFailed) }
        }
    }

    fun clear() {
        viewModelScope.launch { repository.clear() }
    }

    fun retry(attemptId: Long) {
        viewModelScope.launch { repository.retry(attemptId) }
    }

    fun remove(attemptId: Long) {
        viewModelScope.launch { repository.remove(attemptId) }
    }

    fun cancel(attemptId: Long) {
        viewModelScope.launch { repository.cancel(attemptId) }
    }
}
