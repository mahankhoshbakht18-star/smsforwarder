package ir.smsforwardmanager.sms

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import dagger.hilt.android.qualifiers.ApplicationContext
import ir.smsforwardmanager.core.model.DeliveryMethod
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.data.local.dao.ForwardAttemptDao
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ForwardingScheduler @Inject constructor(
    @ApplicationContext context: Context,
    private val attemptDao: ForwardAttemptDao,
) {
    private val workManager = WorkManager.getInstance(context)

    suspend fun enqueue(attemptId: Long) {
        enqueueInternal(attemptId, forcedMethod = null)
    }

    suspend fun enqueueInternetFallback(attemptId: Long) {
        enqueueInternal(attemptId, forcedMethod = DeliveryMethod.INTERNET)
    }

    suspend fun enqueueRetry(attemptId: Long, delaySeconds: Long) {
        val attempt = attemptDao.getById(attemptId) ?: return
        val request = OneTimeWorkRequestBuilder<ForwardingWorker>()
            .setInputData(
                Data.Builder()
                    .putLong(ForwardingWorker.KEY_ATTEMPT_ID, attemptId)
                    .build(),
            )
            .setInitialDelay(delaySeconds.coerceIn(10, 86_400), TimeUnit.SECONDS)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag("sms-forward-$attemptId")
            .build()
        attemptDao.markEnqueued(attemptId = attemptId, workRequestId = request.id.toString())
        workManager.enqueueUniqueWork(
            "sms-forward-$attemptId-retry",
            ExistingWorkPolicy.REPLACE,
            request,
        )
    }

    fun cancel(attemptId: Long) {
        workManager.cancelAllWorkByTag("sms-forward-$attemptId")
        workManager.cancelUniqueWork("sms-forward-$attemptId")
        workManager.cancelUniqueWork("sms-forward-$attemptId-internet")
        workManager.cancelUniqueWork("sms-forward-$attemptId-sms")
        workManager.cancelUniqueWork("sms-forward-$attemptId-retry")
        workManager.cancelUniqueWork("sms-delivery-timeout-$attemptId")
    }

    fun enqueueDeliveryTimeout(attemptId: Long, timeoutHours: Long = DELIVERY_TIMEOUT_HOURS) {
        val request = OneTimeWorkRequestBuilder<DeliveryReportTimeoutWorker>()
            .setInputData(
                Data.Builder()
                    .putLong(DeliveryReportTimeoutWorker.KEY_ATTEMPT_ID, attemptId)
                    .build(),
            )
            .setInitialDelay(timeoutHours.coerceAtLeast(1), TimeUnit.HOURS)
            .addTag("sms-delivery-timeout-$attemptId")
            .build()
        workManager.enqueueUniqueWork(
            "sms-delivery-timeout-$attemptId",
            ExistingWorkPolicy.KEEP,
            request,
        )
    }

    private suspend fun enqueueInternal(attemptId: Long, forcedMethod: DeliveryMethod?) {
        val attempt = attemptDao.getById(attemptId) ?: return
        val input = Data.Builder()
            .putLong(ForwardingWorker.KEY_ATTEMPT_ID, attemptId)
            .apply {
                forcedMethod?.let { putString(ForwardingWorker.KEY_FORCE_METHOD, it.name) }
            }
            .build()

        val requestBuilder = OneTimeWorkRequestBuilder<ForwardingWorker>()
            .setInputData(input)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .addTag("sms-forward-$attemptId")

        if (attempt.deliveryMode == DeliveryMode.INTERNET_ONLY || forcedMethod == DeliveryMethod.INTERNET) {
            requestBuilder.setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build(),
            )
        }

        val request = requestBuilder.build()
        attemptDao.markEnqueued(attemptId = attemptId, workRequestId = request.id.toString())
        val uniqueName = if (forcedMethod == null) {
            "sms-forward-$attemptId"
        } else {
            "sms-forward-$attemptId-${forcedMethod.name.lowercase()}"
        }
        workManager.enqueueUniqueWork(uniqueName, ExistingWorkPolicy.KEEP, request)
    }

    private companion object {
        const val DELIVERY_TIMEOUT_HOURS = 24L
    }
}
