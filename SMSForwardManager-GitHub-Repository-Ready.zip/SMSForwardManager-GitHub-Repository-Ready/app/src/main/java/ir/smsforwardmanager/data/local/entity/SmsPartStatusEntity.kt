package ir.smsforwardmanager.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import ir.smsforwardmanager.core.model.SmsPartDeliveryStatus
import ir.smsforwardmanager.core.model.SmsPartSentStatus

@Entity(
    tableName = "sms_part_status",
    primaryKeys = ["attempt_id", "part_index"],
    foreignKeys = [
        ForeignKey(
            entity = ForwardAttemptEntity::class,
            parentColumns = ["id"],
            childColumns = ["attempt_id"],
            onDelete = ForeignKey.CASCADE,
            onUpdate = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["attempt_id"])],
)
data class SmsPartStatusEntity(
    @ColumnInfo(name = "attempt_id")
    val attemptId: Long,
    @ColumnInfo(name = "part_index")
    val partIndex: Int,
    @ColumnInfo(name = "total_parts")
    val totalParts: Int,
    @ColumnInfo(name = "sent_status")
    val sentStatus: SmsPartSentStatus = SmsPartSentStatus.PENDING,
    @ColumnInfo(name = "delivery_status")
    val deliveryStatus: SmsPartDeliveryStatus = SmsPartDeliveryStatus.PENDING,
    @ColumnInfo(name = "sent_result_code")
    val sentResultCode: Int? = null,
    @ColumnInfo(name = "delivery_status_code")
    val deliveryStatusCode: Int? = null,
    @ColumnInfo(name = "sent_at")
    val sentAt: Long? = null,
    @ColumnInfo(name = "delivered_at")
    val deliveredAt: Long? = null,
    @ColumnInfo(name = "last_error")
    val lastError: String? = null,
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis(),
)
