package ir.smsforwardmanager.sms

import android.app.Activity
import androidx.room.withTransaction
import ir.smsforwardmanager.core.model.ForwardStatus
import ir.smsforwardmanager.data.local.SmsForwardDatabase
import ir.smsforwardmanager.data.local.entity.ForwardAttemptEntity
import ir.smsforwardmanager.data.local.entity.SmsPartStatusEntity
import ir.smsforwardmanager.data.local.relation.SmsPartAggregate
import javax.inject.Inject
import javax.inject.Singleton

enum class DeliveryReportOutcome {
    DELIVERED,
    PENDING,
    FAILED,
    UNKNOWN,
}

data class SmsPartUpdate(
    val attempt: ForwardAttemptEntity,
    val aggregate: SmsPartAggregate,
    val changed: Boolean,
)

/**
 * Applies sent/delivery broadcasts transactionally and idempotently.
 * The (attemptId, partIndex) primary key plus conditional updates prevents duplicate broadcasts
 * from incrementing counters more than once.
 */
@Singleton
class SmsDeliveryTracker @Inject constructor(
    private val database: SmsForwardDatabase,
) {
    private val attemptDao get() = database.forwardAttemptDao()
    private val partDao get() = database.smsPartStatusDao()

    suspend fun initializeAttempt(attemptId: Long, totalParts: Int) {
        val safeTotal = totalParts.coerceAtLeast(1)
        database.withTransaction {
            partDao.deleteForAttempt(attemptId)
            partDao.insertAll(
                List(safeTotal) { index ->
                    SmsPartStatusEntity(
                        attemptId = attemptId,
                        partIndex = index,
                        totalParts = safeTotal,
                    )
                },
            )
            attemptDao.getById(attemptId)?.let { attempt ->
                attemptDao.update(
                    attempt.copy(
                        partCount = safeTotal,
                        sentPartCount = 0,
                        deliveredPartCount = 0,
                        status = ForwardStatus.SENDING,
                        errorCode = null,
                        errorMessage = null,
                        updatedAt = System.currentTimeMillis(),
                    ),
                )
            }
        }
    }

    suspend fun recordSent(
        attemptId: Long,
        partIndex: Int,
        resultCode: Int,
        successful: Boolean,
        errorKey: String? = null,
    ): SmsPartUpdate? = database.withTransaction {
        val now = System.currentTimeMillis()
        val changed = if (successful) {
            partDao.markSent(attemptId, partIndex, resultCode, now)
        } else {
            partDao.markSentFailed(
                attemptId = attemptId,
                partIndex = partIndex,
                resultCode = resultCode,
                errorKey = errorKey ?: SmsResultKeys.UNKNOWN,
                eventAt = now,
            )
        }
        updateParent(attemptId, now, errorKey).copy(changed = changed > 0)
    }

    suspend fun recordDelivery(
        attemptId: Long,
        partIndex: Int,
        outcome: DeliveryReportOutcome,
        statusCode: Int?,
    ): SmsPartUpdate? = database.withTransaction {
        val now = System.currentTimeMillis()

        // A delivery status report proves that the network accepted this part even if the sent
        // broadcast was delayed or lost by the device firmware.
        if (outcome != DeliveryReportOutcome.PENDING) {
            partDao.markSent(attemptId, partIndex, Activity.RESULT_OK, now)
        }

        val changed = when (outcome) {
            DeliveryReportOutcome.DELIVERED ->
                partDao.markDelivered(attemptId, partIndex, statusCode, now)

            DeliveryReportOutcome.PENDING -> 0

            DeliveryReportOutcome.FAILED ->
                partDao.markDeliveryFailed(
                    attemptId,
                    partIndex,
                    statusCode,
                    SmsResultKeys.DELIVERY_FAILED,
                    now,
                )

            DeliveryReportOutcome.UNKNOWN ->
                partDao.markDeliveryUnknown(attemptId, partIndex, statusCode, now)
        }
        val error = if (outcome == DeliveryReportOutcome.FAILED) {
            SmsResultKeys.DELIVERY_FAILED
        } else {
            null
        }
        updateParent(attemptId, now, error).copy(changed = changed > 0)
    }

    suspend fun markTimedOut(attemptId: Long): SmsPartUpdate? = database.withTransaction {
        val attempt = attemptDao.getById(attemptId) ?: return@withTransaction null
        if (attempt.status != ForwardStatus.SENT_WAITING_DELIVERY) {
            return@withTransaction SmsPartUpdate(
                attempt = attempt,
                aggregate = partDao.aggregate(attemptId),
                changed = false,
            )
        }
        val now = System.currentTimeMillis()
        val changed = partDao.markAllPendingDeliveryUnknown(attemptId, now)
        updateParent(attemptId, now, latestError = null).copy(changed = changed > 0)
    }

    private suspend fun updateParent(
        attemptId: Long,
        now: Long,
        latestError: String?,
    ): SmsPartUpdate {
        val attempt = requireNotNull(attemptDao.getById(attemptId))
        val aggregate = partDao.aggregate(attemptId)
        val total = aggregate.totalParts.coerceAtLeast(attempt.partCount.coerceAtLeast(1))
        val sentResolved = aggregate.sentParts + aggregate.failedSentParts
        val deliveryResolved = aggregate.deliveredParts +
            aggregate.failedDeliveryParts + aggregate.unknownDeliveryParts

        val status = when {
            attempt.status == ForwardStatus.CANCELLED -> ForwardStatus.CANCELLED
            aggregate.deliveredParts >= total -> ForwardStatus.DELIVERED
            aggregate.failedSentParts > 0 && sentResolved >= total -> {
                if (aggregate.sentParts > 0) ForwardStatus.PARTIALLY_FAILED else ForwardStatus.FAILED
            }
            aggregate.failedDeliveryParts > 0 && deliveryResolved >= total ->
                ForwardStatus.PARTIALLY_FAILED
            aggregate.unknownDeliveryParts > 0 && deliveryResolved >= total ->
                ForwardStatus.SENT_DELIVERY_UNKNOWN
            aggregate.sentParts >= total -> ForwardStatus.SENT_WAITING_DELIVERY
            else -> ForwardStatus.SENDING
        }

        val errorKey = when {
            status == ForwardStatus.FAILED || status == ForwardStatus.PARTIALLY_FAILED ->
                latestError ?: attempt.errorMessage
            else -> null
        }

        val updated = attempt.copy(
            partCount = total,
            sentPartCount = aggregate.sentParts.coerceAtMost(total),
            deliveredPartCount = aggregate.deliveredParts.coerceAtMost(total),
            status = status,
            sentAt = if (aggregate.sentParts >= total) attempt.sentAt ?: now else attempt.sentAt,
            deliveredAt = if (aggregate.deliveredParts >= total) attempt.deliveredAt ?: now else attempt.deliveredAt,
            errorCode = if (errorKey == null) null else attempt.errorCode,
            errorMessage = errorKey,
            updatedAt = now,
        )
        attemptDao.update(updated)
        return SmsPartUpdate(updated, aggregate, changed = false)
    }
}
