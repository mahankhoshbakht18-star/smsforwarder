package ir.smsforwardmanager.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import ir.smsforwardmanager.data.local.entity.RuleDestinationCrossRef
import ir.smsforwardmanager.data.local.relation.RuleDestinationWithDestination
import kotlinx.coroutines.flow.Flow

@Dao
interface RuleDestinationDao {
    @Transaction
    @Query(
        """
        SELECT * FROM rule_destinations
        WHERE rule_id = :ruleId
        ORDER BY sort_order, destination_id
        """,
    )
    fun observeForRule(ruleId: Long): Flow<List<RuleDestinationWithDestination>>

    @Transaction
    @Query(
        """
        SELECT * FROM rule_destinations
        WHERE rule_id = :ruleId AND is_enabled = 1
        ORDER BY sort_order, destination_id
        """,
    )
    suspend fun getEnabledForRule(ruleId: Long): List<RuleDestinationWithDestination>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(links: List<RuleDestinationCrossRef>)

    @Query("DELETE FROM rule_destinations WHERE rule_id = :ruleId")
    suspend fun deleteForRule(ruleId: Long): Int

    @Query(
        """
        UPDATE rule_destinations
        SET is_enabled = :enabled
        WHERE rule_id = :ruleId AND destination_id = :destinationId
        """,
    )
    suspend fun setEnabled(ruleId: Long, destinationId: Long, enabled: Boolean): Int
}

