package ir.smsforwardmanager.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.smsforwardmanager.core.model.ForwardMode
import ir.smsforwardmanager.core.model.KeywordLogic
import ir.smsforwardmanager.core.model.MatchMode
import ir.smsforwardmanager.core.model.RuleDeliveryMode
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "rules",
    indices = [
        Index(value = ["is_enabled", "priority"]),
        Index(value = ["updated_at"]),
    ],
)
data class RuleEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0,
    @ColumnInfo(name = "name")
    val name: String,
    @ColumnInfo(name = "is_enabled")
    val isEnabled: Boolean = true,
    @ColumnInfo(name = "priority")
    val priority: Int = 0,
    @ColumnInfo(name = "sender_pattern")
    val senderPattern: String? = null,
    @ColumnInfo(name = "sender_match_mode")
    val senderMatchMode: MatchMode = MatchMode.EXACT,
    @ColumnInfo(name = "keyword_match_mode")
    val keywordMatchMode: MatchMode = MatchMode.CONTAINS,
    @ColumnInfo(name = "keyword_logic")
    val keywordLogic: KeywordLogic = KeywordLogic.ANY,
    @ColumnInfo(name = "forward_mode")
    val forwardMode: ForwardMode = ForwardMode.FULL_MESSAGE,
    @ColumnInfo(name = "otp_regex")
    val otpRegex: String? = null,
    @ColumnInfo(name = "is_case_sensitive")
    val isCaseSensitive: Boolean = false,
    @ColumnInfo(name = "subscription_id")
    val subscriptionId: Int? = null,
    @ColumnInfo(name = "stop_after_match")
    val stopAfterMatch: Boolean = false,
    @ColumnInfo(name = "allow_sensitive_content", defaultValue = "0")
    val allowSensitiveContent: Boolean = false,
    @ColumnInfo(name = "excluded_keywords", defaultValue = "'[]'")
    val excludedKeywords: List<String> = emptyList(),
    @ColumnInfo(name = "delivery_mode_override", defaultValue = "'USE_GLOBAL'")
    val deliveryModeOverride: RuleDeliveryMode = RuleDeliveryMode.USE_GLOBAL,
    @ColumnInfo(name = "active_days_mask", defaultValue = "127")
    val activeDaysMask: Int = 127,
    @ColumnInfo(name = "active_start_minute")
    val activeStartMinute: Int? = null,
    @ColumnInfo(name = "active_end_minute")
    val activeEndMinute: Int? = null,
    @ColumnInfo(name = "max_forwards_per_day", defaultValue = "0")
    val maxForwardsPerDay: Int = 0,
    @ColumnInfo(name = "prepend_text", defaultValue = "''")
    val prependText: String = "",
    @ColumnInfo(name = "append_text", defaultValue = "''")
    val appendText: String = "",
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis(),
)

