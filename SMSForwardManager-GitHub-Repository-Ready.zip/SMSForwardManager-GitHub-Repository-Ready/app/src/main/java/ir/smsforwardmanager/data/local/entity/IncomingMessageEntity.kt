package ir.smsforwardmanager.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.smsforwardmanager.core.model.MessageProcessingState
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "incoming_messages",
    indices = [
        Index(value = ["fingerprint"], unique = true),
        Index(value = ["received_at"]),
        Index(value = ["processing_state"]),
    ],
)
data class IncomingMessageEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0,
    @ColumnInfo(name = "fingerprint")
    val fingerprint: String,
    @ColumnInfo(name = "sender")
    val sender: String,
    @ColumnInfo(name = "normalized_sender")
    val normalizedSender: String,
    @ColumnInfo(name = "body")
    val body: String,
    @ColumnInfo(name = "received_at")
    val receivedAt: Long,
    @ColumnInfo(name = "subscription_id")
    val subscriptionId: Int? = null,
    @ColumnInfo(name = "sim_slot_index")
    val simSlotIndex: Int? = null,
    @ColumnInfo(name = "matched_rule_count")
    val matchedRuleCount: Int = 0,
    @ColumnInfo(name = "processing_state")
    val processingState: MessageProcessingState = MessageProcessingState.RECEIVED,
    @ColumnInfo(name = "error_message")
    val errorMessage: String? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis(),
)

