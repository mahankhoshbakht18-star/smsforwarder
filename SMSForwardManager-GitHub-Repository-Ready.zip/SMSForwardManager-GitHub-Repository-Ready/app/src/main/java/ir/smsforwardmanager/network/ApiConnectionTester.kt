package ir.smsforwardmanager.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

sealed interface ApiConnectionTestResult {
    data class Reachable(val httpStatus: Int) : ApiConnectionTestResult
    data object Unauthorized : ApiConnectionTestResult
    data object Failed : ApiConnectionTestResult
}

@Singleton
class ApiConnectionTester @Inject constructor(
    private val baseHttpClient: OkHttpClient,
) {
    suspend fun test(
        endpoint: String,
        token: String,
        connectTimeoutSeconds: Int,
        readTimeoutSeconds: Int,
    ): ApiConnectionTestResult = withContext(Dispatchers.IO) {
        val normalizedEndpoint = endpoint.trim()
        if (!SecureEndpointValidator.isValid(normalizedEndpoint)) {
            return@withContext ApiConnectionTestResult.Failed
        }
        val headers = buildMap {
            put("Accept", "application/json")
            token.trim().takeIf(String::isNotEmpty)?.let { value ->
                put("Authorization", "Bearer $value")
            }
        }
        try {
            val client = baseHttpClient.newBuilder()
                .connectTimeout(connectTimeoutSeconds.coerceIn(5, 60).toLong(), TimeUnit.SECONDS)
                .readTimeout(readTimeoutSeconds.coerceIn(5, 120).toLong(), TimeUnit.SECONDS)
                .build()
            val service = Retrofit.Builder()
                .baseUrl(RETROFIT_BASE_URL)
                .client(client)
                .build()
                .create(OnlineApiService::class.java)
            val response = service.probe(normalizedEndpoint, headers)
            response.body()?.close()
            response.errorBody()?.close()
            when (val status = response.code()) {
                401, 403 -> ApiConnectionTestResult.Unauthorized
                else -> ApiConnectionTestResult.Reachable(status)
            }
        } catch (_: Exception) {
            ApiConnectionTestResult.Failed
        }
    }

    private companion object {
        const val RETROFIT_BASE_URL = "https://example.invalid/"
    }
}
