package ir.smsforwardmanager.ui.remote

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.smsforwardmanager.R
import ir.smsforwardmanager.remote.customer.RemoteJoinInput
import ir.smsforwardmanager.remote.customer.RemoteSession
import ir.smsforwardmanager.remote.customer.ScreenShareService
import ir.smsforwardmanager.remote.customer.ShareSessionState
import ir.smsforwardmanager.remote.customer.ShareUiState
import ir.smsforwardmanager.ui.components.SectionCard

@Composable
fun RemoteAssistScreen(
    joinInput: RemoteJoinInput,
    activityMessage: String?,
    onStartShare: (RemoteJoinInput) -> Unit,
    onServiceAction: (String) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: RemoteAssistViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val shareState by ShareSessionState.state.collectAsStateWithLifecycle()

    LaunchedEffect(joinInput) {
        viewModel.applyJoinInput(joinInput)
    }

    val shownMessage = activityMessage
        ?: state.error?.let { error ->
            if (error == RemoteAssistViewModel.ERROR_INVALID_SESSION) {
                stringResource(R.string.customer_remote_invalid_session)
            } else {
                stringResource(R.string.customer_remote_session_load_failed, error)
            }
        }
        ?: shareState.statusMessage

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = stringResource(R.string.customer_remote_title),
                    style = MaterialTheme.typography.headlineMedium,
                )
                Text(
                    text = stringResource(R.string.customer_remote_subtitle),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        item { CustomerWarningCard() }

        if (shareState.running) {
            item {
                ActiveShareCard(
                    state = shareState,
                    onServiceAction = onServiceAction,
                )
            }
        } else {
            item {
                SectionCard(
                    title = stringResource(R.string.customer_remote_join_section),
                    description = stringResource(R.string.customer_remote_join_desc),
                ) {
                    OutlinedTextField(
                        value = state.serverUrl,
                        onValueChange = viewModel::updateServerUrl,
                        label = { Text(stringResource(R.string.customer_remote_server_url)) },
                        placeholder = { Text("https://assist.example.com") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = state.token,
                        onValueChange = viewModel::updateToken,
                        label = { Text(stringResource(R.string.customer_remote_session_token)) },
                        visualTransformation = PasswordVisualTransformation(),
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Button(
                        onClick = viewModel::loadSession,
                        enabled = !state.loading && !state.acceptingConsent,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        if (state.loading) {
                            CircularProgressIndicator(modifier = Modifier.padding(2.dp))
                        } else {
                            Text(stringResource(R.string.customer_remote_load_session))
                        }
                    }
                }
            }

            state.session?.let { session ->
                item {
                    SessionConsentCard(
                        session = session,
                        state = state,
                        onScopeChange = viewModel::setConsentScope,
                        onControlChange = viewModel::setConsentControl,
                        onSecretChange = viewModel::setConsentSecret,
                        onSecureChange = viewModel::setConsentSecure,
                        onStart = {
                            viewModel.acceptConsent(onAccepted = onStartShare)
                        },
                    )
                }
            }
        }

        if (!shownMessage.isNullOrBlank()) {
            item {
                Text(
                    text = shownMessage,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}

@Composable
private fun CustomerWarningCard() {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
        ),
    ) {
        Text(
            text = stringResource(R.string.customer_remote_privacy_warning),
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            color = MaterialTheme.colorScheme.onTertiaryContainer,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun SessionConsentCard(
    session: RemoteSession,
    state: RemoteAssistUiState,
    onScopeChange: (Boolean) -> Unit,
    onControlChange: (Boolean) -> Unit,
    onSecretChange: (Boolean) -> Unit,
    onSecureChange: (Boolean) -> Unit,
    onStart: () -> Unit,
) {
    Card {
        Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = stringResource(R.string.customer_remote_consent_title),
                style = MaterialTheme.typography.titleLarge,
            )
            Text(
                text = stringResource(R.string.customer_remote_requester, session.requesterName),
                fontWeight = FontWeight.SemiBold,
            )
            Text(stringResource(R.string.customer_remote_purpose, session.purpose))
            Text(stringResource(R.string.customer_remote_session_code, session.code))
            Text(stringResource(R.string.customer_remote_expires, session.expiresAt))
            Text(stringResource(R.string.customer_remote_consent_intro))

            ConsentRow(
                text = stringResource(R.string.customer_remote_consent_scope),
                checked = state.consentScope,
                onCheckedChange = onScopeChange,
            )
            ConsentRow(
                text = stringResource(R.string.customer_remote_consent_control),
                checked = state.consentControl,
                onCheckedChange = onControlChange,
            )
            ConsentRow(
                text = stringResource(R.string.customer_remote_consent_secret),
                checked = state.consentSecret,
                onCheckedChange = onSecretChange,
            )
            ConsentRow(
                text = stringResource(R.string.customer_remote_consent_secure),
                checked = state.consentSecure,
                onCheckedChange = onSecureChange,
            )

            Button(
                onClick = onStart,
                enabled = !state.loading &&
                    !state.acceptingConsent &&
                    state.consentScope &&
                    state.consentControl &&
                    state.consentSecret &&
                    state.consentSecure,
                modifier = Modifier.fillMaxWidth(),
            ) {
                if (state.acceptingConsent) {
                    CircularProgressIndicator(modifier = Modifier.padding(2.dp))
                } else {
                    Text(stringResource(R.string.customer_remote_start_share))
                }
            }
        }
    }
}

@Composable
private fun ConsentRow(
    text: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(verticalAlignment = Alignment.Top) {
        Checkbox(checked = checked, onCheckedChange = onCheckedChange)
        Text(text = text, modifier = Modifier.weight(1f).padding(top = 12.dp))
    }
}

@Composable
private fun ActiveShareCard(
    state: ShareUiState,
    onServiceAction: (String) -> Unit,
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (state.paused) {
                MaterialTheme.colorScheme.secondaryContainer
            } else {
                MaterialTheme.colorScheme.primaryContainer
            },
        ),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = stringResource(
                    if (state.paused) {
                        R.string.customer_remote_paused_title
                    } else {
                        R.string.customer_remote_active_title
                    },
                ),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = stringResource(
                    when {
                        !state.relayConnected -> R.string.customer_remote_status_connecting
                        !state.operatorConnected -> R.string.customer_remote_status_waiting_operator
                        else -> R.string.customer_remote_status_connected
                    },
                ),
            )
            state.instruction?.let { instruction ->
                Text(
                    text = stringResource(R.string.customer_remote_instruction, instruction),
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = {
                        onServiceAction(
                            if (state.paused) {
                                ScreenShareService.ACTION_RESUME
                            } else {
                                ScreenShareService.ACTION_PAUSE
                            },
                        )
                    },
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(
                        imageVector = if (state.paused) {
                            Icons.Outlined.PlayArrow
                        } else {
                            Icons.Outlined.Pause
                        },
                        contentDescription = null,
                    )
                    Text(
                        stringResource(
                            if (state.paused) {
                                R.string.customer_remote_resume
                            } else {
                                R.string.customer_remote_pause
                            },
                        ),
                    )
                }
                Button(
                    onClick = { onServiceAction(ScreenShareService.ACTION_STOP) },
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Outlined.Stop, contentDescription = null)
                    Text(stringResource(R.string.customer_remote_stop))
                }
            }
        }
    }
}
