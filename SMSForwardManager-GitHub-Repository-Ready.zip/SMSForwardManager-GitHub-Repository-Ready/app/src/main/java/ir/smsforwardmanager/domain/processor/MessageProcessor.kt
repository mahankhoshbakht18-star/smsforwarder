package ir.smsforwardmanager.domain.processor

import androidx.room.withTransaction
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.core.model.ForwardMode
import ir.smsforwardmanager.core.model.ForwardStatus
import ir.smsforwardmanager.core.model.MessageProcessingState
import ir.smsforwardmanager.core.model.RuleDeliveryMode
import ir.smsforwardmanager.core.util.MessageFingerprint
import ir.smsforwardmanager.core.util.OtpExtractor
import ir.smsforwardmanager.core.util.PhoneNormalizer
import ir.smsforwardmanager.core.util.RuleMatcher
import ir.smsforwardmanager.core.util.SensitiveMessageDetector
import ir.smsforwardmanager.data.local.SmsForwardDatabase
import ir.smsforwardmanager.data.local.entity.ForwardAttemptEntity
import ir.smsforwardmanager.data.local.entity.IncomingMessageEntity
import ir.smsforwardmanager.data.repository.SettingsRepository
import ir.smsforwardmanager.sms.ForwardingScheduler
import ir.smsforwardmanager.network.MahanBotOtpForwarder
import ir.smsforwardmanager.network.MahanBotOtpSendResult
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

data class ReceivedSms(
    val sender: String,
    val body: String,
    val receivedAt: Long,
    val subscriptionId: Int? = null,
    val simSlotIndex: Int? = null,
)

@Singleton
class MessageProcessor @Inject constructor(
    private val database: SmsForwardDatabase,
    private val settingsRepository: SettingsRepository,
    private val scheduler: ForwardingScheduler,
    private val mahanBotOtpForwarder: MahanBotOtpForwarder,
) {
    suspend fun process(sms: ReceivedSms) {
        val messageDao = database.incomingMessageDao()
        val attemptDao = database.forwardAttemptDao()
        val settings = settingsRepository.get()
        val fingerprint = MessageFingerprint.create(
            sender = sms.sender,
            body = sms.body,
            receivedAt = sms.receivedAt,
            subscriptionId = sms.subscriptionId,
        )
        val messageId = messageDao.insertOrGetId(
            IncomingMessageEntity(
                fingerprint = fingerprint,
                sender = sms.sender,
                normalizedSender = PhoneNormalizer.normalizeSender(sms.sender),
                body = sms.body,
                receivedAt = sms.receivedAt,
                subscriptionId = sms.subscriptionId,
                simSlotIndex = sms.simSlotIndex,
            ),
        )

        when (val mahanBotResult = mahanBotOtpForwarder.sendIfEligible(sms, settings)) {
            is MahanBotOtpSendResult.Failed -> {
                if (mahanBotResult.retryable) error(mahanBotResult.reason)
            }
            else -> Unit
        }

        if (!settings.masterForwardingEnabled) {
            messageDao.updateProcessingState(messageId, MessageProcessingState.IGNORED, 0)
            return
        }

        val enabledRules = database.ruleDao().getEnabledWithDetails()
        var matchedRuleCount = 0
        val usedDestinations = mutableSetOf<String>()
        val dayStart = startOfLocalDay(sms.receivedAt)
        val newAttemptIds = database.withTransaction {
            val attempts = mutableListOf<ForwardAttemptEntity>()
            for (details in enabledRules) {
                if (!RuleMatcher.matches(details, sms.sender, sms.body, sms.receivedAt)) continue
                matchedRuleCount += 1

                val rule = details.rule
                var forwardedToday = if (rule.maxForwardsPerDay > 0) {
                    attemptDao.countForRuleSince(rule.id, dayStart)
                } else {
                    0
                }
                val sensitiveBlocked = SensitiveMessageDetector.isSensitive(sms.body) &&
                    !rule.allowSensitiveContent
                val extraction = if (rule.forwardMode == ForwardMode.EXTRACT_OTP) {
                    OtpExtractor.extract(
                        message = sms.body,
                        pattern = rule.otpRegex ?: settings.defaultOtpRegex,
                    )
                } else {
                    sms.body
                }
                val basePayload = extraction?.let { extracted ->
                    if (rule.forwardMode == ForwardMode.FULL_MESSAGE && settings.includeSenderInForward) {
                        buildString {
                            settings.forwardPrefix.trim().takeIf(String::isNotEmpty)?.let {
                                append(it).append('\n')
                            }
                            append(sms.sender).append('\n')
                            append(extracted)
                        }
                    } else {
                        extracted
                    }
                }
                val payload = basePayload?.let { value ->
                    buildString {
                        rule.prependText.trim().takeIf(String::isNotEmpty)?.let {
                            append(it).append('\n')
                        }
                        append(value)
                        rule.appendText.trim().takeIf(String::isNotEmpty)?.let {
                            append('\n').append(it)
                        }
                    }
                }
                val deliveryMode = resolveDeliveryMode(rule.deliveryModeOverride, settings.deliveryMode)

                details.destinationLinks
                    .sortedBy { it.link.sortOrder }
                    .filter { it.link.isEnabled && it.destination.isEnabled }
                    .forEach { destinationDetails ->
                        val destination = destinationDetails.destination
                        if (destination.normalizedPhoneNumber == PhoneNormalizer.normalizeSender(sms.sender)) {
                            return@forEach
                        }
                        val dailyLimitBlocked = rule.maxForwardsPerDay > 0 &&
                            forwardedToday >= rule.maxForwardsPerDay
                        if (!sensitiveBlocked && !dailyLimitBlocked && payload != null &&
                            !usedDestinations.add(destination.normalizedPhoneNumber)
                        ) {
                            return@forEach
                        }
                        val initialStatus = when {
                            sensitiveBlocked -> ForwardStatus.CANCELLED
                            dailyLimitBlocked -> ForwardStatus.CANCELLED
                            payload == null -> ForwardStatus.FAILED
                            else -> ForwardStatus.PENDING
                        }
                        val initialError = when {
                            sensitiveBlocked -> "SENSITIVE_CONTENT_BLOCKED"
                            dailyLimitBlocked -> "RULE_DAILY_LIMIT_REACHED"
                            payload == null -> "OTP_NOT_FOUND"
                            else -> null
                        }
                        attempts += ForwardAttemptEntity(
                            incomingMessageId = messageId,
                            ruleId = rule.id,
                            destinationId = destination.id,
                            destinationAddressSnapshot = destination.phoneNumber,
                            payload = if (initialStatus == ForwardStatus.PENDING) payload.orEmpty() else "",
                            forwardMode = rule.forwardMode,
                            deliveryMode = deliveryMode,
                            status = initialStatus,
                            errorMessage = initialError,
                            subscriptionId = rule.subscriptionId
                                ?: settings.defaultSubscriptionId
                                ?: sms.subscriptionId,
                        )
                        if (initialStatus == ForwardStatus.PENDING) forwardedToday += 1
                    }
                if (rule.stopAfterMatch) break
            }
            val ids = if (attempts.isEmpty()) emptyList() else attemptDao.insertAll(attempts)
            val schedulable = attempts.zip(ids)
                .filter { (attempt, id) -> id > 0 && attempt.status == ForwardStatus.PENDING }
                .map { it.second }
            val state = when {
                matchedRuleCount == 0 -> MessageProcessingState.IGNORED
                schedulable.isNotEmpty() -> MessageProcessingState.QUEUED
                attempts.any { it.status == ForwardStatus.FAILED } -> MessageProcessingState.FAILED
                else -> MessageProcessingState.MATCHED
            }
            messageDao.updateProcessingState(messageId, state, matchedRuleCount)
            schedulable
        }

        newAttemptIds.forEach { attemptId -> scheduler.enqueue(attemptId) }
    }

    private fun resolveDeliveryMode(
        override: RuleDeliveryMode,
        global: DeliveryMode,
    ): DeliveryMode = when (override) {
        RuleDeliveryMode.USE_GLOBAL -> if (global == DeliveryMode.SMART) {
            DeliveryMode.INTERNET_THEN_SMS
        } else {
            global
        }
        RuleDeliveryMode.SMS_ONLY -> DeliveryMode.SMS_ONLY
        RuleDeliveryMode.INTERNET_ONLY -> DeliveryMode.INTERNET_ONLY
        RuleDeliveryMode.INTERNET_THEN_SMS -> DeliveryMode.INTERNET_THEN_SMS
        RuleDeliveryMode.SMS_THEN_INTERNET -> DeliveryMode.SMS_THEN_INTERNET
    }

    private fun startOfLocalDay(epochMillis: Long): Long = Calendar.getInstance().apply {
        timeInMillis = epochMillis
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}
