package ir.smsforwardmanager.ui.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.smsforwardmanager.backup.BackupManager
import ir.smsforwardmanager.core.model.AppLanguage
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.core.model.ThemeMode
import ir.smsforwardmanager.core.util.OtpExtractor
import ir.smsforwardmanager.core.util.SimInfoProvider
import ir.smsforwardmanager.core.util.SimOption
import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import ir.smsforwardmanager.data.repository.SettingsRepository
import ir.smsforwardmanager.security.SecureApiTokenStore
import ir.smsforwardmanager.network.SecureEndpointValidator
import ir.smsforwardmanager.network.ApiConnectionTester
import ir.smsforwardmanager.network.ApiConnectionTestResult
import ir.smsforwardmanager.network.MahanBotConnectionTester
import ir.smsforwardmanager.network.MahanBotConnectionTestResult
import ir.smsforwardmanager.network.MahanBotEndpointValidator
import ir.smsforwardmanager.security.SecureMahanBotTokenStore
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val settings: AppSettingsEntity = AppSettingsEntity(),
    val prefix: String = AppSettingsEntity().forwardPrefix,
    val otpRegex: String = AppSettingsEntity.DEFAULT_OTP_REGEX,
    val retentionDays: String = "90",
    val maxSendAttempts: String = "3",
    val retryDelaySeconds: String = "60",
    val hourlySmsLimit: String = "20",
    val internetEndpoint: String = "",
    val apiToken: String = "",
    val mahanBotNationalId: String = "",
    val mahanBotEndpoint: String = "",
    val mahanBotSmsKeyword: String = "سامانه ازدواج",
    val mahanBotToken: String = "",
    val simOptions: List<SimOption> = emptyList(),
    val isDirty: Boolean = false,
    val isSaving: Boolean = false,
    val isTestingApi: Boolean = false,
    val isTestingMahanBot: Boolean = false,
    val defaultsValidationError: Boolean = false,
    val endpointValidationError: Boolean = false,
    val mahanBotValidationError: Boolean = false,
)

sealed interface SettingsEvent {
    data object Saved : SettingsEvent
    data class Exported(val count: Int) : SettingsEvent
    data class Imported(val count: Int, val language: AppLanguage) : SettingsEvent
    data object ApiReachable : SettingsEvent
    data object ApiUnauthorized : SettingsEvent
    data object ApiTestFailed : SettingsEvent
    data object MahanBotReachable : SettingsEvent
    data object MahanBotUnauthorized : SettingsEvent
    data object MahanBotApplicantNotFound : SettingsEvent
    data object MahanBotTestFailed : SettingsEvent
    data class Failed(val message: String) : SettingsEvent
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val repository: SettingsRepository,
    private val backupManager: BackupManager,
    private val simInfoProvider: SimInfoProvider,
    private val tokenStore: SecureApiTokenStore,
    private val apiConnectionTester: ApiConnectionTester,
    private val mahanBotTokenStore: SecureMahanBotTokenStore,
    private val mahanBotConnectionTester: MahanBotConnectionTester,
) : ViewModel() {
    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()
    private val _events = MutableSharedFlow<SettingsEvent>()
    val events: SharedFlow<SettingsEvent> = _events.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.get()
            repository.settings.collectLatest { settings ->
                _uiState.update { current ->
                    if (current.isDirty) {
                        current.copy(
                            settings = settings.copy(
                                deliveryMode = current.settings.deliveryMode,
                                includeSenderInForward = current.settings.includeSenderInForward,
                                defaultSubscriptionId = current.settings.defaultSubscriptionId,
                                appLockEnabled = current.settings.appLockEnabled,
                                mahanBotOtpEnabled = current.settings.mahanBotOtpEnabled,
                                mahanBotConsentAcceptedAt = current.settings.mahanBotConsentAcceptedAt,
                            ),
                        )
                    } else {
                        current.copy(
                            settings = settings,
                            prefix = settings.forwardPrefix,
                            otpRegex = settings.defaultOtpRegex,
                            retentionDays = settings.logRetentionDays.toString(),
                            maxSendAttempts = settings.maxSendAttempts.toString(),
                            retryDelaySeconds = settings.retryDelaySeconds.toString(),
                            hourlySmsLimit = settings.hourlySmsLimit.toString(),
                            internetEndpoint = settings.internetEndpoint,
                            apiToken = tokenStore.getToken(),
                            mahanBotNationalId = settings.mahanBotNationalId,
                            mahanBotEndpoint = settings.mahanBotEndpoint,
                            mahanBotSmsKeyword = settings.mahanBotSmsKeyword,
                            mahanBotToken = mahanBotTokenStore.getToken(),
                            simOptions = simInfoProvider.getActiveSims(),
                        )
                    }
                }
            }
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { repository.update { it.copy(language = language) } }
    }

    fun setTheme(themeMode: ThemeMode) {
        viewModelScope.launch { repository.update { it.copy(themeMode = themeMode) } }
    }

    fun setDynamicColors(enabled: Boolean) {
        viewModelScope.launch { repository.update { it.copy(dynamicColorEnabled = enabled) } }
    }

    fun setDeliveryMode(mode: DeliveryMode) {
        _uiState.update {
            it.copy(
                settings = it.settings.copy(deliveryMode = mode),
                isDirty = true,
                endpointValidationError = false,
            )
        }
    }

    fun setInternetEndpoint(value: String) {
        _uiState.update {
            it.copy(internetEndpoint = value, isDirty = true, endpointValidationError = false)
        }
    }

    fun setApiToken(value: String) {
        _uiState.update { it.copy(apiToken = value, isDirty = true) }
    }

    fun setMahanBotEnabled(enabled: Boolean) {
        _uiState.update { current ->
            current.copy(
                settings = current.settings.copy(
                    mahanBotOtpEnabled = enabled,
                    mahanBotConsentAcceptedAt = if (enabled) System.currentTimeMillis() else null,
                ),
                isDirty = true,
                mahanBotValidationError = false,
            )
        }
        // Disabling consent is immediate; it must not depend on pressing Save later.
        if (!enabled) {
            viewModelScope.launch {
                repository.update {
                    it.copy(
                        mahanBotOtpEnabled = false,
                        mahanBotConsentAcceptedAt = null,
                    )
                }
            }
        }
    }

    fun setMahanBotNationalId(value: String) {
        val normalized = value.map { ch ->
            when (ch) {
                in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar()
                in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar()
                else -> ch
            }
        }.filter(Char::isDigit).take(10).joinToString("")
        _uiState.update { it.copy(mahanBotNationalId = normalized, isDirty = true, mahanBotValidationError = false) }
    }

    fun setMahanBotEndpoint(value: String) {
        _uiState.update { it.copy(mahanBotEndpoint = value, isDirty = true, mahanBotValidationError = false) }
    }

    fun setMahanBotSmsKeyword(value: String) {
        _uiState.update { it.copy(mahanBotSmsKeyword = value, isDirty = true, mahanBotValidationError = false) }
    }

    fun setMahanBotToken(value: String) {
        _uiState.update { it.copy(mahanBotToken = value, isDirty = true, mahanBotValidationError = false) }
    }

    fun testMahanBotConnection() {
        val state = _uiState.value
        val valid = state.mahanBotNationalId.length == 10 &&
            MahanBotEndpointValidator.isValid(state.mahanBotEndpoint) &&
            state.mahanBotToken.isNotBlank()
        if (!valid) {
            _uiState.update { it.copy(mahanBotValidationError = true) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingMahanBot = true) }
            val result = mahanBotConnectionTester.test(
                endpoint = state.mahanBotEndpoint,
                token = state.mahanBotToken,
                nationalId = state.mahanBotNationalId,
            )
            _uiState.update { it.copy(isTestingMahanBot = false) }
            _events.emit(
                when (result) {
                    MahanBotConnectionTestResult.Reachable -> SettingsEvent.MahanBotReachable
                    MahanBotConnectionTestResult.Unauthorized -> SettingsEvent.MahanBotUnauthorized
                    MahanBotConnectionTestResult.ApplicantNotFound -> SettingsEvent.MahanBotApplicantNotFound
                    MahanBotConnectionTestResult.Failed -> SettingsEvent.MahanBotTestFailed
                },
            )
        }
    }

    fun setAppLockEnabled(enabled: Boolean) {
        _uiState.update { current ->
            current.copy(settings = current.settings.copy(appLockEnabled = enabled))
        }
        viewModelScope.launch {
            repository.update { it.copy(appLockEnabled = enabled) }
        }
    }

    fun setIncludeSender(enabled: Boolean) {
        _uiState.update {
            it.copy(settings = it.settings.copy(includeSenderInForward = enabled), isDirty = true)
        }
    }

    fun setDefaultSim(subscriptionId: Int?) {
        _uiState.update {
            it.copy(settings = it.settings.copy(defaultSubscriptionId = subscriptionId), isDirty = true)
        }
    }

    fun setPrefix(value: String) {
        _uiState.update {
            it.copy(prefix = value, isDirty = true, defaultsValidationError = false)
        }
    }

    fun setOtpRegex(value: String) {
        _uiState.update {
            it.copy(otpRegex = value, isDirty = true, defaultsValidationError = false)
        }
    }

    fun setRetentionDays(value: String) {
        _uiState.update {
            it.copy(retentionDays = value, isDirty = true, defaultsValidationError = false)
        }
    }

    fun setMaxSendAttempts(value: String) {
        _uiState.update {
            it.copy(maxSendAttempts = value, isDirty = true, defaultsValidationError = false)
        }
    }

    fun setRetryDelaySeconds(value: String) {
        _uiState.update {
            it.copy(retryDelaySeconds = value, isDirty = true, defaultsValidationError = false)
        }
    }

    fun setHourlySmsLimit(value: String) {
        _uiState.update {
            it.copy(hourlySmsLimit = value, isDirty = true, defaultsValidationError = false)
        }
    }

    fun testApiConnection() {
        val state = _uiState.value
        if (!isValidHttpsEndpoint(state.internetEndpoint)) {
            _uiState.update { it.copy(endpointValidationError = true) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingApi = true) }
            val result = apiConnectionTester.test(
                endpoint = state.internetEndpoint,
                token = state.apiToken,
                connectTimeoutSeconds = state.settings.internetConnectTimeoutSeconds,
                readTimeoutSeconds = state.settings.internetReadTimeoutSeconds,
            )
            _uiState.update { it.copy(isTestingApi = false) }
            _events.emit(
                when (result) {
                    is ApiConnectionTestResult.Reachable -> SettingsEvent.ApiReachable
                    ApiConnectionTestResult.Unauthorized -> SettingsEvent.ApiUnauthorized
                    ApiConnectionTestResult.Failed -> SettingsEvent.ApiTestFailed
                },
            )
        }
    }

    fun saveDefaults() {
        val state = _uiState.value
        val days = state.retentionDays.toIntOrNull()
        val maxAttempts = state.maxSendAttempts.toIntOrNull()
        val retryDelay = state.retryDelaySeconds.toIntOrNull()
        val hourlyLimit = state.hourlySmsLimit.toIntOrNull()
        val defaultsInvalid = !OtpExtractor.isValidPattern(state.otpRegex) ||
            days == null || days !in 1..3650 ||
            maxAttempts == null || maxAttempts !in 1..10 ||
            retryDelay == null || retryDelay !in 10..86_400 ||
            hourlyLimit == null || hourlyLimit !in 0..500
        val endpointInvalid = state.settings.deliveryMode != DeliveryMode.SMS_ONLY &&
            !isValidHttpsEndpoint(state.internetEndpoint)
        val mahanBotInvalid = state.settings.mahanBotOtpEnabled && (
            state.mahanBotNationalId.length != 10 ||
                !MahanBotEndpointValidator.isValid(state.mahanBotEndpoint) ||
                state.mahanBotToken.isBlank() ||
                state.mahanBotSmsKeyword.isBlank() ||
                state.settings.mahanBotConsentAcceptedAt == null
            )

        if (defaultsInvalid || endpointInvalid || mahanBotInvalid) {
            _uiState.update {
                it.copy(
                    defaultsValidationError = defaultsInvalid,
                    endpointValidationError = endpointInvalid,
                    mahanBotValidationError = mahanBotInvalid,
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            runCatching {
                repository.update {
                    it.copy(
                        deliveryMode = state.settings.deliveryMode,
                        internetEndpoint = state.internetEndpoint.trim(),
                        includeSenderInForward = state.settings.includeSenderInForward,
                        defaultSubscriptionId = state.settings.defaultSubscriptionId,
                        forwardPrefix = state.prefix.trim(),
                        defaultOtpRegex = state.otpRegex.trim(),
                        logRetentionDays = days!!,
                        maxSendAttempts = maxAttempts!!,
                        retryDelaySeconds = retryDelay!!,
                        hourlySmsLimit = hourlyLimit!!,
                        appLockEnabled = state.settings.appLockEnabled,
                        mahanBotOtpEnabled = state.settings.mahanBotOtpEnabled,
                        mahanBotNationalId = state.mahanBotNationalId,
                        mahanBotEndpoint = MahanBotEndpointValidator.normalize(state.mahanBotEndpoint).orEmpty(),
                        mahanBotSmsKeyword = state.mahanBotSmsKeyword.trim(),
                        mahanBotConsentAcceptedAt = state.settings.mahanBotConsentAcceptedAt,
                    )
                }
                tokenStore.setToken(state.apiToken)
                mahanBotTokenStore.setToken(state.mahanBotToken)
            }.onSuccess {
                _uiState.update {
                    it.copy(
                        isSaving = false,
                        isDirty = false,
                        defaultsValidationError = false,
                        endpointValidationError = false,
                        mahanBotValidationError = false,
                    )
                }
                _events.emit(SettingsEvent.Saved)
            }.onFailure { error ->
                _uiState.update { it.copy(isSaving = false) }
                _events.emit(SettingsEvent.Failed(error.message ?: error.javaClass.simpleName))
            }
        }
    }

    fun exportBackup(uri: Uri) {
        viewModelScope.launch {
            runCatching { backupManager.exportTo(uri) }
                .onSuccess { _events.emit(SettingsEvent.Exported(it)) }
                .onFailure { _events.emit(SettingsEvent.Failed(it.message ?: it.javaClass.simpleName)) }
        }
    }

    fun importBackup(uri: Uri) {
        viewModelScope.launch {
            runCatching { backupManager.importFrom(uri) }
                .onSuccess { count ->
                    val settings = repository.get()
                    _uiState.update {
                        it.copy(
                            settings = settings,
                            prefix = settings.forwardPrefix,
                            otpRegex = settings.defaultOtpRegex,
                            retentionDays = settings.logRetentionDays.toString(),
                            maxSendAttempts = settings.maxSendAttempts.toString(),
                            retryDelaySeconds = settings.retryDelaySeconds.toString(),
                            hourlySmsLimit = settings.hourlySmsLimit.toString(),
                            internetEndpoint = settings.internetEndpoint,
                            apiToken = tokenStore.getToken(),
                            mahanBotNationalId = settings.mahanBotNationalId,
                            mahanBotEndpoint = settings.mahanBotEndpoint,
                            mahanBotSmsKeyword = settings.mahanBotSmsKeyword,
                            mahanBotToken = mahanBotTokenStore.getToken(),
                            simOptions = simInfoProvider.getActiveSims(),
                            isDirty = false,
                            defaultsValidationError = false,
                            endpointValidationError = false,
                            mahanBotValidationError = false,
                        )
                    }
                    _events.emit(SettingsEvent.Imported(count, settings.language))
                }
                .onFailure { _events.emit(SettingsEvent.Failed(it.message ?: it.javaClass.simpleName)) }
        }
    }

    private fun isValidHttpsEndpoint(value: String): Boolean =
        SecureEndpointValidator.isValid(value)
}
