package ir.smsforwardmanager.core.model

import kotlinx.serialization.Serializable

@Serializable
enum class MatchMode {
    CONTAINS,
    STARTS_WITH,
    EXACT,
}

@Serializable
enum class KeywordLogic {
    ANY,
    ALL,
}

@Serializable
enum class ForwardMode {
    FULL_MESSAGE,
    EXTRACT_OTP,
}

/**
 * Global route used for newly-created forwarding attempts.
 * Existing attempts keep a snapshot of the mode that was active when queued.
 */
@Serializable
enum class DeliveryMode {
    SMS_ONLY,
    INTERNET_ONLY,
    INTERNET_THEN_SMS,
    SMS_THEN_INTERNET,

    /** Kept only so old v2 backups/databases can be read. New UI never writes this value. */
    SMART,
}

/** Per-rule route override. USE_GLOBAL keeps the route selected in app settings. */
@Serializable
enum class RuleDeliveryMode {
    USE_GLOBAL,
    SMS_ONLY,
    INTERNET_ONLY,
    INTERNET_THEN_SMS,
    SMS_THEN_INTERNET,
}

/** The channel that actually handled the attempt. */
@Serializable
enum class DeliveryMethod {
    SMS,
    INTERNET,
}

@Serializable
enum class MessageProcessingState {
    RECEIVED,
    MATCHED,
    IGNORED,
    QUEUED,
    COMPLETED,
    PARTIAL_FAILURE,
    FAILED,
}

@Serializable
enum class ForwardStatus {
    PENDING,
    ENQUEUED,
    RETRY_PENDING,
    SENDING,
    SENT,
    SENT_WAITING_DELIVERY,
    SENT_DELIVERY_UNKNOWN,
    DELIVERED,
    PARTIALLY_FAILED,
    FAILED,
    CANCELLED,
}

@Serializable
enum class SmsPartSentStatus {
    PENDING,
    SENT,
    FAILED,
}

@Serializable
enum class SmsPartDeliveryStatus {
    PENDING,
    DELIVERED,
    FAILED,
    UNKNOWN,
}

@Serializable
enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK,
}

@Serializable
enum class AppLanguage {
    SYSTEM,
    PERSIAN,
    ENGLISH,
}
