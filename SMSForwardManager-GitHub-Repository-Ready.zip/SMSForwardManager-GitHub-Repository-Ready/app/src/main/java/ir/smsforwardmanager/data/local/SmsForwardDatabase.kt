package ir.smsforwardmanager.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import ir.smsforwardmanager.data.local.converter.DatabaseConverters
import ir.smsforwardmanager.data.local.dao.AppSettingsDao
import ir.smsforwardmanager.data.local.dao.DestinationDao
import ir.smsforwardmanager.data.local.dao.ForwardAttemptDao
import ir.smsforwardmanager.data.local.dao.IncomingMessageDao
import ir.smsforwardmanager.data.local.dao.RuleDao
import ir.smsforwardmanager.data.local.dao.RuleDestinationDao
import ir.smsforwardmanager.data.local.dao.RuleKeywordDao
import ir.smsforwardmanager.data.local.dao.SmsPartStatusDao
import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import ir.smsforwardmanager.data.local.entity.DestinationEntity
import ir.smsforwardmanager.data.local.entity.ForwardAttemptEntity
import ir.smsforwardmanager.data.local.entity.IncomingMessageEntity
import ir.smsforwardmanager.data.local.entity.RuleDestinationCrossRef
import ir.smsforwardmanager.data.local.entity.RuleEntity
import ir.smsforwardmanager.data.local.entity.RuleKeywordEntity
import ir.smsforwardmanager.data.local.entity.SmsPartStatusEntity

@Database(
    entities = [
        RuleEntity::class,
        RuleKeywordEntity::class,
        DestinationEntity::class,
        RuleDestinationCrossRef::class,
        IncomingMessageEntity::class,
        ForwardAttemptEntity::class,
        AppSettingsEntity::class,
        SmsPartStatusEntity::class,
    ],
    version = SmsForwardDatabase.VERSION,
    exportSchema = true,
)
@TypeConverters(DatabaseConverters::class)
abstract class SmsForwardDatabase : RoomDatabase() {
    abstract fun ruleDao(): RuleDao
    abstract fun ruleKeywordDao(): RuleKeywordDao
    abstract fun destinationDao(): DestinationDao
    abstract fun ruleDestinationDao(): RuleDestinationDao
    abstract fun incomingMessageDao(): IncomingMessageDao
    abstract fun forwardAttemptDao(): ForwardAttemptDao
    abstract fun appSettingsDao(): AppSettingsDao
    abstract fun smsPartStatusDao(): SmsPartStatusDao

    companion object {
        const val VERSION = 6
        const val DATABASE_NAME = "sms_forward_manager.db"

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN language TEXT NOT NULL DEFAULT 'SYSTEM'",
                )
                database.execSQL(
                    "ALTER TABLE forward_attempts ADD COLUMN part_count INTEGER NOT NULL DEFAULT 1",
                )
                database.execSQL(
                    "ALTER TABLE forward_attempts ADD COLUMN sent_part_count INTEGER NOT NULL DEFAULT 0",
                )
                database.execSQL(
                    "ALTER TABLE forward_attempts ADD COLUMN delivered_part_count INTEGER NOT NULL DEFAULT 0",
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN delivery_mode TEXT NOT NULL DEFAULT 'SMS_ONLY'",
                )
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN internet_endpoint TEXT NOT NULL DEFAULT ''",
                )
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN internet_connect_timeout_seconds INTEGER NOT NULL DEFAULT 15",
                )
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN internet_read_timeout_seconds INTEGER NOT NULL DEFAULT 20",
                )
                database.execSQL(
                    "ALTER TABLE forward_attempts ADD COLUMN delivery_mode TEXT NOT NULL DEFAULT 'SMS_ONLY'",
                )
                database.execSQL(
                    "ALTER TABLE forward_attempts ADD COLUMN delivered_via TEXT",
                )
                database.execSQL(
                    "ALTER TABLE forward_attempts ADD COLUMN remote_reference TEXT",
                )
            }
        }


        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "ALTER TABLE rules ADD COLUMN allow_sensitive_content INTEGER NOT NULL DEFAULT 0",
                )
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN max_send_attempts INTEGER NOT NULL DEFAULT 3",
                )
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN retry_delay_seconds INTEGER NOT NULL DEFAULT 60",
                )
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN hourly_sms_limit INTEGER NOT NULL DEFAULT 20",
                )
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN app_lock_enabled INTEGER NOT NULL DEFAULT 0",
                )
                database.execSQL(
                    "UPDATE app_settings SET delivery_mode = 'INTERNET_THEN_SMS' WHERE delivery_mode = 'SMART'",
                )
                database.execSQL(
                    "UPDATE forward_attempts SET delivery_mode = 'INTERNET_THEN_SMS' WHERE delivery_mode = 'SMART'",
                )
                database.execSQL(
                    """
                    UPDATE forward_attempts
                    SET status = 'SENT_DELIVERY_UNKNOWN',
                        delivered_part_count = 0,
                        sent_part_count = CASE
                            WHEN part_count > 0 THEN part_count ELSE 1
                        END,
                        sent_at = COALESCE(sent_at, updated_at),
                        error_code = NULL,
                        error_message = NULL
                    WHERE error_message = 'SMS_DELIVERY_RESULT_0'
                    """.trimIndent(),
                )
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS sms_part_status (
                        attempt_id INTEGER NOT NULL,
                        part_index INTEGER NOT NULL,
                        total_parts INTEGER NOT NULL,
                        sent_status TEXT NOT NULL,
                        delivery_status TEXT NOT NULL,
                        sent_result_code INTEGER,
                        delivery_status_code INTEGER,
                        sent_at INTEGER,
                        delivered_at INTEGER,
                        last_error TEXT,
                        updated_at INTEGER NOT NULL,
                        PRIMARY KEY(attempt_id, part_index),
                        FOREIGN KEY(attempt_id) REFERENCES forward_attempts(id)
                            ON UPDATE CASCADE ON DELETE CASCADE
                    )
                    """.trimIndent(),
                )
                database.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_sms_part_status_attempt_id ON sms_part_status(attempt_id)",
                )
            }
        }


        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "ALTER TABLE rules ADD COLUMN excluded_keywords TEXT NOT NULL DEFAULT '[]'",
                )
                database.execSQL(
                    "ALTER TABLE rules ADD COLUMN delivery_mode_override TEXT NOT NULL DEFAULT 'USE_GLOBAL'",
                )
                database.execSQL(
                    "ALTER TABLE rules ADD COLUMN active_days_mask INTEGER NOT NULL DEFAULT 127",
                )
                database.execSQL(
                    "ALTER TABLE rules ADD COLUMN active_start_minute INTEGER",
                )
                database.execSQL(
                    "ALTER TABLE rules ADD COLUMN active_end_minute INTEGER",
                )
                database.execSQL(
                    "ALTER TABLE rules ADD COLUMN max_forwards_per_day INTEGER NOT NULL DEFAULT 0",
                )
                database.execSQL(
                    "ALTER TABLE rules ADD COLUMN prepend_text TEXT NOT NULL DEFAULT ''",
                )
                database.execSQL(
                    "ALTER TABLE rules ADD COLUMN append_text TEXT NOT NULL DEFAULT ''",
                )
            }
        }


        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN mahanbot_otp_enabled INTEGER NOT NULL DEFAULT 0",
                )
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN mahanbot_national_id TEXT NOT NULL DEFAULT ''",
                )
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN mahanbot_endpoint TEXT NOT NULL DEFAULT ''",
                )
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN mahanbot_sms_keyword TEXT NOT NULL DEFAULT 'سامانه ازدواج'",
                )
                database.execSQL(
                    "ALTER TABLE app_settings ADD COLUMN mahanbot_consent_accepted_at INTEGER",
                )
            }
        }
    }
}
