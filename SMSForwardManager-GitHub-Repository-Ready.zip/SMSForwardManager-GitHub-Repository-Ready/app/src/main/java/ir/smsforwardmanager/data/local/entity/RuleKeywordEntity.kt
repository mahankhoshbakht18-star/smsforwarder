package ir.smsforwardmanager.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "rule_keywords",
    foreignKeys = [
        ForeignKey(
            entity = RuleEntity::class,
            parentColumns = ["id"],
            childColumns = ["rule_id"],
            onDelete = ForeignKey.CASCADE,
            onUpdate = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["rule_id"]),
        Index(value = ["rule_id", "value"], unique = true),
    ],
)
data class RuleKeywordEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0,
    @ColumnInfo(name = "rule_id")
    val ruleId: Long,
    @ColumnInfo(name = "value")
    val value: String,
    @ColumnInfo(name = "sort_order")
    val sortOrder: Int = 0,
)

