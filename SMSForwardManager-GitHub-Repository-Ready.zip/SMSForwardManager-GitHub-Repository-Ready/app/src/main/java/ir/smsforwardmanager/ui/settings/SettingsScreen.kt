package ir.smsforwardmanager.ui.settings

import android.Manifest
import android.app.ActivityManager
import android.content.pm.PackageManager
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BatterySaver
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.biometric.BiometricManager
import androidx.core.net.toUri
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.smsforwardmanager.R
import ir.smsforwardmanager.core.model.AppLanguage
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.core.model.ThemeMode
import ir.smsforwardmanager.ui.components.ChoiceChips
import ir.smsforwardmanager.ui.components.LabeledSwitch
import ir.smsforwardmanager.ui.components.SectionCard
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(
    onLanguageChange: (AppLanguage) -> Unit,
    onOpenAbout: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var confirmImport by remember { mutableStateOf(false) }
    var confirmClearData by remember { mutableStateOf(false) }
    var confirmMahanBotConsent by remember { mutableStateOf(false) }
    val biometricAuthenticators = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else {
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        }
    }
    val appLockAvailable = remember {
        BiometricManager.from(context).canAuthenticate(biometricAuthenticators) ==
            BiometricManager.BIOMETRIC_SUCCESS
    }
    var smsPermissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECEIVE_SMS) ==
                PackageManager.PERMISSION_GRANTED,
        )
    }
    val smsPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> smsPermissionGranted = granted }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri -> uri?.let(viewModel::exportBackup) }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri -> uri?.let(viewModel::importBackup) }

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            val message = when (event) {
                SettingsEvent.Saved -> context.getString(R.string.settings_saved)
                is SettingsEvent.Exported -> context.resources.getQuantityString(
                    R.plurals.backup_exported,
                    event.count,
                    event.count,
                )
                is SettingsEvent.Imported -> {
                    onLanguageChange(event.language)
                    context.resources.getQuantityString(
                        R.plurals.backup_imported,
                        event.count,
                        event.count,
                    )
                }
                SettingsEvent.ApiReachable -> context.getString(R.string.api_test_reachable)
                SettingsEvent.ApiUnauthorized -> context.getString(R.string.api_test_unauthorized)
                SettingsEvent.ApiTestFailed -> context.getString(R.string.api_test_failed)
                SettingsEvent.MahanBotReachable -> context.getString(R.string.mahanbot_test_reachable)
                SettingsEvent.MahanBotUnauthorized -> context.getString(R.string.mahanbot_test_unauthorized)
                SettingsEvent.MahanBotApplicantNotFound -> context.getString(R.string.mahanbot_test_applicant_not_found)
                SettingsEvent.MahanBotTestFailed -> context.getString(R.string.mahanbot_test_failed)
                is SettingsEvent.Failed -> context.getString(R.string.operation_failed, event.message)
            }
            snackbarHostState.showSnackbar(message)
        }
    }

    Scaffold(
        modifier = modifier,
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Column {
                    Text(stringResource(R.string.settings_title), style = MaterialTheme.typography.headlineMedium)
                    Text(
                        stringResource(R.string.settings_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            item {
                SectionCard(
                    title = stringResource(R.string.delivery_section),
                    description = stringResource(R.string.delivery_section_desc),
                ) {
                    val visibleDeliveryMode = when (state.settings.deliveryMode) {
                        DeliveryMode.SMS_THEN_INTERNET,
                        DeliveryMode.SMART -> DeliveryMode.INTERNET_THEN_SMS
                        else -> state.settings.deliveryMode
                    }
                    ChoiceChips(
                        options = listOf(
                            DeliveryMode.SMS_ONLY to stringResource(R.string.delivery_sms_only_short),
                            DeliveryMode.INTERNET_ONLY to stringResource(R.string.delivery_internet_only_short),
                            DeliveryMode.INTERNET_THEN_SMS to stringResource(R.string.delivery_sms_and_internet),
                        ),
                        selected = visibleDeliveryMode,
                        onSelected = viewModel::setDeliveryMode,
                    )
                    Text(
                        text = stringResource(
                            when (visibleDeliveryMode) {
                                DeliveryMode.SMS_ONLY -> R.string.delivery_sms_only_desc
                                DeliveryMode.INTERNET_ONLY -> R.string.delivery_internet_only_desc
                                else -> R.string.delivery_sms_and_internet_desc
                            },
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    if (state.settings.deliveryMode != DeliveryMode.SMS_ONLY) {
                        OutlinedTextField(
                            value = state.internetEndpoint,
                            onValueChange = viewModel::setInternetEndpoint,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(stringResource(R.string.internet_endpoint)) },
                            placeholder = { Text(stringResource(R.string.internet_endpoint_hint)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                            singleLine = true,
                            isError = state.endpointValidationError,
                            supportingText = if (state.endpointValidationError) {
                                { Text(stringResource(R.string.internet_validation)) }
                            } else null,
                        )
                        OutlinedTextField(
                            value = state.apiToken,
                            onValueChange = viewModel::setApiToken,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(stringResource(R.string.internet_api_token)) },
                            placeholder = { Text(stringResource(R.string.internet_api_token_hint)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                        )
                        OutlinedButton(
                            onClick = viewModel::testApiConnection,
                            enabled = !state.isTestingApi,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            if (state.isTestingApi) {
                                CircularProgressIndicator(modifier = Modifier.padding(end = 8.dp))
                            } else {
                                Icon(Icons.Outlined.Cloud, contentDescription = null)
                            }
                            Text(
                                stringResource(R.string.test_api_connection),
                                modifier = Modifier.padding(start = 8.dp),
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(
                                Icons.Outlined.Cloud,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                            )
                            Text(
                                stringResource(R.string.internet_security_note),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            item {
                SectionCard(
                    title = stringResource(R.string.mahanbot_section),
                    description = stringResource(R.string.mahanbot_section_desc),
                ) {
                    LabeledSwitch(
                        title = stringResource(R.string.mahanbot_enable),
                        description = stringResource(R.string.mahanbot_enable_desc),
                        checked = state.settings.mahanBotOtpEnabled && smsPermissionGranted,
                        enabled = smsPermissionGranted,
                        onCheckedChange = { enabled ->
                            if (enabled) confirmMahanBotConsent = true
                            else viewModel.setMahanBotEnabled(false)
                        },
                    )
                    if (!smsPermissionGranted) {
                        OutlinedButton(
                            onClick = { smsPermissionLauncher.launch(Manifest.permission.RECEIVE_SMS) },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(stringResource(R.string.mahanbot_grant_sms_permission))
                        }
                    }
                    OutlinedTextField(
                        value = state.mahanBotNationalId,
                        onValueChange = viewModel::setMahanBotNationalId,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.mahanbot_national_id)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        isError = state.mahanBotValidationError,
                    )
                    OutlinedTextField(
                        value = state.mahanBotEndpoint,
                        onValueChange = viewModel::setMahanBotEndpoint,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.mahanbot_endpoint)) },
                        placeholder = { Text(stringResource(R.string.mahanbot_endpoint_hint)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        singleLine = true,
                        isError = state.mahanBotValidationError,
                    )
                    OutlinedTextField(
                        value = state.mahanBotToken,
                        onValueChange = viewModel::setMahanBotToken,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.mahanbot_device_key)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        isError = state.mahanBotValidationError,
                    )
                    OutlinedTextField(
                        value = state.mahanBotSmsKeyword,
                        onValueChange = viewModel::setMahanBotSmsKeyword,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.mahanbot_sms_keyword)) },
                        singleLine = true,
                        isError = state.mahanBotValidationError,
                        supportingText = {
                            Text(stringResource(R.string.mahanbot_privacy_note))
                        },
                    )
                    OutlinedButton(
                        onClick = viewModel::testMahanBotConnection,
                        enabled = !state.isTestingMahanBot,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        if (state.isTestingMahanBot) {
                            CircularProgressIndicator(modifier = Modifier.padding(end = 8.dp))
                        } else {
                            Icon(Icons.Outlined.Cloud, contentDescription = null)
                        }
                        Text(
                            stringResource(R.string.mahanbot_test_connection),
                            modifier = Modifier.padding(start = 8.dp),
                        )
                    }
                    if (state.mahanBotValidationError) {
                        Text(
                            stringResource(R.string.mahanbot_validation),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }

            item {
                SectionCard(
                    title = stringResource(R.string.language_section),
                    description = stringResource(R.string.language_section_desc),
                ) {
                    ChoiceChips(
                        options = listOf(
                            AppLanguage.SYSTEM to stringResource(R.string.language_system),
                            AppLanguage.PERSIAN to stringResource(R.string.language_persian),
                            AppLanguage.ENGLISH to stringResource(R.string.language_english),
                        ),
                        selected = state.settings.language,
                        onSelected = { language ->
                            viewModel.setLanguage(language)
                            onLanguageChange(language)
                        },
                    )
                }
            }

            item {
                SectionCard(
                    title = stringResource(R.string.appearance_section),
                    description = stringResource(R.string.appearance_section_desc),
                ) {
                    Text(stringResource(R.string.theme), style = MaterialTheme.typography.labelLarge)
                    ChoiceChips(
                        options = listOf(
                            ThemeMode.SYSTEM to stringResource(R.string.theme_system),
                            ThemeMode.LIGHT to stringResource(R.string.theme_light),
                            ThemeMode.DARK to stringResource(R.string.theme_dark),
                        ),
                        selected = state.settings.themeMode,
                        onSelected = viewModel::setTheme,
                    )
                }
            }

            item {
                SectionCard(
                    title = stringResource(R.string.defaults_section),
                    description = stringResource(R.string.defaults_section_desc),
                ) {
                    LabeledSwitch(
                        title = stringResource(R.string.include_sender),
                        checked = state.settings.includeSenderInForward,
                        onCheckedChange = viewModel::setIncludeSender,
                    )
                    OutlinedTextField(
                        value = state.prefix,
                        onValueChange = viewModel::setPrefix,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.forward_prefix)) },
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = state.otpRegex,
                        onValueChange = viewModel::setOtpRegex,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.default_otp_regex)) },
                        singleLine = true,
                        isError = state.defaultsValidationError,
                    )
                    OutlinedTextField(
                        value = state.retentionDays,
                        onValueChange = { value ->
                            if (value.isEmpty() || value.all(Char::isDigit)) viewModel.setRetentionDays(value)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.log_retention)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        isError = state.defaultsValidationError,
                        supportingText = if (state.defaultsValidationError) {
                            { Text(stringResource(R.string.settings_validation)) }
                        } else null,
                    )
                    Text(stringResource(R.string.default_sim), style = MaterialTheme.typography.labelLarge)
                    ChoiceChips(
                        options = buildList<Pair<Int?, String>> {
                            add(null to stringResource(R.string.sim_automatic))
                            state.simOptions.forEach { sim ->
                                val name = sim.displayName.ifBlank { sim.carrierName.ifBlank { "SIM" } }
                                add(sim.subscriptionId to stringResource(R.string.sim_slot, sim.slotIndex + 1, name))
                            }
                        },
                        selected = state.settings.defaultSubscriptionId,
                        onSelected = viewModel::setDefaultSim,
                    )
                    Button(
                        onClick = viewModel::saveDefaults,
                        enabled = !state.isSaving,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        if (state.isSaving) {
                            CircularProgressIndicator(modifier = Modifier.padding(end = 8.dp))
                        } else {
                            Icon(Icons.Outlined.Save, contentDescription = null)
                        }
                        Text(stringResource(R.string.save_all_settings), modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }

            item {
                SectionCard(
                    title = stringResource(R.string.reliability_section),
                    description = stringResource(R.string.reliability_section_desc),
                ) {
                    OutlinedTextField(
                        value = state.maxSendAttempts,
                        onValueChange = { value ->
                            if (value.isEmpty() || value.all(Char::isDigit)) {
                                viewModel.setMaxSendAttempts(value)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.max_send_attempts)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        isError = state.defaultsValidationError,
                    )
                    OutlinedTextField(
                        value = state.retryDelaySeconds,
                        onValueChange = { value ->
                            if (value.isEmpty() || value.all(Char::isDigit)) {
                                viewModel.setRetryDelaySeconds(value)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.retry_delay_seconds)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        isError = state.defaultsValidationError,
                    )
                    OutlinedTextField(
                        value = state.hourlySmsLimit,
                        onValueChange = { value ->
                            if (value.isEmpty() || value.all(Char::isDigit)) {
                                viewModel.setHourlySmsLimit(value)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(stringResource(R.string.hourly_sms_limit)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        isError = state.defaultsValidationError,
                        supportingText = if (state.defaultsValidationError) {
                            { Text(stringResource(R.string.reliability_validation)) }
                        } else null,
                    )
                }
            }

            item {
                SectionCard(
                    title = stringResource(R.string.backup_section),
                    description = stringResource(R.string.backup_section_desc_v2),
                ) {
                    Button(
                        onClick = {
                            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                            exportLauncher.launch("sms-forward-manager-$date.json")
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Outlined.Download, contentDescription = null)
                        Text(stringResource(R.string.export_backup), modifier = Modifier.padding(start = 8.dp))
                    }
                    OutlinedButton(onClick = { confirmImport = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Outlined.Upload, contentDescription = null)
                        Text(stringResource(R.string.import_backup), modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }

            item {
                SectionCard(
                    title = stringResource(R.string.settings_about_section),
                    description = stringResource(R.string.settings_about_section_desc),
                ) {
                    OutlinedButton(onClick = onOpenAbout, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Outlined.Info, contentDescription = null)
                        Text(
                            stringResource(R.string.settings_open_about),
                            modifier = Modifier.padding(start = 8.dp),
                        )
                    }
                }
            }

            item {
                SectionCard(
                    title = stringResource(R.string.privacy_section),
                    description = stringResource(R.string.privacy_desc_v2),
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Outlined.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(stringResource(R.string.privacy_secure_token), style = MaterialTheme.typography.titleSmall)
                    }
                    LabeledSwitch(
                        title = stringResource(R.string.app_lock),
                        description = stringResource(
                            if (appLockAvailable) R.string.app_lock_desc
                            else R.string.app_lock_unavailable,
                        ),
                        checked = state.settings.appLockEnabled && appLockAvailable,
                        enabled = appLockAvailable,
                        onCheckedChange = viewModel::setAppLockEnabled,
                    )
                    Text(stringResource(R.string.battery_desc), style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(
                        onClick = { confirmClearData = true },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Outlined.DeleteForever, contentDescription = null)
                        Text(
                            stringResource(R.string.delete_all_app_data),
                            modifier = Modifier.padding(start = 8.dp),
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                            runCatching { context.startActivity(intent) }.onFailure {
                                context.startActivity(
                                    Intent(
                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        "package:${context.packageName}".toUri(),
                                    ),
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Outlined.BatterySaver, contentDescription = null)
                        Text(stringResource(R.string.open_battery_settings), modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        }
    }

    if (confirmMahanBotConsent) {
        AlertDialog(
            onDismissRequest = { confirmMahanBotConsent = false },
            title = { Text(stringResource(R.string.mahanbot_consent_title)) },
            text = { Text(stringResource(R.string.mahanbot_consent_text)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmMahanBotConsent = false
                        viewModel.setMahanBotEnabled(true)
                    },
                ) { Text(stringResource(R.string.mahanbot_consent_accept)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmMahanBotConsent = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }

    if (confirmImport) {
        AlertDialog(
            onDismissRequest = { confirmImport = false },
            title = { Text(stringResource(R.string.import_backup)) },
            text = { Text(stringResource(R.string.import_warning)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmImport = false
                    importLauncher.launch(arrayOf("application/json", "text/plain"))
                }) { Text(stringResource(R.string.confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmImport = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }

    if (confirmClearData) {
        AlertDialog(
            onDismissRequest = { confirmClearData = false },
            title = { Text(stringResource(R.string.delete_all_app_data)) },
            text = { Text(stringResource(R.string.delete_all_app_data_warning)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmClearData = false
                        context.getSystemService(ActivityManager::class.java)
                            .clearApplicationUserData()
                    },
                ) { Text(stringResource(R.string.delete_all_app_data_confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearData = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }
}
