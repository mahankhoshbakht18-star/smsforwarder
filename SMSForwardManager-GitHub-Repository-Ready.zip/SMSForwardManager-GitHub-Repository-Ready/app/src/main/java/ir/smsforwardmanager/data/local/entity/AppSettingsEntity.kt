package ir.smsforwardmanager.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import ir.smsforwardmanager.core.model.AppLanguage
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.core.model.ThemeMode
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey
    @ColumnInfo(name = "id")
    val id: Int = SINGLETON_ID,
    @ColumnInfo(name = "master_forwarding_enabled")
    val masterForwardingEnabled: Boolean = false,
    @ColumnInfo(name = "default_subscription_id")
    val defaultSubscriptionId: Int? = null,
    @ColumnInfo(name = "default_otp_regex")
    val defaultOtpRegex: String = DEFAULT_OTP_REGEX,
    @ColumnInfo(name = "include_sender_in_forward")
    val includeSenderInForward: Boolean = true,
    @ColumnInfo(name = "forward_prefix")
    val forwardPrefix: String = "ارسال خودکار",
    @ColumnInfo(name = "log_retention_days")
    val logRetentionDays: Int = 90,
    @ColumnInfo(name = "theme_mode")
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    @ColumnInfo(name = "dynamic_color_enabled")
    val dynamicColorEnabled: Boolean = false,
    @ColumnInfo(name = "language")
    val language: AppLanguage = AppLanguage.SYSTEM,
    @ColumnInfo(name = "delivery_mode", defaultValue = "'SMS_ONLY'")
    val deliveryMode: DeliveryMode = DeliveryMode.SMS_ONLY,
    @ColumnInfo(name = "internet_endpoint", defaultValue = "''")
    val internetEndpoint: String = "",
    @ColumnInfo(name = "internet_connect_timeout_seconds", defaultValue = "15")
    val internetConnectTimeoutSeconds: Int = 15,
    @ColumnInfo(name = "internet_read_timeout_seconds", defaultValue = "20")
    val internetReadTimeoutSeconds: Int = 20,
    @ColumnInfo(name = "max_send_attempts", defaultValue = "3")
    val maxSendAttempts: Int = 3,
    @ColumnInfo(name = "retry_delay_seconds", defaultValue = "60")
    val retryDelaySeconds: Int = 60,
    @ColumnInfo(name = "hourly_sms_limit", defaultValue = "20")
    val hourlySmsLimit: Int = 20,
    @ColumnInfo(name = "app_lock_enabled", defaultValue = "0")
    val appLockEnabled: Boolean = false,
    @ColumnInfo(name = "mahanbot_otp_enabled", defaultValue = "0")
    val mahanBotOtpEnabled: Boolean = false,
    @ColumnInfo(name = "mahanbot_national_id", defaultValue = "''")
    val mahanBotNationalId: String = "",
    @ColumnInfo(name = "mahanbot_endpoint", defaultValue = "''")
    val mahanBotEndpoint: String = "",
    @ColumnInfo(name = "mahanbot_sms_keyword", defaultValue = "'سامانه ازدواج'")
    val mahanBotSmsKeyword: String = "سامانه ازدواج",
    @ColumnInfo(name = "mahanbot_consent_accepted_at")
    val mahanBotConsentAcceptedAt: Long? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis(),
) {
    companion object {
        const val SINGLETON_ID = 1
        const val DEFAULT_OTP_REGEX = "(?<!\\d)\\d{4,8}(?!\\d)"
    }
}
