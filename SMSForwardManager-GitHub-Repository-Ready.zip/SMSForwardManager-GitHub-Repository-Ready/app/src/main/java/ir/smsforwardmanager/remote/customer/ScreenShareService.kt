package ir.smsforwardmanager.remote.customer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import androidx.core.app.NotificationCompat
import ir.smsforwardmanager.MainActivity
import ir.smsforwardmanager.R
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

@AndroidEntryPoint
class ScreenShareService : Service() {
    @Inject lateinit var injectedApi: RemoteSessionApi
    private lateinit var api: RemoteSessionApi
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private var remoteSocket: RemoteSocket? = null
    private var serverUrl: String = ""
    private var clientToken: String = ""
    private var paused = false
    private var stopped = false
    private var lastFrameAt = 0L

    override fun onCreate() {
        super.onCreate()
        api = injectedApi
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startSharing(intent)
            ACTION_PAUSE -> setPaused(true)
            ACTION_RESUME -> setPaused(false)
            ACTION_STOP -> stopSharing(null)
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSharing(null)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        releaseCapture()
        super.onDestroy()
    }

    private fun startSharing(intent: Intent) {
        if (projection != null) return
        stopped = false
        serverUrl = intent.getStringExtra(EXTRA_SERVER_URL).orEmpty()
        clientToken = intent.getStringExtra(EXTRA_CLIENT_TOKEN).orEmpty()
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (serverUrl.isBlank() || clientToken.isBlank() || resultData == null) {
            stopSharing("Invalid session")
            return
        }

        startForeground(
            NOTIFICATION_ID,
            buildNotification(paused = false),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION,
        )
        val manager = getSystemService(MediaProjectionManager::class.java)
        val mediaProjection = manager.getMediaProjection(resultCode, resultData)
        projection = mediaProjection
        mediaProjection.registerCallback(
            object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSharing(null)
                }
            },
            Handler(mainLooper),
        )

        captureThread = HandlerThread("RemoteAssistCapture").also { it.start() }
        captureHandler = Handler(captureThread!!.looper)
        configureVirtualDisplay(mediaProjection)
        ShareSessionState.update {
            ShareUiState(
                running = true,
                paused = false,
                relayConnected = false,
                operatorConnected = false,
            )
        }
        remoteSocket = RemoteSocket(
            serverUrl = serverUrl,
            token = clientToken,
            api = api,
            onRelayConnected = {
                ShareSessionState.update {
                    it.copy(relayConnected = true, statusMessage = null)
                }
            },
            onOperatorConnectionChanged = { connected ->
                ShareSessionState.update { it.copy(operatorConnected = connected) }
            },
            onInstruction = { instruction ->
                ShareSessionState.update { it.copy(instruction = instruction) }
                updateNotification(instruction)
            },
            onError = { message ->
                Handler(mainLooper).post { stopSharing(message) }
            },
        ).also { it.connect() }
        api.postEvent(serverUrl, clientToken, "share_started")
    }

    private fun configureVirtualDisplay(mediaProjection: MediaProjection) {
        val metrics = resources.displayMetrics
        val sourceWidth = metrics.widthPixels.coerceAtLeast(1)
        val sourceHeight = metrics.heightPixels.coerceAtLeast(1)
        val scale = minOf(1.0, MAX_CAPTURE_WIDTH.toDouble() / sourceWidth.toDouble())
        val width = (sourceWidth * scale).roundToInt().coerceAtLeast(1)
        val height = (sourceHeight * scale).roundToInt().coerceAtLeast(1)
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).also { reader ->
            reader.setOnImageAvailableListener({ availableReader ->
                val image = availableReader.acquireLatestImage() ?: return@setOnImageAvailableListener
                image.use {
                    val now = System.currentTimeMillis()
                    if (
                        paused ||
                        remoteSocket?.canSendFrame() != true ||
                        now - lastFrameAt < FRAME_INTERVAL_MS
                    ) return@use
                    lastFrameAt = now
                    encodeFrame(image.width, image.height, image.planes.firstOrNull())?.let { bytes ->
                        remoteSocket?.sendFrame(bytes)
                    }
                }
            }, captureHandler)
        }
        virtualDisplay = mediaProjection.createVirtualDisplay(
            "RemoteAssistVisibleShare",
            width,
            height,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null,
            captureHandler,
        )
    }

    private fun encodeFrame(width: Int, height: Int, plane: android.media.Image.Plane?): ByteArray? {
        plane ?: return null
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width
        val paddedWidth = width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        return try {
            plane.buffer.rewind()
            padded.copyPixelsFromBuffer(plane.buffer)
            val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
            try {
                ByteArrayOutputStream().use { output ->
                    cropped.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, output)
                    output.toByteArray().takeIf { it.size <= MAX_FRAME_BYTES }
                }
            } finally {
                cropped.recycle()
            }
        } finally {
            padded.recycle()
        }
    }

    private fun setPaused(value: Boolean) {
        if (projection == null) {
            stopSelf()
            return
        }
        paused = value
        remoteSocket?.sendState(if (paused) "paused" else "active")
        ShareSessionState.update { it.copy(paused = paused) }
        api.postEvent(serverUrl, clientToken, if (paused) "share_paused" else "share_resumed")
        updateNotification()
    }

    private fun stopSharing(message: String?) {
        if (stopped) return
        stopped = true
        if (serverUrl.isNotBlank() && clientToken.isNotBlank()) {
            remoteSocket?.sendState("stopped")
            api.postEvent(serverUrl, clientToken, "share_stopped")
        }
        releaseCapture()
        ShareSessionState.reset(message)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releaseCapture() {
        imageReader?.setOnImageAvailableListener(null, null)
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.stop()
        projection = null
        remoteSocket?.close()
        remoteSocket = null
        captureThread?.quitSafely()
        captureThread = null
        captureHandler = null
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                getString(R.string.customer_remote_notification_channel),
                NotificationManager.IMPORTANCE_HIGH,
            ).apply {
                description = getString(R.string.customer_remote_notification_channel_desc)
                setSound(null, null)
                enableVibration(false)
            },
        )
    }

    private fun updateNotification(instruction: String? = ShareSessionState.state.value.instruction) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(paused, instruction))
    }

    private fun buildNotification(paused: Boolean, instruction: String? = null): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            10,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val toggleAction = if (paused) ACTION_RESUME else ACTION_PAUSE
        val toggleLabel = getString(if (paused) R.string.customer_remote_resume else R.string.customer_remote_pause)
        val toggleIntent = PendingIntent.getService(
            this,
            11,
            Intent(this, ScreenShareService::class.java).setAction(toggleAction),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val stopIntent = PendingIntent.getService(
            this,
            12,
            Intent(this, ScreenShareService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_remote_assist)
            .setContentTitle(getString(if (paused) R.string.customer_remote_notification_paused else R.string.customer_remote_notification_active))
            .setContentText(
                instruction?.let { getString(R.string.customer_remote_notification_instruction, it) }
                    ?: getString(R.string.customer_remote_notification_text),
            )
            .setStyle(NotificationCompat.BigTextStyle())
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .addAction(0, toggleLabel, toggleIntent)
            .addAction(0, getString(R.string.customer_remote_stop), stopIntent)
            .build()
    }

    companion object {
        const val ACTION_START = "ir.smsforwardmanager.action.REMOTE_START"
        const val ACTION_PAUSE = "ir.smsforwardmanager.action.REMOTE_PAUSE"
        const val ACTION_RESUME = "ir.smsforwardmanager.action.REMOTE_RESUME"
        const val ACTION_STOP = "ir.smsforwardmanager.action.REMOTE_STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_SERVER_URL = "server_url"
        const val EXTRA_CLIENT_TOKEN = "client_token"
        private const val CHANNEL_ID = "visible_screen_share"
        private const val NOTIFICATION_ID = 2201
        private const val MAX_CAPTURE_WIDTH = 720
        private const val FRAME_INTERVAL_MS = 500L
        private const val JPEG_QUALITY = 52
        private const val MAX_FRAME_BYTES = 1_100_000
    }
}

private class RemoteSocket(
    private val serverUrl: String,
    private val token: String,
    private val api: RemoteSessionApi,
    private val onRelayConnected: () -> Unit,
    private val onOperatorConnectionChanged: (Boolean) -> Unit,
    private val onInstruction: (String) -> Unit,
    private val onError: (String) -> Unit,
) : WebSocketListener() {
    private var socket: WebSocket? = null
    @Volatile private var authenticated = false
    @Volatile private var operatorConnected = false
    @Volatile private var closing = false

    fun connect() {
        val base = serverUrl.trimEnd('/').toHttpUrlOrNull()
        if (base == null) {
            onError("Invalid server URL")
            return
        }
        val socketUrl = base.newBuilder()
            .scheme(if (base.isHttps) "wss" else "ws")
            .encodedPath("/ws")
            .query(null)
            .fragment(null)
            .build()
        val client = api.webSocketClient().newBuilder()
            .pingInterval(20, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build()
        socket = client.newWebSocket(Request.Builder().url(socketUrl).build(), this)
    }

    override fun onOpen(webSocket: WebSocket, response: Response) {
        webSocket.send(JSONObject().put("type", "authenticate").put("token", token).toString())
    }

    override fun onMessage(webSocket: WebSocket, text: String) {
        val message = runCatching { JSONObject(text) }.getOrNull() ?: return
        when (message.optString("type")) {
            "authenticated" -> {
                authenticated = true
                onRelayConnected()
                sendState("active")
            }
            "peerState" -> {
                if (message.optString("role") == "operator") {
                    operatorConnected = message.optString("state") == "connected"
                    onOperatorConnectionChanged(operatorConnected)
                }
            }
            "instruction" -> message.optString("text").takeIf { it.isNotBlank() }?.let(onInstruction)
            "error" -> onError(message.optString("message", "Remote error"))
        }
    }

    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
        authenticated = false
        operatorConnected = false
        onOperatorConnectionChanged(false)
        onError(t.message ?: "Connection failed")
        response?.close()
    }

    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
        authenticated = false
        operatorConnected = false
        onOperatorConnectionChanged(false)
        if (!closing) onError(reason.ifBlank { "Connection ended" })
    }

    fun canSendFrame(): Boolean = authenticated && operatorConnected

    fun sendFrame(bytes: ByteArray) {
        if (canSendFrame()) socket?.send(bytes.toByteString())
    }

    fun sendState(state: String) {
        if (authenticated) {
            socket?.send(JSONObject().put("type", "shareState").put("state", state).toString())
        }
    }

    fun close() {
        closing = true
        authenticated = false
        operatorConnected = false
        onOperatorConnectionChanged(false)
        socket?.close(1000, "customer stopped sharing")
        socket = null
    }
}
