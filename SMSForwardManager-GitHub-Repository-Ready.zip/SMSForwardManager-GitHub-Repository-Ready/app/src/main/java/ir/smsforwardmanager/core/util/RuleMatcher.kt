package ir.smsforwardmanager.core.util

import ir.smsforwardmanager.core.model.KeywordLogic
import ir.smsforwardmanager.core.model.MatchMode
import ir.smsforwardmanager.data.local.entity.RuleEntity
import ir.smsforwardmanager.data.local.relation.RuleWithDetails
import java.util.Calendar

object RuleMatcher {
    fun matches(
        ruleDetails: RuleWithDetails,
        sender: String,
        message: String,
        nowMillis: Long = System.currentTimeMillis(),
    ): Boolean {
        val rule = ruleDetails.rule
        if (!rule.isEnabled || !isActiveAt(rule, nowMillis)) return false

        val senderMatches = rule.senderPattern
            ?.trim()
            ?.takeIf(String::isNotEmpty)
            ?.let { pattern ->
                val normalizedSender = PhoneNormalizer.normalizeSender(sender)
                val normalizedPattern = PhoneNormalizer.normalizeSender(pattern)
                compare(normalizedSender, normalizedPattern, rule.senderMatchMode, true)
            }
            ?: true

        if (!senderMatches) return false

        val containsExcludedKeyword = rule.excludedKeywords
            .map(String::trim)
            .filter(String::isNotEmpty)
            .any { excluded ->
                compare(message, excluded, MatchMode.CONTAINS, rule.isCaseSensitive)
            }
        if (containsExcludedKeyword) return false

        val keywords = ruleDetails.keywords.map { it.value.trim() }.filter(String::isNotEmpty)
        if (keywords.isEmpty()) return true

        val results = keywords.map { keyword ->
            compare(message, keyword, rule.keywordMatchMode, rule.isCaseSensitive)
        }
        return when (rule.keywordLogic) {
            KeywordLogic.ANY -> results.any { it }
            KeywordLogic.ALL -> results.all { it }
        }
    }

    fun isActiveAt(rule: RuleEntity, nowMillis: Long): Boolean {
        val calendar = Calendar.getInstance().apply { timeInMillis = nowMillis }
        val dayBit = 1 shl (calendar.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY)
        if (rule.activeDaysMask and dayBit == 0) return false

        val start = rule.activeStartMinute
        val end = rule.activeEndMinute
        if (start == null && end == null) return true
        val safeStart = (start ?: 0).coerceIn(0, 1439)
        val safeEnd = (end ?: 1439).coerceIn(0, 1439)
        val minuteOfDay = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
        return if (safeStart <= safeEnd) {
            minuteOfDay in safeStart..safeEnd
        } else {
            // Overnight range, for example 22:00–06:00.
            minuteOfDay >= safeStart || minuteOfDay <= safeEnd
        }
    }

    private fun compare(
        source: String,
        pattern: String,
        mode: MatchMode,
        caseSensitive: Boolean,
    ): Boolean {
        val sourceValue = if (caseSensitive) source else source.lowercase()
        val patternValue = if (caseSensitive) pattern else pattern.lowercase()
        return when (mode) {
            MatchMode.CONTAINS -> sourceValue.contains(patternValue)
            MatchMode.STARTS_WITH -> sourceValue.startsWith(patternValue)
            MatchMode.EXACT -> sourceValue == patternValue
        }
    }
}
