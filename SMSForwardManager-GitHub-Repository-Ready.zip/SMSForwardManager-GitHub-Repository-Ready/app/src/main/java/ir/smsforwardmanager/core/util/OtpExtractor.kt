package ir.smsforwardmanager.core.util

object OtpExtractor {
    fun extract(message: String, pattern: String): String? = runCatching {
        val match = Regex(pattern).find(PhoneNormalizer.toLatinDigits(message)) ?: return null
        match.groupValues.drop(1).firstOrNull { it.isNotBlank() } ?: match.value
    }.getOrNull()

    fun isValidPattern(pattern: String): Boolean = runCatching { Regex(pattern) }.isSuccess
}
