package ir.smsforwardmanager.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.smsforwardmanager.core.model.DeliveryMethod
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.core.model.ForwardMode
import ir.smsforwardmanager.core.model.ForwardStatus
import kotlinx.serialization.Serializable

@Serializable
@Entity(
    tableName = "forward_attempts",
    foreignKeys = [
        ForeignKey(
            entity = IncomingMessageEntity::class,
            parentColumns = ["id"],
            childColumns = ["incoming_message_id"],
            onDelete = ForeignKey.CASCADE,
            onUpdate = ForeignKey.CASCADE,
        ),
        ForeignKey(
            entity = RuleEntity::class,
            parentColumns = ["id"],
            childColumns = ["rule_id"],
            onDelete = ForeignKey.SET_NULL,
            onUpdate = ForeignKey.CASCADE,
        ),
        ForeignKey(
            entity = DestinationEntity::class,
            parentColumns = ["id"],
            childColumns = ["destination_id"],
            onDelete = ForeignKey.SET_NULL,
            onUpdate = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["incoming_message_id"]),
        Index(value = ["rule_id"]),
        Index(value = ["destination_id"]),
        Index(value = ["status"]),
        Index(value = ["queued_at"]),
        Index(
            value = ["incoming_message_id", "rule_id", "destination_address_snapshot"],
            unique = true,
        ),
    ],
)
data class ForwardAttemptEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0,
    @ColumnInfo(name = "incoming_message_id")
    val incomingMessageId: Long,
    @ColumnInfo(name = "rule_id")
    val ruleId: Long? = null,
    @ColumnInfo(name = "destination_id")
    val destinationId: Long? = null,
    @ColumnInfo(name = "destination_address_snapshot")
    val destinationAddressSnapshot: String,
    @ColumnInfo(name = "payload")
    val payload: String,
    @ColumnInfo(name = "forward_mode")
    val forwardMode: ForwardMode,
    @ColumnInfo(name = "delivery_mode", defaultValue = "'SMS_ONLY'")
    val deliveryMode: DeliveryMode = DeliveryMode.SMS_ONLY,
    @ColumnInfo(name = "delivered_via")
    val deliveredVia: DeliveryMethod? = null,
    @ColumnInfo(name = "remote_reference")
    val remoteReference: String? = null,
    @ColumnInfo(name = "status")
    val status: ForwardStatus = ForwardStatus.PENDING,
    @ColumnInfo(name = "attempt_count")
    val attemptCount: Int = 0,
    @ColumnInfo(name = "part_count")
    val partCount: Int = 1,
    @ColumnInfo(name = "sent_part_count")
    val sentPartCount: Int = 0,
    @ColumnInfo(name = "delivered_part_count")
    val deliveredPartCount: Int = 0,
    @ColumnInfo(name = "error_code")
    val errorCode: Int? = null,
    @ColumnInfo(name = "error_message")
    val errorMessage: String? = null,
    @ColumnInfo(name = "subscription_id")
    val subscriptionId: Int? = null,
    @ColumnInfo(name = "work_request_id")
    val workRequestId: String? = null,
    @ColumnInfo(name = "queued_at")
    val queuedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "sent_at")
    val sentAt: Long? = null,
    @ColumnInfo(name = "delivered_at")
    val deliveredAt: Long? = null,
    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis(),
)
