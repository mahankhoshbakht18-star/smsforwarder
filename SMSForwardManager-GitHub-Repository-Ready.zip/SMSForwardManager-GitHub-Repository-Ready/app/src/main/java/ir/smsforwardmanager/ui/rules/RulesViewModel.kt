package ir.smsforwardmanager.ui.rules

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import ir.smsforwardmanager.data.local.relation.RuleWithDetails
import ir.smsforwardmanager.data.repository.RuleRepository
import ir.smsforwardmanager.data.repository.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class RulesUiState(
    val rules: List<RuleWithDetails> = emptyList(),
    val settings: AppSettingsEntity = AppSettingsEntity(),
    val isLoading: Boolean = true,
)

@HiltViewModel
class RulesViewModel @Inject constructor(
    private val ruleRepository: RuleRepository,
    private val settingsRepository: SettingsRepository,
) : ViewModel() {
    val uiState = combine(
        ruleRepository.observeRules(),
        settingsRepository.settings,
    ) { rules, settings ->
        RulesUiState(rules = rules, settings = settings, isLoading = false)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = RulesUiState(),
    )

    fun setMasterEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setMasterEnabled(enabled) }
    }

    fun setRuleEnabled(ruleId: Long, enabled: Boolean) {
        viewModelScope.launch { ruleRepository.setEnabled(ruleId, enabled) }
    }

    fun duplicateRule(details: RuleWithDetails, copyName: String) {
        viewModelScope.launch { ruleRepository.duplicate(details, copyName) }
    }

    fun deleteRule(ruleId: Long) {
        viewModelScope.launch { ruleRepository.delete(ruleId) }
    }
}
