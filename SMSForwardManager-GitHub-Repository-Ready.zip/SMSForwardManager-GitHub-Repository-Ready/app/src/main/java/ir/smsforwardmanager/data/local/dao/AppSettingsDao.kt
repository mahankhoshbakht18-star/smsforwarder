package ir.smsforwardmanager.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AppSettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    fun observe(): Flow<AppSettingsEntity?>

    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    suspend fun get(): AppSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertDefault(settings: AppSettingsEntity = AppSettingsEntity()): Long

    @Update(onConflict = OnConflictStrategy.ABORT)
    suspend fun update(settings: AppSettingsEntity): Int

    @Query(
        """
        UPDATE app_settings
        SET master_forwarding_enabled = :enabled,
            updated_at = :updatedAt
        WHERE id = 1
        """,
    )
    suspend fun setMasterForwardingEnabled(
        enabled: Boolean,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int
}

