package ir.smsforwardmanager.network

import ir.smsforwardmanager.security.MahanBotDeviceIdentity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

sealed interface MahanBotConnectionTestResult {
    data object Reachable : MahanBotConnectionTestResult
    data object Unauthorized : MahanBotConnectionTestResult
    data object ApplicantNotFound : MahanBotConnectionTestResult
    data object Failed : MahanBotConnectionTestResult
}

@Singleton
class MahanBotConnectionTester @Inject constructor(
    private val baseHttpClient: OkHttpClient,
    private val deviceIdentity: MahanBotDeviceIdentity,
) {
    suspend fun test(endpoint: String, token: String, nationalId: String): MahanBotConnectionTestResult =
        withContext(Dispatchers.IO) {
            val statusUrl = MahanBotEndpointValidator.statusUrl(endpoint)
                ?: return@withContext MahanBotConnectionTestResult.Failed
            val deviceId = deviceIdentity.getOrCreate()
            val url = "$statusUrl?national_id=$nationalId"
            val request = Request.Builder()
                .url(url)
                .header("Accept", "application/json")
                .header("X-DEVICE-KEY", token.trim())
                .header("X-DEVICE-ID", deviceId)
                .get()
                .build()
            try {
                val client = baseHttpClient.newBuilder()
                    .connectTimeout(15, TimeUnit.SECONDS)
                    .readTimeout(20, TimeUnit.SECONDS)
                    .build()
                client.newCall(request).execute().use { response ->
                    when {
                        response.isSuccessful -> {
                            val body = response.body?.string().orEmpty()
                            if (body.contains("\"applicant_found\":false")) {
                                MahanBotConnectionTestResult.ApplicantNotFound
                            } else {
                                MahanBotConnectionTestResult.Reachable
                            }
                        }
                        response.code == 401 || response.code == 403 ->
                            MahanBotConnectionTestResult.Unauthorized
                        else -> MahanBotConnectionTestResult.Failed
                    }
                }
            } catch (_: Exception) {
                MahanBotConnectionTestResult.Failed
            }
        }
}
