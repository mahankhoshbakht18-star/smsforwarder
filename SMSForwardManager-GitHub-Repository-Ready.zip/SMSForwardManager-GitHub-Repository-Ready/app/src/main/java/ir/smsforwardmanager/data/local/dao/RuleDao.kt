package ir.smsforwardmanager.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import ir.smsforwardmanager.data.local.entity.RuleEntity
import ir.smsforwardmanager.data.local.relation.RuleWithDetails
import kotlinx.coroutines.flow.Flow

@Dao
interface RuleDao {
    @Query("SELECT * FROM rules ORDER BY priority DESC, updated_at DESC")
    fun observeAll(): Flow<List<RuleEntity>>

    @Transaction
    @Query("SELECT * FROM rules ORDER BY priority DESC, updated_at DESC")
    fun observeAllWithDetails(): Flow<List<RuleWithDetails>>

    @Transaction
    @Query("SELECT * FROM rules ORDER BY priority DESC, updated_at DESC")
    suspend fun getAllWithDetails(): List<RuleWithDetails>

    @Transaction
    @Query("SELECT * FROM rules WHERE id = :ruleId LIMIT 1")
    fun observeWithDetails(ruleId: Long): Flow<RuleWithDetails?>

    @Transaction
    @Query("SELECT * FROM rules WHERE id = :ruleId LIMIT 1")
    suspend fun getWithDetails(ruleId: Long): RuleWithDetails?

    @Transaction
    @Query(
        """
        SELECT * FROM rules
        WHERE is_enabled = 1
        ORDER BY priority DESC, id ASC
        """,
    )
    suspend fun getEnabledWithDetails(): List<RuleWithDetails>

    @Query("SELECT * FROM rules WHERE id = :ruleId LIMIT 1")
    suspend fun getById(ruleId: Long): RuleEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(rule: RuleEntity): Long

    @Update(onConflict = OnConflictStrategy.ABORT)
    suspend fun update(rule: RuleEntity): Int

    @Delete
    suspend fun delete(rule: RuleEntity): Int

    @Query("DELETE FROM rules WHERE id = :ruleId")
    suspend fun deleteById(ruleId: Long): Int

    @Query("DELETE FROM rules")
    suspend fun deleteAll(): Int

    @Query(
        """
        UPDATE rules
        SET is_enabled = :enabled, updated_at = :updatedAt
        WHERE id = :ruleId
        """,
    )
    suspend fun setEnabled(
        ruleId: Long,
        enabled: Boolean,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int

    @Query("SELECT COUNT(*) FROM rules")
    fun observeCount(): Flow<Int>
}
