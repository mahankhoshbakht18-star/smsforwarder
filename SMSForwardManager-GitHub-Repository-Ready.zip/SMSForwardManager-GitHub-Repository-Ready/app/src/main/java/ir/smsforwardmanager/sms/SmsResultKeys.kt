package ir.smsforwardmanager.sms

import android.telephony.SmsManager

object SmsResultKeys {
    const val GENERIC_FAILURE = "SMS_ERROR_GENERIC_FAILURE"
    const val RADIO_OFF = "SMS_ERROR_RADIO_OFF"
    const val NULL_PDU = "SMS_ERROR_NULL_PDU"
    const val NO_SERVICE = "SMS_ERROR_NO_SERVICE"
    const val LIMIT_EXCEEDED = "SMS_ERROR_LIMIT_EXCEEDED"
    const val SHORT_CODE_NOT_ALLOWED = "SMS_ERROR_SHORT_CODE_NOT_ALLOWED"
    const val SHORT_CODE_NEVER_ALLOWED = "SMS_ERROR_SHORT_CODE_NEVER_ALLOWED"
    const val UNKNOWN = "SMS_ERROR_UNKNOWN"
    const val DELIVERY_FAILED = "SMS_DELIVERY_FAILED"

    fun sentErrorKey(resultCode: Int): String = when (resultCode) {
        SmsManager.RESULT_ERROR_GENERIC_FAILURE -> GENERIC_FAILURE
        SmsManager.RESULT_ERROR_RADIO_OFF -> RADIO_OFF
        SmsManager.RESULT_ERROR_NULL_PDU -> NULL_PDU
        SmsManager.RESULT_ERROR_NO_SERVICE -> NO_SERVICE
        SmsManager.RESULT_ERROR_LIMIT_EXCEEDED -> LIMIT_EXCEEDED
        SmsManager.RESULT_ERROR_SHORT_CODE_NOT_ALLOWED -> SHORT_CODE_NOT_ALLOWED
        SmsManager.RESULT_ERROR_SHORT_CODE_NEVER_ALLOWED -> SHORT_CODE_NEVER_ALLOWED
        else -> UNKNOWN
    }
}
