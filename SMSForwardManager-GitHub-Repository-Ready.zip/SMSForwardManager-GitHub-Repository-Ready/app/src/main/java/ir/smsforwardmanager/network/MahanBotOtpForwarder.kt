package ir.smsforwardmanager.network

import ir.smsforwardmanager.BuildConfig
import ir.smsforwardmanager.core.util.MessageFingerprint
import ir.smsforwardmanager.core.util.OtpExtractor
import ir.smsforwardmanager.core.util.PhoneNormalizer
import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import ir.smsforwardmanager.domain.processor.ReceivedSms
import ir.smsforwardmanager.security.MahanBotDeviceIdentity
import ir.smsforwardmanager.security.SecureMahanBotTokenStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

sealed interface MahanBotOtpSendResult {
    data object Skipped : MahanBotOtpSendResult
    data object Sent : MahanBotOtpSendResult
    data object Duplicate : MahanBotOtpSendResult
    data class Failed(val retryable: Boolean, val reason: String) : MahanBotOtpSendResult
}

@Singleton
class MahanBotOtpForwarder @Inject constructor(
    private val baseHttpClient: OkHttpClient,
    private val tokenStore: SecureMahanBotTokenStore,
    private val deviceIdentity: MahanBotDeviceIdentity,
) {
    suspend fun sendIfEligible(
        sms: ReceivedSms,
        settings: AppSettingsEntity,
    ): MahanBotOtpSendResult = withContext(Dispatchers.IO) {
        if (!settings.mahanBotOtpEnabled || settings.mahanBotConsentAcceptedAt == null) {
            return@withContext MahanBotOtpSendResult.Skipped
        }
        val nationalId = normalizeNationalId(settings.mahanBotNationalId)
            ?: return@withContext MahanBotOtpSendResult.Failed(false, "MAHANBOT_NID_INVALID")
        val endpoint = MahanBotEndpointValidator.normalize(settings.mahanBotEndpoint)
            ?: return@withContext MahanBotOtpSendResult.Failed(false, "MAHANBOT_ENDPOINT_INVALID")
        val token = tokenStore.getToken().trim()
        if (token.isBlank()) {
            return@withContext MahanBotOtpSendResult.Failed(false, "MAHANBOT_DEVICE_KEY_MISSING")
        }

        val keyword = normalizeForMatch(settings.mahanBotSmsKeyword)
        if (keyword.isNotBlank() && !normalizeForMatch(sms.body).contains(keyword)) {
            return@withContext MahanBotOtpSendResult.Skipped
        }
        val otp = OtpExtractor.extract(sms.body, settings.defaultOtpRegex)
            ?.let(PhoneNormalizer::toLatinDigits)
            ?.filter(Char::isDigit)
            ?.takeIf { it.length in 4..8 }
            ?: return@withContext MahanBotOtpSendResult.Skipped

        val deviceId = deviceIdentity.getOrCreate()
        val fingerprint = MessageFingerprint.create(
            sender = sms.sender,
            body = sms.body,
            receivedAt = sms.receivedAt,
            subscriptionId = sms.subscriptionId,
        )
        val messageId = "sfm-otp-$fingerprint"
        val payload = JSONObject()
            .put("device_id", deviceId)
            .put("message_id", messageId)
            .put("national_id", nationalId)
            .put("otp", otp)
            .put("received_at", sms.receivedAt / 1000.0)
            .put("source", "android")
            .put("consent_version", "1")
            .toString()
            .toRequestBody(JSON_MEDIA_TYPE)

        val request = Request.Builder()
            .url(endpoint)
            .header("Accept", "application/json")
            .header("User-Agent", "SMSForwardManager/${BuildConfig.VERSION_NAME}")
            .header("X-DEVICE-KEY", token)
            .header("X-DEVICE-ID", deviceId)
            .header("Idempotency-Key", messageId)
            .post(payload)
            .build()

        val client = baseHttpClient.newBuilder()
            .connectTimeout(settings.internetConnectTimeoutSeconds.coerceIn(5, 60).toLong(), TimeUnit.SECONDS)
            .readTimeout(settings.internetReadTimeoutSeconds.coerceIn(5, 120).toLong(), TimeUnit.SECONDS)
            .writeTimeout(settings.internetReadTimeoutSeconds.coerceIn(5, 120).toLong(), TimeUnit.SECONDS)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                when {
                    response.isSuccessful -> MahanBotOtpSendResult.Sent
                    response.code == 409 || response.code == 410 || response.code == 404 ->
                        MahanBotOtpSendResult.Failed(false, "MAHANBOT_HTTP_${response.code}")
                    response.code == 401 || response.code == 403 || response.code == 400 ->
                        MahanBotOtpSendResult.Failed(false, "MAHANBOT_HTTP_${response.code}")
                    response.code == 408 || response.code == 425 || response.code == 429 || response.code >= 500 ->
                        MahanBotOtpSendResult.Failed(true, "MAHANBOT_HTTP_${response.code}")
                    else -> MahanBotOtpSendResult.Failed(false, "MAHANBOT_HTTP_${response.code}")
                }
            }
        } catch (_: SocketTimeoutException) {
            MahanBotOtpSendResult.Failed(true, "MAHANBOT_TIMEOUT")
        } catch (_: IOException) {
            MahanBotOtpSendResult.Failed(true, "MAHANBOT_IO_FAILURE")
        } catch (_: Exception) {
            MahanBotOtpSendResult.Failed(false, "MAHANBOT_REQUEST_FAILED")
        }
    }

    private fun normalizeNationalId(value: String): String? = PhoneNormalizer.toLatinDigits(value)
        .filter(Char::isDigit)
        .takeIf { it.length == 10 }

    private fun normalizeForMatch(value: String): String = PhoneNormalizer.toLatinDigits(value)
        .replace('ي', 'ی')
        .replace('ك', 'ک')
        .replace("‌", " ")
        .lowercase()
        .replace(Regex("\\s+"), " ")
        .trim()

    private companion object {
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}
