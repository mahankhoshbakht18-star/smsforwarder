package ir.smsforwardmanager.data.local.relation

import androidx.room.Embedded
import androidx.room.Relation
import ir.smsforwardmanager.data.local.entity.ForwardAttemptEntity
import ir.smsforwardmanager.data.local.entity.IncomingMessageEntity

data class MessageWithAttempts(
    @Embedded
    val message: IncomingMessageEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "incoming_message_id",
    )
    val attempts: List<ForwardAttemptEntity>,
)

