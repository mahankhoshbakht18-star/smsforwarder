package ir.smsforwardmanager.core.util

import java.security.MessageDigest

object MessageFingerprint {
    fun create(sender: String, body: String, receivedAt: Long, subscriptionId: Int?): String {
        val source = "${PhoneNormalizer.normalizeSender(sender)}|$body|$receivedAt|${subscriptionId ?: -1}"
        return MessageDigest.getInstance("SHA-256")
            .digest(source.toByteArray(Charsets.UTF_8))
            .joinToString(separator = "") { byte -> "%02x".format(byte) }
    }
}
