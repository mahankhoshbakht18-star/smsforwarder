package ir.smsforwardmanager.data.local.converter

import androidx.room.TypeConverter
import ir.smsforwardmanager.core.model.AppLanguage
import ir.smsforwardmanager.core.model.DeliveryMethod
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.core.model.ForwardMode
import ir.smsforwardmanager.core.model.ForwardStatus
import ir.smsforwardmanager.core.model.KeywordLogic
import ir.smsforwardmanager.core.model.MatchMode
import ir.smsforwardmanager.core.model.MessageProcessingState
import ir.smsforwardmanager.core.model.RuleDeliveryMode
import ir.smsforwardmanager.core.model.SmsPartDeliveryStatus
import ir.smsforwardmanager.core.model.SmsPartSentStatus
import ir.smsforwardmanager.core.model.ThemeMode
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class DatabaseConverters {
    @TypeConverter
    fun fromMatchMode(value: MatchMode): String = value.name

    @TypeConverter
    fun toMatchMode(value: String): MatchMode = enumOrDefault(value, MatchMode.CONTAINS)

    @TypeConverter
    fun fromKeywordLogic(value: KeywordLogic): String = value.name

    @TypeConverter
    fun toKeywordLogic(value: String): KeywordLogic = enumOrDefault(value, KeywordLogic.ANY)

    @TypeConverter
    fun fromForwardMode(value: ForwardMode): String = value.name

    @TypeConverter
    fun toForwardMode(value: String): ForwardMode = enumOrDefault(value, ForwardMode.FULL_MESSAGE)

    @TypeConverter
    fun fromDeliveryMode(value: DeliveryMode): String = value.name

    @TypeConverter
    fun toDeliveryMode(value: String): DeliveryMode = enumOrDefault(value, DeliveryMode.SMS_ONLY)

    @TypeConverter
    fun fromRuleDeliveryMode(value: RuleDeliveryMode): String = value.name

    @TypeConverter
    fun toRuleDeliveryMode(value: String): RuleDeliveryMode =
        enumOrDefault(value, RuleDeliveryMode.USE_GLOBAL)

    @TypeConverter
    fun fromStringList(value: List<String>): String = Json.encodeToString(value)

    @TypeConverter
    fun toStringList(value: String): List<String> =
        runCatching { Json.decodeFromString<List<String>>(value) }.getOrDefault(emptyList())

    @TypeConverter
    fun fromDeliveryMethod(value: DeliveryMethod?): String? = value?.name

    @TypeConverter
    fun toDeliveryMethod(value: String?): DeliveryMethod? =
        value?.let { enumOrDefault(it, DeliveryMethod.SMS) }

    @TypeConverter
    fun fromMessageProcessingState(value: MessageProcessingState): String = value.name

    @TypeConverter
    fun toMessageProcessingState(value: String): MessageProcessingState =
        enumOrDefault(value, MessageProcessingState.RECEIVED)

    @TypeConverter
    fun fromForwardStatus(value: ForwardStatus): String = value.name

    @TypeConverter
    fun toForwardStatus(value: String): ForwardStatus = enumOrDefault(value, ForwardStatus.PENDING)


    @TypeConverter
    fun fromSmsPartSentStatus(value: SmsPartSentStatus): String = value.name

    @TypeConverter
    fun toSmsPartSentStatus(value: String): SmsPartSentStatus =
        enumOrDefault(value, SmsPartSentStatus.PENDING)

    @TypeConverter
    fun fromSmsPartDeliveryStatus(value: SmsPartDeliveryStatus): String = value.name

    @TypeConverter
    fun toSmsPartDeliveryStatus(value: String): SmsPartDeliveryStatus =
        enumOrDefault(value, SmsPartDeliveryStatus.PENDING)

    @TypeConverter
    fun fromThemeMode(value: ThemeMode): String = value.name

    @TypeConverter
    fun toThemeMode(value: String): ThemeMode = enumOrDefault(value, ThemeMode.SYSTEM)

    @TypeConverter
    fun fromAppLanguage(value: AppLanguage): String = value.name

    @TypeConverter
    fun toAppLanguage(value: String): AppLanguage = enumOrDefault(value, AppLanguage.SYSTEM)

    private inline fun <reified T : Enum<T>> enumOrDefault(value: String, default: T): T =
        runCatching { enumValueOf<T>(value) }.getOrDefault(default)
}
