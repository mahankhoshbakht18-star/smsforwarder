package ir.smsforwardmanager.remote.customer

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

data class RemoteSession(
    val id: String,
    val code: String,
    val requesterName: String,
    val purpose: String,
    val status: String,
    val consentVersion: String,
    val expiresAt: String,
    val retentionUntil: String,
)

@Singleton
class RemoteSessionApi @Inject constructor(
    private val client: OkHttpClient,
) {
    suspend fun fetchSession(serverUrl: String, token: String): RemoteSession =
        withContext(Dispatchers.IO) {
            val request = Request.Builder()
                .url(apiUrl(serverUrl, "api/session"))
                .header("Authorization", "Bearer ${token.trim()}")
                .get()
                .build()
            client.newCall(request).execute().use { response -> parseSessionResponse(response) }
        }

    suspend fun acceptConsent(
        serverUrl: String,
        token: String,
        consentVersion: String,
    ): RemoteSession = withContext(Dispatchers.IO) {
        val payload = JSONObject()
            .put("accepted", true)
            .put("consentVersion", consentVersion)
            .toString()
            .toRequestBody(JSON_MEDIA_TYPE)
        val request = Request.Builder()
            .url(apiUrl(serverUrl, "api/consent"))
            .header("Authorization", "Bearer ${token.trim()}")
            .post(payload)
            .build()
        client.newCall(request).execute().use { response -> parseSessionResponse(response) }
    }

    fun postEvent(serverUrl: String, token: String, eventType: String) {
        val payload = JSONObject()
            .put("eventType", eventType)
            .toString()
            .toRequestBody(JSON_MEDIA_TYPE)
        val request = runCatching {
            Request.Builder()
                .url(apiUrl(serverUrl, "api/events"))
                .header("Authorization", "Bearer ${token.trim()}")
                .post(payload)
                .build()
        }.getOrNull() ?: return

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, error: IOException) = Unit

            override fun onResponse(call: okhttp3.Call, response: Response) {
                response.close()
            }
        })
    }

    fun webSocketClient(): OkHttpClient = client

    private fun apiUrl(serverUrl: String, relativePath: String): HttpUrl {
        val base = serverUrl.trim().trimEnd('/').toHttpUrlOrNull()
            ?: throw IOException("Invalid server URL")
        return base.newBuilder()
            .encodedPath("/${relativePath.trimStart('/')}")
            .query(null)
            .fragment(null)
            .build()
    }

    private fun parseSessionResponse(response: Response): RemoteSession {
        val raw = response.body?.string().orEmpty()
        val json = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
        if (!response.isSuccessful) {
            throw IOException(json.optString("error").ifBlank { "HTTP ${response.code}" })
        }
        val session = json.optJSONObject("session") ?: throw IOException("Missing session")
        return RemoteSession(
            id = session.getString("id"),
            code = session.getString("code"),
            requesterName = session.getString("requesterName"),
            purpose = session.getString("purpose"),
            status = session.getString("status"),
            consentVersion = session.getString("consentVersion"),
            expiresAt = session.getString("expiresAt"),
            retentionUntil = session.getString("retentionUntil"),
        )
    }

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}
