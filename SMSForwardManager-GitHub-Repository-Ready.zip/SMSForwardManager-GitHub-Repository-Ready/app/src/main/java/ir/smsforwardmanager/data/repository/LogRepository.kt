package ir.smsforwardmanager.data.repository

import android.net.Uri
import ir.smsforwardmanager.data.local.SmsForwardDatabase
import ir.smsforwardmanager.data.local.relation.ForwardLogRow
import ir.smsforwardmanager.sms.ForwardingScheduler
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LogRepository @Inject constructor(
    private val database: SmsForwardDatabase,
    private val scheduler: ForwardingScheduler,
    private val exportManager: LogExportManager,
) {
    fun observeLogs(limit: Int = 500): Flow<List<ForwardLogRow>> =
        database.forwardAttemptDao().observeRecentLogs(limit)

    suspend fun export(uri: Uri): Int = exportManager.exportTo(uri)

    suspend fun clear() {
        database.incomingMessageDao().deleteAll()
    }

    suspend fun retry(attemptId: Long) {
        scheduler.cancel(attemptId)
        val changed = database.forwardAttemptDao().resetForRetry(attemptId)
        if (changed > 0) scheduler.enqueue(attemptId)
    }

    suspend fun remove(attemptId: Long) {
        scheduler.cancel(attemptId)
        database.forwardAttemptDao().deleteById(attemptId)
    }

    suspend fun cancel(attemptId: Long) {
        scheduler.cancel(attemptId)
        database.forwardAttemptDao().cancel(attemptId)
    }

    suspend fun removeExpired(retentionDays: Int) {
        val cutoff = System.currentTimeMillis() - retentionDays.coerceAtLeast(1) * 86_400_000L
        database.incomingMessageDao().deleteOlderThan(cutoff)
    }
}
