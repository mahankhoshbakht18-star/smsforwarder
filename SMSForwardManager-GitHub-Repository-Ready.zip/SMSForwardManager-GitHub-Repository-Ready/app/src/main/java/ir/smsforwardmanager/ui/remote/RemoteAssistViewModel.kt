package ir.smsforwardmanager.ui.remote

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.smsforwardmanager.BuildConfig
import ir.smsforwardmanager.remote.customer.RemoteJoinInput
import ir.smsforwardmanager.remote.customer.RemoteSession
import ir.smsforwardmanager.remote.customer.RemoteSessionApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.json.JSONObject
import javax.inject.Inject

data class RemoteAssistUiState(
    val serverUrl: String = "",
    val token: String = "",
    val session: RemoteSession? = null,
    val loading: Boolean = false,
    val acceptingConsent: Boolean = false,
    val error: String? = null,
    val consentScope: Boolean = false,
    val consentControl: Boolean = false,
    val consentSecret: Boolean = false,
    val consentSecure: Boolean = false,
)

@HiltViewModel
class RemoteAssistViewModel @Inject constructor(
    private val api: RemoteSessionApi,
) : ViewModel() {
    private val mutableState = MutableStateFlow(RemoteAssistUiState())
    val state: StateFlow<RemoteAssistUiState> = mutableState.asStateFlow()

    private var lastAutoLoadedJoin: RemoteJoinInput? = null

    fun applyJoinInput(input: RemoteJoinInput) {
        if (!input.isComplete) return
        val normalized = RemoteJoinInput(input.server.trim().trimEnd('/'), input.token.trim())
        mutableState.update {
            it.copy(
                serverUrl = normalized.server,
                token = normalized.token,
                session = if (
                    it.serverUrl == normalized.server && it.token == normalized.token
                ) it.session else null,
                error = null,
            )
        }
        if (lastAutoLoadedJoin != normalized) {
            lastAutoLoadedJoin = normalized
            loadSession()
        }
    }

    fun updateServerUrl(value: String) {
        lastAutoLoadedJoin = null
        mutableState.update {
            it.copy(
                serverUrl = value,
                session = null,
                error = null,
            ).resetConsent()
        }
    }

    fun updateToken(value: String) {
        lastAutoLoadedJoin = null
        val portable = parsePortableSession(value)
        mutableState.update {
            if (portable != null) {
                it.copy(
                    serverUrl = portable.server,
                    token = portable.token,
                    session = null,
                    error = null,
                ).resetConsent()
            } else {
                it.copy(
                    token = value.trim(),
                    session = null,
                    error = null,
                ).resetConsent()
            }
        }
    }

    fun setConsentScope(value: Boolean) = mutableState.update { it.copy(consentScope = value) }
    fun setConsentControl(value: Boolean) = mutableState.update { it.copy(consentControl = value) }
    fun setConsentSecret(value: Boolean) = mutableState.update { it.copy(consentSecret = value) }
    fun setConsentSecure(value: Boolean) = mutableState.update { it.copy(consentSecure = value) }

    fun loadSession() {
        val current = mutableState.value
        if (!validServer(current.serverUrl) || current.token.length < MIN_TOKEN_LENGTH) {
            mutableState.update { it.copy(error = ERROR_INVALID_SESSION, session = null) }
            return
        }
        if (current.loading || current.acceptingConsent) return

        mutableState.update {
            it.copy(loading = true, error = null, session = null).resetConsent()
        }
        viewModelScope.launch {
            runCatching {
                api.fetchSession(current.serverUrl.trim().trimEnd('/'), current.token.trim())
            }.onSuccess { session ->
                mutableState.update {
                    it.copy(loading = false, session = session, error = null)
                }
            }.onFailure { error ->
                mutableState.update {
                    it.copy(
                        loading = false,
                        session = null,
                        error = error.message ?: ERROR_UNKNOWN,
                    )
                }
            }
        }
    }

    fun acceptConsent(onAccepted: (RemoteJoinInput) -> Unit) {
        val current = mutableState.value
        val session = current.session ?: return
        if (!current.allConsentsAccepted || current.acceptingConsent || current.loading) return

        mutableState.update { it.copy(acceptingConsent = true, error = null) }
        viewModelScope.launch {
            runCatching {
                api.acceptConsent(
                    serverUrl = current.serverUrl.trim().trimEnd('/'),
                    token = current.token.trim(),
                    consentVersion = session.consentVersion,
                )
            }.onSuccess { acceptedSession ->
                mutableState.update {
                    it.copy(
                        acceptingConsent = false,
                        session = acceptedSession,
                        error = null,
                    )
                }
                onAccepted(
                    RemoteJoinInput(
                        server = current.serverUrl.trim().trimEnd('/'),
                        token = current.token.trim(),
                    ),
                )
            }.onFailure { error ->
                mutableState.update {
                    it.copy(
                        acceptingConsent = false,
                        error = error.message ?: ERROR_UNKNOWN,
                    )
                }
            }
        }
    }

    private fun validServer(serverUrl: String): Boolean {
        val url = serverUrl.trim().trimEnd('/').toHttpUrlOrNull() ?: return false
        return url.host.isNotBlank() && (url.isHttps || (BuildConfig.DEBUG && url.scheme == "http"))
    }

    private fun parsePortableSession(value: String): RemoteJoinInput? = runCatching {
        val json = JSONObject(value.trim())
        RemoteJoinInput(
            server = json.getString("server").trim().trimEnd('/'),
            token = json.getString("token").trim(),
        ).takeIf { it.isComplete }
    }.getOrNull()

    private fun RemoteAssistUiState.resetConsent(): RemoteAssistUiState = copy(
        consentScope = false,
        consentControl = false,
        consentSecret = false,
        consentSecure = false,
    )

    private val RemoteAssistUiState.allConsentsAccepted: Boolean
        get() = consentScope && consentControl && consentSecret && consentSecure

    companion object {
        const val ERROR_INVALID_SESSION = "invalid_session"
        const val ERROR_UNKNOWN = "unknown"
        private const val MIN_TOKEN_LENGTH = 20
    }
}
