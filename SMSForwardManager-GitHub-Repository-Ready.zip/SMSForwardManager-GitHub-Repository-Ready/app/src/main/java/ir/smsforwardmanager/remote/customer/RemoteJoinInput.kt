package ir.smsforwardmanager.remote.customer

data class RemoteJoinInput(
    val server: String = "",
    val token: String = "",
) {
    val isComplete: Boolean
        get() = server.isNotBlank() && token.isNotBlank()
}
