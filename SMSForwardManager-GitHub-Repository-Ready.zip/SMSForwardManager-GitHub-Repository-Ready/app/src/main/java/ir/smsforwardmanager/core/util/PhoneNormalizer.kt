package ir.smsforwardmanager.core.util

object PhoneNormalizer {
    private val persianDigits = "۰۱۲۳۴۵۶۷۸۹"
    private val arabicDigits = "٠١٢٣٤٥٦٧٨٩"

    fun toLatinDigits(value: String): String = buildString(value.length) {
        value.forEach { character ->
            val persianIndex = persianDigits.indexOf(character)
            val arabicIndex = arabicDigits.indexOf(character)
            append(
                when {
                    persianIndex >= 0 -> ('0'.code + persianIndex).toChar()
                    arabicIndex >= 0 -> ('0'.code + arabicIndex).toChar()
                    else -> character
                },
            )
        }
    }

    fun normalizePhoneNumber(value: String): String {
        val latin = toLatinDigits(value.trim())
        val compact = buildString {
            latin.forEachIndexed { index, character ->
                if (character.isDigit() || (character == '+' && index == 0)) append(character)
            }
        }
        return when {
            compact.startsWith("0098") -> "+98${compact.drop(4)}"
            compact.startsWith("98") && !compact.startsWith("980") -> "+$compact"
            compact.startsWith("0") && compact.length >= 10 -> "+98${compact.drop(1)}"
            else -> compact
        }
    }

    fun normalizeSender(value: String): String {
        val trimmed = toLatinDigits(value.trim())
        val phone = normalizePhoneNumber(trimmed)
        val digitCount = trimmed.count(Char::isDigit)
        return if (digitCount >= 5 && phone.isNotBlank()) phone else {
            trimmed.filterNot(Char::isWhitespace).lowercase()
        }
    }

    fun isPlausibleDestination(value: String): Boolean {
        val normalized = normalizePhoneNumber(value)
        return normalized.count(Char::isDigit) in 8..15
    }
}
