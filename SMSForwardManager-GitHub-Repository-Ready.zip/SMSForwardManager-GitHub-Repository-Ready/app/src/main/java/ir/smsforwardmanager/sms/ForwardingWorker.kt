package ir.smsforwardmanager.sms

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import ir.smsforwardmanager.core.model.DeliveryMethod
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.data.local.dao.ForwardAttemptDao
import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import ir.smsforwardmanager.data.local.entity.ForwardAttemptEntity
import ir.smsforwardmanager.data.repository.SettingsRepository
import ir.smsforwardmanager.network.ConnectivityStatus
import ir.smsforwardmanager.network.InternetForwarder
import ir.smsforwardmanager.network.InternetSendResult
import java.util.concurrent.TimeUnit

@HiltWorker
class ForwardingWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val attemptDao: ForwardAttemptDao,
    private val settingsRepository: SettingsRepository,
    private val internetForwarder: InternetForwarder,
    private val connectivityStatus: ConnectivityStatus,
    private val deliveryTracker: SmsDeliveryTracker,
    private val scheduler: ForwardingScheduler,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val attemptId = inputData.getLong(KEY_ATTEMPT_ID, -1L)
        if (attemptId <= 0) return Result.failure()
        val attempt = attemptDao.getById(attemptId) ?: return Result.failure()
        if (attempt.payload.isBlank()) {
            attemptDao.markFailed(attemptId, ERROR_EMPTY_PAYLOAD, "EMPTY_PAYLOAD")
            return Result.failure()
        }

        val settings = settingsRepository.get()
        val forcedMethod = inputData.getString(KEY_FORCE_METHOD)
            ?.let { value -> runCatching { DeliveryMethod.valueOf(value) }.getOrNull() }

        if (forcedMethod == null && attempt.attemptCount >= settings.maxSendAttempts) {
            attemptDao.markFailed(attemptId, ERROR_MAX_ATTEMPTS, "MAX_SEND_ATTEMPTS_REACHED")
            return Result.failure()
        }

        if (forcedMethod == DeliveryMethod.INTERNET) {
            return sendInternetOnly(attempt, settings)
        }
        if (forcedMethod == DeliveryMethod.SMS) {
            return sendBySms(attempt, settings)
        }

        return when (attempt.deliveryMode) {
            DeliveryMode.SMS_ONLY -> sendBySms(attempt, settings)

            DeliveryMode.INTERNET_ONLY -> sendInternetOnly(attempt, settings)

            DeliveryMode.INTERNET_THEN_SMS,
            DeliveryMode.SMART -> sendInternetThenSms(attempt, settings)

            DeliveryMode.SMS_THEN_INTERNET -> {
                // The SMS API reports success asynchronously. If every sent callback fails,
                // SmsSentReceiver schedules a single idempotent internet fallback.
                sendBySms(attempt, settings)
            }
        }
    }

    private suspend fun sendInternetOnly(
        attempt: ForwardAttemptEntity,
        settings: AppSettingsEntity,
    ): Result {
        attemptDao.markSending(attempt.id, DeliveryMethod.INTERNET)
        return when (val online = internetForwarder.send(attempt, settings)) {
            is InternetSendResult.Success -> {
                attemptDao.markInternetSent(attempt.id, online.remoteReference)
                Result.success()
            }
            is InternetSendResult.Failure -> handleOnlineOnlyFailure(attempt.id, online, settings)
        }
    }

    private suspend fun sendInternetThenSms(
        attempt: ForwardAttemptEntity,
        settings: AppSettingsEntity,
    ): Result {
        val canTryInternet = settings.internetEndpoint.isNotBlank() && connectivityStatus.hasUsableInternet()
        var internetAttempted = false
        if (canTryInternet) {
            internetAttempted = true
            attemptDao.markSending(attempt.id, DeliveryMethod.INTERNET)
            when (val online = internetForwarder.send(attempt, settings)) {
                is InternetSendResult.Success -> {
                    attemptDao.markInternetSent(attempt.id, online.remoteReference)
                    return Result.success()
                }
                is InternetSendResult.Failure -> {
                    // The route is switched before the SMS send so the log always shows the
                    // channel that actually handled the attempt.
                    attemptDao.setDeliveryMethod(attempt.id, DeliveryMethod.SMS)
                }
            }
        }
        return sendBySms(attempt, settings, incrementAttempt = !internetAttempted)
    }

    private suspend fun handleOnlineOnlyFailure(
        attemptId: Long,
        failure: InternetSendResult.Failure,
        settings: AppSettingsEntity,
    ): Result {
        val current = attemptDao.getById(attemptId)
        if (failure.retryable && (current?.attemptCount ?: 1) < settings.maxSendAttempts) {
            attemptDao.markRetryPending(attemptId, failure.code, failure.message)
            return Result.retry()
        }
        attemptDao.markFailed(attemptId, failure.code ?: ERROR_ONLINE, failure.message)
        return Result.failure()
    }

    private suspend fun sendBySms(
        attempt: ForwardAttemptEntity,
        settings: AppSettingsEntity,
        incrementAttempt: Boolean = true,
    ): Result {
        if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.SEND_SMS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            attemptDao.markFailed(attempt.id, ERROR_PERMISSION, "SEND_SMS_PERMISSION_MISSING")
            return Result.failure()
        }

        val oneHourAgo = System.currentTimeMillis() - TimeUnit.HOURS.toMillis(1)
        val recentSmsAttempts = attemptDao.countRecentSmsAttempts(oneHourAgo, attempt.id)
        if (settings.hourlySmsLimit > 0 && recentSmsAttempts >= settings.hourlySmsLimit) {
            attemptDao.markRetryPending(attempt.id, ERROR_HOURLY_LIMIT, "SMS_HOURLY_LIMIT_REACHED")
            scheduler.enqueueRetry(attempt.id, TimeUnit.HOURS.toSeconds(1))
            return Result.success()
        }

        if (incrementAttempt) {
            attemptDao.markSending(attempt.id, DeliveryMethod.SMS)
        } else {
            attemptDao.setDeliveryMethod(attempt.id, DeliveryMethod.SMS)
        }
        return try {
            val smsManager = smsManagerFor(attempt.subscriptionId)
            val parts = smsManager.divideMessage(attempt.payload).ifEmpty {
                arrayListOf(attempt.payload)
            }
            deliveryTracker.initializeAttempt(attempt.id, parts.size)

            val sentIntents = ArrayList<PendingIntent>(parts.size)
            val deliveredIntents = ArrayList<PendingIntent>(parts.size)
            parts.indices.forEach { partIndex ->
                sentIntents += statusPendingIntent(
                    receiver = SmsSentReceiver::class.java,
                    action = ACTION_SMS_SENT,
                    attempt = attempt,
                    partIndex = partIndex,
                    totalParts = parts.size,
                )
                deliveredIntents += statusPendingIntent(
                    receiver = SmsDeliveredReceiver::class.java,
                    action = ACTION_SMS_DELIVERED,
                    attempt = attempt,
                    partIndex = partIndex,
                    totalParts = parts.size,
                )
            }

            if (parts.size == 1) {
                smsManager.sendTextMessage(
                    attempt.destinationAddressSnapshot,
                    null,
                    parts.first(),
                    sentIntents.first(),
                    deliveredIntents.first(),
                )
            } else {
                smsManager.sendMultipartTextMessage(
                    attempt.destinationAddressSnapshot,
                    null,
                    parts,
                    sentIntents,
                    deliveredIntents,
                )
            }
            Result.success()
        } catch (error: Exception) {
            val current = attemptDao.getById(attempt.id)
            if ((current?.attemptCount ?: 1) < settings.maxSendAttempts) {
                attemptDao.markRetryPending(
                    attemptId = attempt.id,
                    errorCode = ERROR_SEND_EXCEPTION,
                    errorMessage = "SMS_SEND_EXCEPTION_${error.javaClass.simpleName}",
                )
                scheduler.enqueueRetry(attempt.id, settings.retryDelaySeconds.toLong())
                Result.success()
            } else {
                attemptDao.markFailed(
                    attemptId = attempt.id,
                    errorCode = ERROR_SEND_EXCEPTION,
                    errorMessage = "SMS_SEND_EXCEPTION_${error.javaClass.simpleName}",
                )
                Result.failure()
            }
        }
    }

    private fun smsManagerFor(subscriptionId: Int?): SmsManager {
        val systemManager = applicationContext.getSystemService(SmsManager::class.java)
        if (subscriptionId == null) return systemManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            systemManager.createForSubscriptionId(subscriptionId)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
        }
    }

    private fun statusPendingIntent(
        receiver: Class<out android.content.BroadcastReceiver>,
        action: String,
        attempt: ForwardAttemptEntity,
        partIndex: Int,
        totalParts: Int,
    ): PendingIntent {
        val intent = Intent(applicationContext, receiver)
            .setAction(action)
            .setPackage(applicationContext.packageName)
            .putExtra(EXTRA_ATTEMPT_ID, attempt.id)
            .putExtra(EXTRA_PART_INDEX, partIndex)
            .putExtra(EXTRA_TOTAL_PARTS, totalParts)
            .putExtra(EXTRA_DESTINATION, attempt.destinationAddressSnapshot)
            .putExtra(EXTRA_ACTION_TYPE, action)
        val requestCode = "${attempt.id}-$partIndex-$action".hashCode()
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or when {
            action == ACTION_SMS_DELIVERED && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
                PendingIntent.FLAG_MUTABLE
            action == ACTION_SMS_DELIVERED -> 0 // Pre-Android 12 must remain fill-in capable for the PDU.
            else -> PendingIntent.FLAG_IMMUTABLE
        }
        return PendingIntent.getBroadcast(
            applicationContext,
            requestCode,
            intent,
            flags,
        )
    }

    companion object {
        const val KEY_ATTEMPT_ID = "attempt_id"
        const val KEY_FORCE_METHOD = "force_method"
        const val EXTRA_ATTEMPT_ID = "attempt_id"
        const val EXTRA_PART_INDEX = "part_index"
        const val EXTRA_TOTAL_PARTS = "total_parts"
        const val EXTRA_DESTINATION = "destination"
        const val EXTRA_ACTION_TYPE = "action_type"
        const val ACTION_SMS_SENT = "ir.smsforwardmanager.action.SMS_SENT"
        const val ACTION_SMS_DELIVERED = "ir.smsforwardmanager.action.SMS_DELIVERED"
        const val ERROR_PERMISSION = -100
        const val ERROR_EMPTY_PAYLOAD = -101
        const val ERROR_SEND_EXCEPTION = -102
        const val ERROR_ONLINE = -103
        const val ERROR_HOURLY_LIMIT = -104
        const val ERROR_MAX_ATTEMPTS = -105
    }
}
