package ir.smsforwardmanager.network

import android.content.Context
import android.os.Build
import dagger.hilt.android.qualifiers.ApplicationContext
import ir.smsforwardmanager.BuildConfig
import ir.smsforwardmanager.data.local.dao.IncomingMessageDao
import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import ir.smsforwardmanager.data.local.entity.ForwardAttemptEntity
import ir.smsforwardmanager.security.SecureApiTokenStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.Retrofit
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

sealed interface InternetSendResult {
    data class Success(val remoteReference: String?) : InternetSendResult
    data class Failure(
        val code: Int?,
        val message: String,
        val retryable: Boolean,
    ) : InternetSendResult
}

/**
 * Sends a matched message through Retrofit/OkHttp to a user-controlled HTTPS endpoint.
 * Redirects are disabled so an authorization header can never be forwarded to another host.
 */
@Singleton
class InternetForwarder @Inject constructor(
    @ApplicationContext private val context: Context,
    private val tokenStore: SecureApiTokenStore,
    private val incomingMessageDao: IncomingMessageDao,
    private val baseHttpClient: OkHttpClient,
) {
    suspend fun send(
        attempt: ForwardAttemptEntity,
        settings: AppSettingsEntity,
    ): InternetSendResult = withContext(Dispatchers.IO) {
        val endpoint = settings.internetEndpoint.trim()
        if (endpoint.isBlank()) {
            return@withContext InternetSendResult.Failure(null, "ONLINE_ENDPOINT_MISSING", false)
        }
        if (!SecureEndpointValidator.isValid(endpoint)) {
            return@withContext InternetSendResult.Failure(null, "ONLINE_ENDPOINT_INVALID", false)
        }

        val incoming = incomingMessageDao.getById(attempt.incomingMessageId)
            ?: return@withContext InternetSendResult.Failure(null, "SOURCE_MESSAGE_MISSING", false)
        val messageId = "sfm-${attempt.incomingMessageId}-${attempt.id}"
        val payload = JSONObject()
            .put("messageId", messageId)
            .put("sender", incoming.sender)
            .put("destination", attempt.destinationAddressSnapshot)
            .put("message", attempt.payload)
            .put("receivedAt", incoming.receivedAt)
            .put("deviceName", deviceName())
            .put("ruleId", attempt.ruleId ?: JSONObject.NULL)
            .toString()
            .toRequestBody(JSON_MEDIA_TYPE)

        val headers = buildMap {
            put("Accept", "application/json")
            put("User-Agent", "SMSForwardManager/${BuildConfig.VERSION_NAME}")
            put("Idempotency-Key", messageId)
            tokenStore.getToken().trim().takeIf(String::isNotEmpty)?.let { token ->
                put("Authorization", "Bearer $token")
            }
        }

        try {
            val response = serviceFor(settings).forward(endpoint, headers, payload)
            val statusCode = response.code()
            val responseBody = runCatching {
                (response.body() ?: response.errorBody())?.use { body ->
                    body.string().take(MAX_RESPONSE_CHARS)
                }.orEmpty()
            }.getOrDefault("")

            if (response.isSuccessful) {
                parseSuccessfulResponse(responseBody)
            } else {
                InternetSendResult.Failure(
                    code = statusCode,
                    message = "ONLINE_HTTP_$statusCode",
                    retryable = statusCode == 408 || statusCode == 425 ||
                        statusCode == 429 || statusCode >= 500,
                )
            }
        } catch (_: SocketTimeoutException) {
            InternetSendResult.Failure(null, "ONLINE_TIMEOUT", true)
        } catch (_: IOException) {
            InternetSendResult.Failure(null, "ONLINE_IO_FAILURE", true)
        } catch (_: Exception) {
            InternetSendResult.Failure(null, "ONLINE_REQUEST_FAILED", false)
        }
    }

    private fun serviceFor(settings: AppSettingsEntity): OnlineApiService {
        val client = baseHttpClient.newBuilder()
            .connectTimeout(
                settings.internetConnectTimeoutSeconds.coerceIn(5, 60).toLong(),
                TimeUnit.SECONDS,
            )
            .readTimeout(
                settings.internetReadTimeoutSeconds.coerceIn(5, 120).toLong(),
                TimeUnit.SECONDS,
            )
            .writeTimeout(
                settings.internetReadTimeoutSeconds.coerceIn(5, 120).toLong(),
                TimeUnit.SECONDS,
            )
            .build()
        return Retrofit.Builder()
            .baseUrl(RETROFIT_BASE_URL)
            .client(client)
            .build()
            .create(OnlineApiService::class.java)
    }

    private fun parseSuccessfulResponse(responseBody: String): InternetSendResult {
        if (responseBody.isBlank()) return InternetSendResult.Success(null)
        return runCatching {
            val json = JSONObject(responseBody)
            if (json.has("success") && !json.optBoolean("success", false)) {
                return InternetSendResult.Failure(null, "ONLINE_SERVER_REJECTED", false)
            }
            val reference = sequenceOf(
                "referenceId",
                "reference",
                "message_id",
                "messageId",
                "id",
            ).map { json.optString(it).trim() }
                .firstOrNull(String::isNotBlank)
            InternetSendResult.Success(reference)
        }.getOrElse {
            // A successful non-JSON response is accepted, but its content is never logged.
            InternetSendResult.Success(null)
        }
    }

    private fun deviceName(): String = buildString {
        append(Build.MANUFACTURER.orEmpty().trim())
        if (isNotEmpty()) append(' ')
        append(Build.MODEL.orEmpty().trim())
    }.trim().ifBlank { context.packageName }

    private companion object {
        const val MAX_RESPONSE_CHARS = 16_384
        const val RETROFIT_BASE_URL = "https://example.invalid/"
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}
