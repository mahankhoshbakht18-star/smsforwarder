package ir.smsforwardmanager.security

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MahanBotDeviceIdentity @Inject constructor(
    @ApplicationContext context: Context,
) {
    private val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun getOrCreate(): String {
        preferences.getString(KEY_DEVICE_ID, null)?.takeIf(String::isNotBlank)?.let { return it }
        val value = "android-" + UUID.randomUUID().toString()
        preferences.edit().putString(KEY_DEVICE_ID, value).commit()
        return value
    }

    private companion object {
        const val PREFERENCES_NAME = "mahanbot_device_identity"
        const val KEY_DEVICE_ID = "device_id"
    }
}
