package ir.smsforwardmanager.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import ir.smsforwardmanager.data.local.entity.DestinationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DestinationDao {
    @Query("SELECT * FROM destinations ORDER BY is_enabled DESC, label COLLATE NOCASE")
    fun observeAll(): Flow<List<DestinationEntity>>

    @Query("SELECT * FROM destinations ORDER BY label COLLATE NOCASE")
    suspend fun getAll(): List<DestinationEntity>

    @Query("SELECT * FROM destinations WHERE is_enabled = 1 ORDER BY label COLLATE NOCASE")
    suspend fun getEnabled(): List<DestinationEntity>

    @Query("SELECT * FROM destinations WHERE id = :destinationId LIMIT 1")
    suspend fun getById(destinationId: Long): DestinationEntity?

    @Query(
        """
        SELECT * FROM destinations
        WHERE normalized_phone_number = :normalizedPhoneNumber
        LIMIT 1
        """,
    )
    suspend fun getByNormalizedPhoneNumber(normalizedPhoneNumber: String): DestinationEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(destination: DestinationEntity): Long

    @Update(onConflict = OnConflictStrategy.ABORT)
    suspend fun update(destination: DestinationEntity): Int

    @Delete
    suspend fun delete(destination: DestinationEntity): Int

    @Query("DELETE FROM destinations")
    suspend fun deleteAll(): Int

    @Query(
        """
        UPDATE destinations
        SET is_enabled = :enabled, updated_at = :updatedAt
        WHERE id = :destinationId
        """,
    )
    suspend fun setEnabled(
        destinationId: Long,
        enabled: Boolean,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int
}
