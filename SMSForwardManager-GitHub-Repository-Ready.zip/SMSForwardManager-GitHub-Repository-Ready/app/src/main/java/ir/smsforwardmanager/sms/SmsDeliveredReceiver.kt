package ir.smsforwardmanager.sms

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsMessage
import dagger.hilt.android.AndroidEntryPoint
import ir.smsforwardmanager.core.model.ForwardStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class SmsDeliveredReceiver : BroadcastReceiver() {
    @Inject lateinit var tracker: SmsDeliveryTracker

    override fun onReceive(context: Context, intent: Intent) {
        val attemptId = intent.getLongExtra(ForwardingWorker.EXTRA_ATTEMPT_ID, -1L)
        val partIndex = intent.getIntExtra(ForwardingWorker.EXTRA_PART_INDEX, -1)
        if (attemptId <= 0 || partIndex < 0) return

        val pendingResult = goAsync()
        val broadcastResult = resultCode
        val pduStatus = readStatusFromPdu(intent)
        val outcome = when {
            pduStatus != null -> deliveryOutcomeFromStatus(pduStatus)
            else -> when (broadcastResult) {
                Activity.RESULT_OK -> DeliveryReportOutcome.DELIVERED
                // A zero broadcast result without a PDU is Activity.RESULT_CANCELED, not the
                // SMS status-report value STATUS_COMPLETE. Keep the send successful but mark
                // delivery as unknown instead of displaying the old false red error.
                Activity.RESULT_CANCELED -> DeliveryReportOutcome.UNKNOWN
                else -> DeliveryReportOutcome.UNKNOWN
            }
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val update = tracker.recordDelivery(
                    attemptId = attemptId,
                    partIndex = partIndex,
                    outcome = outcome,
                    statusCode = pduStatus ?: broadcastResult,
                )
                // A late valid delivery report is allowed to replace a previous unknown timeout.
                if (update?.attempt?.status == ForwardStatus.DELIVERED) {
                    // No additional action is required; the transaction already cleared errors.
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun readStatusFromPdu(intent: Intent): Int? {
        val pdu = intent.extras?.get("pdu") as? ByteArray ?: return null
        val format = intent.getStringExtra("format")
        return runCatching {
            val message = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                SmsMessage.createFromPdu(pdu, format)
            } else {
                @Suppress("DEPRECATION")
                SmsMessage.createFromPdu(pdu)
            }
            message?.status
        }.getOrNull()
    }

    private fun deliveryOutcomeFromStatus(status: Int): DeliveryReportOutcome = when (status) {
        in 0x00..0x1F -> DeliveryReportOutcome.DELIVERED
        in 0x20..0x3F -> DeliveryReportOutcome.PENDING
        in 0x40..0x7F -> DeliveryReportOutcome.FAILED
        else -> DeliveryReportOutcome.UNKNOWN
    }
}
