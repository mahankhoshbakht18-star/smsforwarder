package ir.smsforwardmanager.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.smsforwardmanager.core.model.ForwardStatus
import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import ir.smsforwardmanager.data.repository.LogRepository
import ir.smsforwardmanager.data.repository.RuleRepository
import ir.smsforwardmanager.data.repository.SettingsRepository
import ir.smsforwardmanager.network.ConnectivityStatus
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

data class DashboardUiState(
    val settings: AppSettingsEntity = AppSettingsEntity(),
    val internetAvailable: Boolean = false,
    val activeRuleCount: Int = 0,
    val todayMessageCount: Int = 0,
    val successfulCount: Int = 0,
    val failedCount: Int = 0,
    val queuedCount: Int = 0,
    val lastActivityAt: Long? = null,
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    ruleRepository: RuleRepository,
    logRepository: LogRepository,
    private val connectivityStatus: ConnectivityStatus,
) : ViewModel() {
    val uiState = combine(
        settingsRepository.settings,
        ruleRepository.observeRules(),
        logRepository.observeLogs(),
    ) { settings, rules, logs ->
        val startOfDay = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val today = logs.filter { it.queuedAt >= startOfDay }
        val successfulStates = setOf(
            ForwardStatus.SENT,
            ForwardStatus.SENT_WAITING_DELIVERY,
            ForwardStatus.SENT_DELIVERY_UNKNOWN,
            ForwardStatus.DELIVERED,
        )
        val queuedStates = setOf(
            ForwardStatus.PENDING,
            ForwardStatus.ENQUEUED,
            ForwardStatus.RETRY_PENDING,
            ForwardStatus.SENDING,
        )
        DashboardUiState(
            settings = settings,
            internetAvailable = connectivityStatus.hasUsableInternet(),
            activeRuleCount = rules.count { it.rule.isEnabled },
            todayMessageCount = today.size,
            successfulCount = today.count { it.status in successfulStates },
            failedCount = today.count {
                it.status == ForwardStatus.FAILED || it.status == ForwardStatus.PARTIALLY_FAILED
            },
            queuedCount = logs.count { it.status in queuedStates },
            lastActivityAt = logs.maxOfOrNull { it.queuedAt },
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = DashboardUiState(),
    )

    fun setMasterEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setMasterEnabled(enabled) }
    }
}
