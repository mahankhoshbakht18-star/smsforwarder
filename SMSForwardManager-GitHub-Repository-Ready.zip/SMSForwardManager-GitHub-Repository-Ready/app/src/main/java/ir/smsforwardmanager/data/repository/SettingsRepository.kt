package ir.smsforwardmanager.data.repository

import androidx.room.withTransaction
import ir.smsforwardmanager.data.local.SmsForwardDatabase
import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsRepository @Inject constructor(
    private val database: SmsForwardDatabase,
) {
    private val dao = database.appSettingsDao()

    val settings: Flow<AppSettingsEntity> = dao.observe().map { it ?: AppSettingsEntity() }

    suspend fun get(): AppSettingsEntity = database.withTransaction {
        dao.get() ?: AppSettingsEntity().also { dao.insertDefault(it) }
    }

    suspend fun update(transform: (AppSettingsEntity) -> AppSettingsEntity) {
        database.withTransaction {
            val current = dao.get() ?: AppSettingsEntity().also { dao.insertDefault(it) }
            dao.update(transform(current).copy(id = AppSettingsEntity.SINGLETON_ID, updatedAt = System.currentTimeMillis()))
        }
    }

    suspend fun setMasterEnabled(enabled: Boolean) {
        get()
        dao.setMasterForwardingEnabled(enabled)
    }
}
