package ir.smsforwardmanager.domain.model

import ir.smsforwardmanager.core.model.ForwardMode
import ir.smsforwardmanager.core.model.KeywordLogic
import ir.smsforwardmanager.core.model.MatchMode
import ir.smsforwardmanager.core.model.RuleDeliveryMode

data class DestinationInput(
    val label: String,
    val phoneNumber: String,
)

data class RuleDraft(
    val id: Long = 0,
    val name: String,
    val isEnabled: Boolean = true,
    val priority: Int = 0,
    val senderPattern: String? = null,
    val senderMatchMode: MatchMode = MatchMode.EXACT,
    val keywordMatchMode: MatchMode = MatchMode.CONTAINS,
    val keywordLogic: KeywordLogic = KeywordLogic.ANY,
    val keywords: List<String> = emptyList(),
    val forwardMode: ForwardMode = ForwardMode.FULL_MESSAGE,
    val otpRegex: String? = null,
    val isCaseSensitive: Boolean = false,
    val subscriptionId: Int? = null,
    val stopAfterMatch: Boolean = false,
    val allowSensitiveContent: Boolean = false,
    val excludedKeywords: List<String> = emptyList(),
    val deliveryModeOverride: RuleDeliveryMode = RuleDeliveryMode.USE_GLOBAL,
    val activeDaysMask: Int = 127,
    val activeStartMinute: Int? = null,
    val activeEndMinute: Int? = null,
    val maxForwardsPerDay: Int = 0,
    val prependText: String = "",
    val appendText: String = "",
    val destinations: List<DestinationInput>,
)
