package ir.smsforwardmanager.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import ir.smsforwardmanager.core.model.DeliveryMethod
import ir.smsforwardmanager.core.model.ForwardStatus
import ir.smsforwardmanager.data.local.entity.ForwardAttemptEntity
import ir.smsforwardmanager.data.local.relation.ForwardLogRow
import kotlinx.coroutines.flow.Flow

@Dao
interface ForwardAttemptDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(attempts: List<ForwardAttemptEntity>): List<Long>

    @Query("SELECT * FROM forward_attempts WHERE id = :attemptId LIMIT 1")
    suspend fun getById(attemptId: Long): ForwardAttemptEntity?

    @Update
    suspend fun update(attempt: ForwardAttemptEntity): Int

    @Query(
        """
        SELECT * FROM forward_attempts
        WHERE status IN ('PENDING', 'ENQUEUED', 'RETRY_PENDING', 'SENDING', 'SENT_WAITING_DELIVERY')
        ORDER BY queued_at, id
        """,
    )
    suspend fun getOutstanding(): List<ForwardAttemptEntity>

    @Query(
        """
        SELECT
            fa.id AS attemptId,
            im.id AS messageId,
            fa.rule_id AS ruleId,
            r.name AS ruleName,
            im.received_at AS receivedAt,
            im.sender AS sender,
            im.body AS originalMessage,
            fa.destination_address_snapshot AS destination,
            fa.payload AS forwardedMessage,
            fa.delivery_mode AS deliveryMode,
            fa.delivered_via AS deliveredVia,
            fa.remote_reference AS remoteReference,
            fa.status AS status,
            fa.attempt_count AS attemptCount,
            fa.part_count AS partCount,
            fa.sent_part_count AS sentPartCount,
            fa.delivered_part_count AS deliveredPartCount,
            fa.error_code AS errorCode,
            fa.error_message AS errorMessage,
            fa.queued_at AS queuedAt,
            fa.sent_at AS sentAt,
            fa.delivered_at AS deliveredAt
        FROM forward_attempts AS fa
        INNER JOIN incoming_messages AS im ON im.id = fa.incoming_message_id
        LEFT JOIN rules AS r ON r.id = fa.rule_id
        ORDER BY fa.queued_at DESC, fa.id DESC
        LIMIT :limit
        """,
    )
    fun observeRecentLogs(limit: Int = 500): Flow<List<ForwardLogRow>>

    @Query(
        """
        SELECT
            fa.id AS attemptId,
            im.id AS messageId,
            fa.rule_id AS ruleId,
            r.name AS ruleName,
            im.received_at AS receivedAt,
            im.sender AS sender,
            im.body AS originalMessage,
            fa.destination_address_snapshot AS destination,
            fa.payload AS forwardedMessage,
            fa.delivery_mode AS deliveryMode,
            fa.delivered_via AS deliveredVia,
            fa.remote_reference AS remoteReference,
            fa.status AS status,
            fa.attempt_count AS attemptCount,
            fa.part_count AS partCount,
            fa.sent_part_count AS sentPartCount,
            fa.delivered_part_count AS deliveredPartCount,
            fa.error_code AS errorCode,
            fa.error_message AS errorMessage,
            fa.queued_at AS queuedAt,
            fa.sent_at AS sentAt,
            fa.delivered_at AS deliveredAt
        FROM forward_attempts AS fa
        INNER JOIN incoming_messages AS im ON im.id = fa.incoming_message_id
        LEFT JOIN rules AS r ON r.id = fa.rule_id
        ORDER BY fa.queued_at DESC, fa.id DESC
        LIMIT :limit
        """,
    )
    suspend fun getRecentLogs(limit: Int = 500): List<ForwardLogRow>

    @Query(
        """
        UPDATE forward_attempts
        SET status = :status,
            work_request_id = :workRequestId,
            error_code = NULL,
            error_message = NULL,
            updated_at = :updatedAt
        WHERE id = :attemptId
        """,
    )
    suspend fun markEnqueued(
        attemptId: Long,
        status: ForwardStatus = ForwardStatus.ENQUEUED,
        workRequestId: String,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE forward_attempts
        SET status = 'SENDING',
            delivered_via = :deliveryMethod,
            attempt_count = attempt_count + 1,
            error_code = NULL,
            error_message = NULL,
            updated_at = :updatedAt
        WHERE id = :attemptId
        """,
    )
    suspend fun markSending(
        attemptId: Long,
        deliveryMethod: DeliveryMethod,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE forward_attempts
        SET delivered_via = :deliveryMethod,
            error_code = NULL,
            error_message = NULL,
            updated_at = :updatedAt
        WHERE id = :attemptId
        """,
    )
    suspend fun setDeliveryMethod(
        attemptId: Long,
        deliveryMethod: DeliveryMethod,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE forward_attempts
        SET status = 'RETRY_PENDING',
            error_code = :errorCode,
            error_message = :errorMessage,
            updated_at = :updatedAt
        WHERE id = :attemptId
        """,
    )
    suspend fun markRetryPending(
        attemptId: Long,
        errorCode: Int?,
        errorMessage: String,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE forward_attempts
        SET part_count = :partCount,
            sent_part_count = 0,
            delivered_part_count = 0,
            updated_at = :updatedAt
        WHERE id = :attemptId
        """,
    )
    suspend fun setPartCount(
        attemptId: Long,
        partCount: Int,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE forward_attempts
        SET sent_part_count = MIN(sent_part_count + 1, part_count),
            status = CASE
                WHEN status = 'FAILED' THEN 'FAILED'
                WHEN sent_part_count + 1 >= part_count THEN 'SENT'
                ELSE 'SENDING'
            END,
            sent_at = CASE
                WHEN status != 'FAILED' AND sent_part_count + 1 >= part_count THEN :sentAt
                ELSE sent_at
            END,
            updated_at = :sentAt
        WHERE id = :attemptId
        """,
    )
    suspend fun registerSentPart(
        attemptId: Long,
        sentAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE forward_attempts
        SET delivered_part_count = MIN(delivered_part_count + 1, part_count),
            status = CASE
                WHEN status = 'FAILED' THEN 'FAILED'
                WHEN delivered_part_count + 1 >= part_count THEN 'DELIVERED'
                ELSE status
            END,
            delivered_at = CASE
                WHEN status != 'FAILED' AND delivered_part_count + 1 >= part_count THEN :deliveredAt
                ELSE delivered_at
            END,
            updated_at = :deliveredAt
        WHERE id = :attemptId
        """,
    )
    suspend fun registerDeliveredPart(
        attemptId: Long,
        deliveredAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE forward_attempts
        SET status = 'SENT',
            delivered_via = 'INTERNET',
            remote_reference = :remoteReference,
            part_count = 1,
            sent_part_count = 1,
            delivered_part_count = 0,
            sent_at = :sentAt,
            error_code = NULL,
            error_message = NULL,
            updated_at = :sentAt
        WHERE id = :attemptId
        """,
    )
    suspend fun markInternetSent(
        attemptId: Long,
        remoteReference: String?,
        sentAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE forward_attempts
        SET status = 'SENT',
            sent_at = :sentAt,
            error_code = NULL,
            error_message = NULL,
            updated_at = :sentAt
        WHERE id = :attemptId
        """,
    )
    suspend fun markSent(attemptId: Long, sentAt: Long = System.currentTimeMillis()): Int

    @Query(
        """
        UPDATE forward_attempts
        SET status = 'DELIVERED',
            delivered_at = :deliveredAt,
            error_code = NULL,
            error_message = NULL,
            updated_at = :deliveredAt
        WHERE id = :attemptId
        """,
    )
    suspend fun markDelivered(
        attemptId: Long,
        deliveredAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE forward_attempts
        SET status = 'FAILED',
            error_code = :errorCode,
            error_message = :errorMessage,
            updated_at = :updatedAt
        WHERE id = :attemptId
        """,
    )
    suspend fun markFailed(
        attemptId: Long,
        errorCode: Int?,
        errorMessage: String,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int


    @Query(
        """
        UPDATE forward_attempts
        SET status = 'SENT_DELIVERY_UNKNOWN',
            error_code = NULL,
            error_message = NULL,
            updated_at = :updatedAt
        WHERE id = :attemptId
          AND status = 'SENT_WAITING_DELIVERY'
        """,
    )
    suspend fun markDeliveryUnknownIfWaiting(
        attemptId: Long,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int

    @Query(
        """
        UPDATE forward_attempts
        SET status = 'CANCELLED',
            updated_at = :updatedAt
        WHERE id = :attemptId
          AND status NOT IN ('DELIVERED', 'CANCELLED')
        """,
    )
    suspend fun cancel(
        attemptId: Long,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int


    @Query(
        """
        UPDATE forward_attempts
        SET status = 'PENDING',
            attempt_count = 0,
            work_request_id = NULL,
            error_code = NULL,
            error_message = NULL,
            updated_at = :updatedAt
        WHERE id = :attemptId
          AND status NOT IN ('DELIVERED', 'CANCELLED')
        """,
    )
    suspend fun resetForRetry(
        attemptId: Long,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int


    @Query(
        """
        SELECT COUNT(*) FROM forward_attempts
        WHERE delivered_via = 'SMS'
          AND attempt_count > 0
          AND updated_at >= :sinceEpochMillis
          AND id != :excludeAttemptId
        """,
    )
    suspend fun countRecentSmsAttempts(
        sinceEpochMillis: Long,
        excludeAttemptId: Long,
    ): Int

    @Query(
        """
        SELECT COUNT(*) FROM forward_attempts
        WHERE rule_id = :ruleId
          AND queued_at >= :sinceEpochMillis
          AND status NOT IN ('CANCELLED', 'FAILED')
        """,
    )
    suspend fun countForRuleSince(ruleId: Long, sinceEpochMillis: Long): Int

    @Query("DELETE FROM forward_attempts WHERE id = :attemptId")
    suspend fun deleteById(attemptId: Long): Int

    @Query("DELETE FROM forward_attempts WHERE queued_at < :cutoffEpochMillis")
    suspend fun deleteOlderThan(cutoffEpochMillis: Long): Int
}
