package ir.smsforwardmanager.ui.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Rule
import androidx.compose.material.icons.outlined.CloudDone
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.PauseCircle
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.smsforwardmanager.R
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.ui.components.SectionCard
import java.text.DateFormat
import java.util.Date

@Composable
fun DashboardScreen(
    onOpenRules: () -> Unit,
    onOpenLogs: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenRemoteAssist: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: DashboardViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var confirmEnable by remember { mutableStateOf(false) }
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(stringResource(R.string.dashboard_title), style = MaterialTheme.typography.headlineMedium)
                Text(
                    stringResource(R.string.dashboard_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (state.settings.masterForwardingEnabled) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        MaterialTheme.colorScheme.surfaceContainerHigh
                    },
                ),
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (state.settings.masterForwardingEnabled) {
                                Icons.Outlined.PlayCircle
                            } else {
                                Icons.Outlined.PauseCircle
                            },
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                        )
                        Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(
                                stringResource(R.string.master_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Text(
                                stringResource(
                                    if (state.settings.masterForwardingEnabled) {
                                        R.string.master_on_desc
                                    } else {
                                        R.string.master_off_desc
                                    },
                                ),
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                        Switch(
                            checked = state.settings.masterForwardingEnabled,
                            onCheckedChange = { enabled ->
                                if (enabled) confirmEnable = true else viewModel.setMasterEnabled(false)
                            },
                        )
                    }
                    if (state.settings.masterForwardingEnabled) {
                        OutlinedButton(
                            onClick = { viewModel.setMasterEnabled(false) },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Icon(Icons.Outlined.Warning, contentDescription = null)
                            Text(
                                stringResource(R.string.emergency_stop),
                                modifier = Modifier.padding(start = 8.dp),
                            )
                        }
                    }
                }
            }
        }

        item {
            SectionCard(
                title = stringResource(R.string.dashboard_status_title),
                description = stringResource(R.string.dashboard_status_desc),
            ) {
                StatusRow(
                    label = stringResource(R.string.dashboard_internet),
                    value = stringResource(
                        if (state.internetAvailable) R.string.dashboard_available else R.string.dashboard_unavailable,
                    ),
                    icon = if (state.internetAvailable) Icons.Outlined.CloudDone else Icons.Outlined.CloudOff,
                )
                StatusRow(
                    label = stringResource(R.string.dashboard_delivery_mode),
                    value = deliveryModeLabel(state.settings.deliveryMode),
                    icon = Icons.Outlined.Settings,
                )
                val lastActivity = state.lastActivityAt?.let {
                    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(it))
                } ?: stringResource(R.string.dashboard_no_activity)
                StatusRow(
                    label = stringResource(R.string.dashboard_last_activity),
                    value = lastActivity,
                    icon = Icons.Outlined.History,
                )
            }
        }

        item {
            SectionCard(
                title = stringResource(R.string.dashboard_today_title),
                description = stringResource(R.string.dashboard_today_desc),
            ) {
                StatRow(stringResource(R.string.dashboard_active_rules), state.activeRuleCount)
                StatRow(stringResource(R.string.dashboard_today_messages), state.todayMessageCount)
                StatRow(stringResource(R.string.dashboard_successful), state.successfulCount)
                StatRow(stringResource(R.string.dashboard_failed), state.failedCount)
                StatRow(stringResource(R.string.dashboard_queue), state.queuedCount)
            }
        }

        item {
            SectionCard(
                title = stringResource(R.string.dashboard_shortcuts),
                description = stringResource(R.string.dashboard_shortcuts_desc),
            ) {
                Button(onClick = onOpenRules, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.AutoMirrored.Outlined.Rule, contentDescription = null)
                    Text(stringResource(R.string.nav_rules), modifier = Modifier.padding(start = 8.dp))
                }
                OutlinedButton(onClick = onOpenLogs, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.History, contentDescription = null)
                    Text(stringResource(R.string.nav_logs), modifier = Modifier.padding(start = 8.dp))
                }
                OutlinedButton(onClick = onOpenSettings, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.Settings, contentDescription = null)
                    Text(stringResource(R.string.nav_settings), modifier = Modifier.padding(start = 8.dp))
                }
                OutlinedButton(onClick = onOpenRemoteAssist, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.SupportAgent, contentDescription = null)
                    Text(
                        stringResource(R.string.remote_dashboard_action),
                        modifier = Modifier.padding(start = 8.dp),
                    )
                }
            }
        }
    }

    if (confirmEnable) {
        AlertDialog(
            onDismissRequest = { confirmEnable = false },
            title = { Text(stringResource(R.string.forwarding_consent_title)) },
            text = { Text(stringResource(R.string.forwarding_consent_text)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmEnable = false
                    viewModel.setMasterEnabled(true)
                }) { Text(stringResource(R.string.forwarding_consent_accept)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmEnable = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }
}

@Composable
private fun StatusRow(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(
            value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun StatRow(label: String, value: Int) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value.toString(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun deliveryModeLabel(mode: DeliveryMode): String = stringResource(
    when (mode) {
        DeliveryMode.SMS_ONLY -> R.string.delivery_sms_only
        DeliveryMode.INTERNET_ONLY -> R.string.delivery_internet_only
        DeliveryMode.INTERNET_THEN_SMS,
        DeliveryMode.SMART -> R.string.delivery_internet_then_sms
        DeliveryMode.SMS_THEN_INTERNET -> R.string.delivery_sms_then_internet
    },
)
