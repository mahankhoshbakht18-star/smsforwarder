package ir.smsforwardmanager.network

import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.HeaderMap
import retrofit2.http.HTTP
import retrofit2.http.POST
import retrofit2.http.Url

/** Retrofit contract using an owner-configured absolute HTTPS URL. */
interface OnlineApiService {
    @POST
    suspend fun forward(
        @Url endpoint: String,
        @HeaderMap headers: Map<String, String>,
        @Body body: RequestBody,
    ): Response<ResponseBody>

    @HTTP(method = "OPTIONS", hasBody = false)
    suspend fun probe(
        @Url endpoint: String,
        @HeaderMap headers: Map<String, String>,
    ): Response<ResponseBody>
}
