package ir.smsforwardmanager.di

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import ir.smsforwardmanager.data.local.SmsForwardDatabase
import ir.smsforwardmanager.data.local.dao.AppSettingsDao
import ir.smsforwardmanager.data.local.dao.DestinationDao
import ir.smsforwardmanager.data.local.dao.ForwardAttemptDao
import ir.smsforwardmanager.data.local.dao.IncomingMessageDao
import ir.smsforwardmanager.data.local.dao.RuleDao
import ir.smsforwardmanager.data.local.dao.RuleDestinationDao
import ir.smsforwardmanager.data.local.dao.RuleKeywordDao
import ir.smsforwardmanager.data.local.dao.SmsPartStatusDao
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context,
    ): SmsForwardDatabase =
        Room.databaseBuilder(
            context,
            SmsForwardDatabase::class.java,
            SmsForwardDatabase.DATABASE_NAME,
        )
            .addMigrations(
                SmsForwardDatabase.MIGRATION_1_2,
                SmsForwardDatabase.MIGRATION_2_3,
                SmsForwardDatabase.MIGRATION_3_4,
                SmsForwardDatabase.MIGRATION_4_5,
                SmsForwardDatabase.MIGRATION_5_6,
            )
            .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
            .build()

    @Provides
    fun provideRuleDao(database: SmsForwardDatabase): RuleDao = database.ruleDao()

    @Provides
    fun provideRuleKeywordDao(database: SmsForwardDatabase): RuleKeywordDao =
        database.ruleKeywordDao()

    @Provides
    fun provideDestinationDao(database: SmsForwardDatabase): DestinationDao =
        database.destinationDao()

    @Provides
    fun provideRuleDestinationDao(database: SmsForwardDatabase): RuleDestinationDao =
        database.ruleDestinationDao()

    @Provides
    fun provideIncomingMessageDao(database: SmsForwardDatabase): IncomingMessageDao =
        database.incomingMessageDao()

    @Provides
    fun provideForwardAttemptDao(database: SmsForwardDatabase): ForwardAttemptDao =
        database.forwardAttemptDao()

    @Provides
    fun provideAppSettingsDao(database: SmsForwardDatabase): AppSettingsDao =
        database.appSettingsDao()

    @Provides
    fun provideSmsPartStatusDao(database: SmsForwardDatabase): SmsPartStatusDao =
        database.smsPartStatusDao()
}
