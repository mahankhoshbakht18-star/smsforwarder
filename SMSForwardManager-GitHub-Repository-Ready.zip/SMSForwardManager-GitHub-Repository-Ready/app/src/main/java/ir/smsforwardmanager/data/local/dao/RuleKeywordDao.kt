package ir.smsforwardmanager.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import ir.smsforwardmanager.data.local.entity.RuleKeywordEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RuleKeywordDao {
    @Query("SELECT * FROM rule_keywords WHERE rule_id = :ruleId ORDER BY sort_order, id")
    fun observeForRule(ruleId: Long): Flow<List<RuleKeywordEntity>>

    @Query("SELECT * FROM rule_keywords WHERE rule_id = :ruleId ORDER BY sort_order, id")
    suspend fun getForRule(ruleId: Long): List<RuleKeywordEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAll(keywords: List<RuleKeywordEntity>): List<Long>

    @Query("DELETE FROM rule_keywords WHERE rule_id = :ruleId")
    suspend fun deleteForRule(ruleId: Long): Int
}

