package ir.smsforwardmanager.sms

import android.content.Context
import android.telephony.SubscriptionManager
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import ir.smsforwardmanager.domain.processor.MessageProcessor
import ir.smsforwardmanager.domain.processor.ReceivedSms

@HiltWorker
class IncomingSmsWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val processor: MessageProcessor,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val sender = inputData.getString(KEY_SENDER)?.takeIf(String::isNotBlank)
            ?: return Result.failure()
        val body = inputData.getString(KEY_BODY)?.takeIf(String::isNotBlank)
            ?: return Result.failure()
        val receivedAt = inputData.getLong(KEY_RECEIVED_AT, System.currentTimeMillis())
        val subscriptionId = inputData.getInt(
            KEY_SUBSCRIPTION_ID,
            SubscriptionManager.INVALID_SUBSCRIPTION_ID,
        ).takeIf(SubscriptionManager::isValidSubscriptionId)
        val slotIndex = inputData.getInt(
            KEY_SIM_SLOT_INDEX,
            SubscriptionManager.INVALID_SIM_SLOT_INDEX,
        ).takeIf { it != SubscriptionManager.INVALID_SIM_SLOT_INDEX }

        return runCatching {
            processor.process(
                ReceivedSms(
                    sender = sender,
                    body = body,
                    receivedAt = receivedAt,
                    subscriptionId = subscriptionId,
                    simSlotIndex = slotIndex,
                ),
            )
        }.fold(
            onSuccess = { Result.success() },
            onFailure = { if (runAttemptCount < 2) Result.retry() else Result.failure() },
        )
    }

    companion object {
        const val KEY_SENDER = "sender"
        const val KEY_BODY = "body"
        const val KEY_RECEIVED_AT = "received_at"
        const val KEY_SUBSCRIPTION_ID = "subscription_id"
        const val KEY_SIM_SLOT_INDEX = "sim_slot_index"
    }
}
