package ir.smsforwardmanager.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import ir.smsforwardmanager.core.model.MessageProcessingState
import ir.smsforwardmanager.data.local.entity.IncomingMessageEntity
import ir.smsforwardmanager.data.local.relation.MessageWithAttempts
import kotlinx.coroutines.flow.Flow

@Dao
interface IncomingMessageDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(message: IncomingMessageEntity): Long

    @Query("SELECT id FROM incoming_messages WHERE fingerprint = :fingerprint LIMIT 1")
    suspend fun findIdByFingerprint(fingerprint: String): Long?

    @Transaction
    suspend fun insertOrGetId(message: IncomingMessageEntity): Long {
        val insertedId = insert(message)
        if (insertedId != -1L) return insertedId

        return requireNotNull(findIdByFingerprint(message.fingerprint)) {
            "Message conflict occurred but its existing row could not be found."
        }
    }

    @Query("SELECT * FROM incoming_messages WHERE id = :messageId LIMIT 1")
    suspend fun getById(messageId: Long): IncomingMessageEntity?

    @Transaction
    @Query("SELECT * FROM incoming_messages WHERE id = :messageId LIMIT 1")
    fun observeWithAttempts(messageId: Long): Flow<MessageWithAttempts?>

    @Query("SELECT * FROM incoming_messages ORDER BY received_at DESC LIMIT :limit")
    fun observeRecent(limit: Int = 500): Flow<List<IncomingMessageEntity>>

    @Query(
        """
        UPDATE incoming_messages
        SET processing_state = :state,
            matched_rule_count = :matchedRuleCount,
            error_message = :errorMessage,
            updated_at = :updatedAt
        WHERE id = :messageId
        """,
    )
    suspend fun updateProcessingState(
        messageId: Long,
        state: MessageProcessingState,
        matchedRuleCount: Int,
        errorMessage: String? = null,
        updatedAt: Long = System.currentTimeMillis(),
    ): Int

    @Query("DELETE FROM incoming_messages WHERE received_at < :cutoffEpochMillis")
    suspend fun deleteOlderThan(cutoffEpochMillis: Long): Int

    @Query("DELETE FROM incoming_messages")
    suspend fun deleteAll(): Int
}
