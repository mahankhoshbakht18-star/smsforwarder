package ir.smsforwardmanager

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import ir.smsforwardmanager.sms.MaintenanceScheduler
import javax.inject.Inject

@HiltAndroidApp
class SmsForwardManagerApp : Application(), Configuration.Provider {
    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var maintenanceScheduler: MaintenanceScheduler

    override fun onCreate() {
        super.onCreate()
        maintenanceScheduler.ensureScheduled()
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()
}
