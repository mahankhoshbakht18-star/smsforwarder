package ir.smsforwardmanager.core.util

/** Masks common 4–8 digit one-time codes before text is shown in the local log UI. */
object SensitiveMessageMasker {
    private val codePattern = Regex("(?<!\\d)\\d{4,8}(?!\\d)")

    fun mask(value: String): String = codePattern.replace(value) { match ->
        "•".repeat(match.value.length.coerceAtMost(8))
    }
}
