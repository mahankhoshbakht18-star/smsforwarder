package ir.smsforwardmanager.backup

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import dagger.hilt.android.qualifiers.ApplicationContext
import ir.smsforwardmanager.core.model.DeliveryMode
import ir.smsforwardmanager.data.local.SmsForwardDatabase
import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import ir.smsforwardmanager.data.local.entity.RuleEntity
import ir.smsforwardmanager.data.repository.RuleRepository
import ir.smsforwardmanager.domain.model.DestinationInput
import ir.smsforwardmanager.domain.model.RuleDraft
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Serializable
data class BackupDocument(
    val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
    val exportedAt: Long = System.currentTimeMillis(),
    val settings: AppSettingsEntity,
    val rules: List<BackupRule>,
) {
    companion object {
        const val CURRENT_SCHEMA_VERSION = 3
    }
}

@Serializable
data class BackupRule(
    val rule: RuleEntity,
    val keywords: List<String>,
    val destinations: List<BackupDestination>,
)

@Serializable
data class BackupDestination(
    val label: String,
    val phoneNumber: String,
)

@Singleton
class BackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val database: SmsForwardDatabase,
    private val ruleRepository: RuleRepository,
) {
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    suspend fun exportTo(uri: Uri): Int {
        val settings = database.appSettingsDao().get() ?: AppSettingsEntity()
        val rules = database.ruleDao().getAllWithDetails().map { details ->
            BackupRule(
                rule = details.rule,
                keywords = details.keywords.sortedBy { it.sortOrder }.map { it.value },
                destinations = details.destinationLinks
                    .sortedBy { it.link.sortOrder }
                    .map {
                        BackupDestination(
                            label = it.destination.label,
                            phoneNumber = it.destination.phoneNumber,
                        )
                    },
            )
        }
        val encoded = json.encodeToString(
            BackupDocument.serializer(),
            BackupDocument(
                settings = settings.copy(
                    appLockEnabled = false,
                    mahanBotOtpEnabled = false,
                    mahanBotNationalId = "",
                    mahanBotConsentAcceptedAt = null,
                ),
                rules = rules,
            ),
        )
        check(encoded.length <= MAX_BACKUP_CHARACTERS) { "BACKUP_TOO_LARGE" }
        context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { writer ->
            writer.write(encoded)
        } ?: error("CANNOT_OPEN_BACKUP_DESTINATION")
        return rules.size
    }

    suspend fun importFrom(uri: Uri): Int {
        val encoded = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
            val value = reader.readText()
            check(value.length <= MAX_BACKUP_CHARACTERS) { "BACKUP_TOO_LARGE" }
            value
        } ?: error("CANNOT_OPEN_BACKUP_FILE")
        val document = json.decodeFromString(BackupDocument.serializer(), encoded)
        require(document.schemaVersion in 1..BackupDocument.CURRENT_SCHEMA_VERSION) {
            "UNSUPPORTED_BACKUP_VERSION"
        }

        database.withTransaction {
            database.ruleDao().deleteAll()
            database.destinationDao().deleteAll()
            val settings = document.settings.copy(
                id = AppSettingsEntity.SINGLETON_ID,
                deliveryMode = if (document.settings.deliveryMode == DeliveryMode.SMART) {
                    DeliveryMode.INTERNET_THEN_SMS
                } else {
                    document.settings.deliveryMode
                },
                appLockEnabled = false,
                mahanBotOtpEnabled = false,
                mahanBotNationalId = "",
                mahanBotConsentAcceptedAt = null,
                updatedAt = System.currentTimeMillis(),
            )
            database.appSettingsDao().insertDefault(settings)
            database.appSettingsDao().update(settings)
            document.rules.forEach { backup ->
                val rule = backup.rule
                ruleRepository.save(
                    RuleDraft(
                        name = rule.name,
                        isEnabled = rule.isEnabled,
                        priority = rule.priority,
                        senderPattern = rule.senderPattern,
                        senderMatchMode = rule.senderMatchMode,
                        keywordMatchMode = rule.keywordMatchMode,
                        keywordLogic = rule.keywordLogic,
                        keywords = backup.keywords,
                        forwardMode = rule.forwardMode,
                        otpRegex = rule.otpRegex,
                        isCaseSensitive = rule.isCaseSensitive,
                        subscriptionId = rule.subscriptionId,
                        stopAfterMatch = rule.stopAfterMatch,
                        allowSensitiveContent = rule.allowSensitiveContent,
                        excludedKeywords = rule.excludedKeywords,
                        deliveryModeOverride = rule.deliveryModeOverride,
                        activeDaysMask = rule.activeDaysMask,
                        activeStartMinute = rule.activeStartMinute,
                        activeEndMinute = rule.activeEndMinute,
                        maxForwardsPerDay = rule.maxForwardsPerDay,
                        prependText = rule.prependText,
                        appendText = rule.appendText,
                        destinations = backup.destinations.map {
                            DestinationInput(label = it.label, phoneNumber = it.phoneNumber)
                        },
                    ),
                )
            }
        }
        return document.rules.size
    }

    private companion object {
        const val MAX_BACKUP_CHARACTERS = 2_000_000
    }
}
