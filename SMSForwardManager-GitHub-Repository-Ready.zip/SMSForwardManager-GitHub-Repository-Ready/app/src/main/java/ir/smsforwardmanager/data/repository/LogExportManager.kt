package ir.smsforwardmanager.data.repository

import android.content.Context
import android.net.Uri
import dagger.hilt.android.qualifiers.ApplicationContext
import ir.smsforwardmanager.core.util.SensitiveMessageMasker
import ir.smsforwardmanager.data.local.dao.ForwardAttemptDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/** Creates a local audit export with message codes masked and no API credentials. */
@Singleton
class LogExportManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val attemptDao: ForwardAttemptDao,
) {
    suspend fun exportTo(uri: Uri): Int = withContext(Dispatchers.IO) {
        val logs = attemptDao.getRecentLogs(MAX_EXPORTED_LOGS)
        val items = JSONArray()
        logs.forEach { log ->
            items.put(
                JSONObject()
                    .put("attemptId", log.attemptId)
                    .put("messageId", log.messageId)
                    .put("ruleId", log.ruleId ?: JSONObject.NULL)
                    .put("ruleName", log.ruleName ?: JSONObject.NULL)
                    .put("receivedAt", log.receivedAt)
                    .put("sender", log.sender)
                    .put("destination", log.destination)
                    .put("originalMessageMasked", SensitiveMessageMasker.mask(log.originalMessage))
                    .put("forwardedMessageMasked", SensitiveMessageMasker.mask(log.forwardedMessage))
                    .put("deliveryMode", log.deliveryMode.name)
                    .put("deliveredVia", log.deliveredVia?.name ?: JSONObject.NULL)
                    .put("status", log.status.name)
                    .put("attemptCount", log.attemptCount)
                    .put("partCount", log.partCount)
                    .put("sentPartCount", log.sentPartCount)
                    .put("deliveredPartCount", log.deliveredPartCount)
                    .put("queuedAt", log.queuedAt)
                    .put("sentAt", log.sentAt ?: JSONObject.NULL)
                    .put("deliveredAt", log.deliveredAt ?: JSONObject.NULL),
            )
        }
        val document = JSONObject()
            .put("schemaVersion", 1)
            .put("exportedAt", System.currentTimeMillis())
            .put("sensitiveCodesMasked", true)
            .put("logs", items)
            .toString(2)

        context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { writer ->
            writer.write(document)
        } ?: error("CANNOT_OPEN_LOG_EXPORT_DESTINATION")
        logs.size
    }

    private companion object {
        const val MAX_EXPORTED_LOGS = 5_000
    }
}
