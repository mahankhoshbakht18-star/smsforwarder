package ir.smsforwardmanager.data.repository

import androidx.room.withTransaction
import ir.smsforwardmanager.core.util.PhoneNormalizer
import ir.smsforwardmanager.data.local.SmsForwardDatabase
import ir.smsforwardmanager.data.local.entity.DestinationEntity
import ir.smsforwardmanager.data.local.entity.RuleDestinationCrossRef
import ir.smsforwardmanager.data.local.entity.RuleEntity
import ir.smsforwardmanager.data.local.entity.RuleKeywordEntity
import ir.smsforwardmanager.data.local.relation.RuleWithDetails
import ir.smsforwardmanager.domain.model.RuleDraft
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RuleRepository @Inject constructor(
    private val database: SmsForwardDatabase,
) {
    private val ruleDao = database.ruleDao()
    private val keywordDao = database.ruleKeywordDao()
    private val destinationDao = database.destinationDao()
    private val ruleDestinationDao = database.ruleDestinationDao()

    fun observeRules(): Flow<List<RuleWithDetails>> = ruleDao.observeAllWithDetails()

    fun observeRule(ruleId: Long): Flow<RuleWithDetails?> = ruleDao.observeWithDetails(ruleId)

    suspend fun getRule(ruleId: Long): RuleWithDetails? = ruleDao.getWithDetails(ruleId)

    suspend fun save(draft: RuleDraft): Long = database.withTransaction {
        require(draft.name.isNotBlank()) { "Rule name is required." }
        require(draft.senderPattern?.isNotBlank() == true || draft.keywords.any(String::isNotBlank)) {
            "At least one sender or keyword filter is required."
        }
        require(draft.destinations.isNotEmpty()) { "At least one destination is required." }
        require(draft.destinations.all { PhoneNormalizer.isPlausibleDestination(it.phoneNumber) }) {
            "One or more destination phone numbers are invalid."
        }
        require(draft.activeDaysMask in 1..127) { "At least one active day is required." }
        require((draft.activeStartMinute == null) == (draft.activeEndMinute == null)) {
            "Both active start and end times must be provided together."
        }
        require(draft.activeStartMinute == null || draft.activeStartMinute in 0..1439) {
            "Active start time is invalid."
        }
        require(draft.activeEndMinute == null || draft.activeEndMinute in 0..1439) {
            "Active end time is invalid."
        }
        require(draft.maxForwardsPerDay in 0..10_000) { "Daily forwarding limit is invalid." }

        val now = System.currentTimeMillis()
        val existing = draft.id.takeIf { it > 0 }?.let { ruleDao.getById(it) }
        val entity = RuleEntity(
            id = existing?.id ?: 0,
            name = draft.name.trim(),
            isEnabled = draft.isEnabled,
            priority = draft.priority,
            senderPattern = draft.senderPattern?.trim()?.ifBlank { null },
            senderMatchMode = draft.senderMatchMode,
            keywordMatchMode = draft.keywordMatchMode,
            keywordLogic = draft.keywordLogic,
            forwardMode = draft.forwardMode,
            otpRegex = draft.otpRegex?.trim()?.ifBlank { null },
            isCaseSensitive = draft.isCaseSensitive,
            subscriptionId = draft.subscriptionId,
            stopAfterMatch = draft.stopAfterMatch,
            allowSensitiveContent = draft.allowSensitiveContent,
            excludedKeywords = draft.excludedKeywords
                .map(String::trim)
                .filter(String::isNotBlank)
                .distinct(),
            deliveryModeOverride = draft.deliveryModeOverride,
            activeDaysMask = draft.activeDaysMask.coerceIn(0, 127),
            activeStartMinute = draft.activeStartMinute?.coerceIn(0, 1439),
            activeEndMinute = draft.activeEndMinute?.coerceIn(0, 1439),
            maxForwardsPerDay = draft.maxForwardsPerDay.coerceIn(0, 10_000),
            prependText = draft.prependText.trim(),
            appendText = draft.appendText.trim(),
            createdAt = existing?.createdAt ?: now,
            updatedAt = now,
        )
        val ruleId = if (existing == null) ruleDao.insert(entity) else {
            ruleDao.update(entity)
            entity.id
        }

        keywordDao.deleteForRule(ruleId)
        val cleanKeywords = draft.keywords.map(String::trim).filter(String::isNotBlank).distinct()
        if (cleanKeywords.isNotEmpty()) {
            keywordDao.insertAll(
                cleanKeywords.mapIndexed { index, keyword ->
                    RuleKeywordEntity(ruleId = ruleId, value = keyword, sortOrder = index)
                },
            )
        }

        ruleDestinationDao.deleteForRule(ruleId)
        val links = draft.destinations
            .mapIndexed { index, input ->
                val normalized = PhoneNormalizer.normalizePhoneNumber(input.phoneNumber)
                val current = destinationDao.getByNormalizedPhoneNumber(normalized)
                val destinationId = if (current == null) {
                    destinationDao.insert(
                        DestinationEntity(
                            label = input.label.trim().ifBlank { input.phoneNumber.trim() },
                            phoneNumber = PhoneNormalizer.toLatinDigits(input.phoneNumber.trim()),
                            normalizedPhoneNumber = normalized,
                        ),
                    )
                } else {
                    destinationDao.update(
                        current.copy(
                            label = input.label.trim().ifBlank { current.label },
                            phoneNumber = PhoneNormalizer.toLatinDigits(input.phoneNumber.trim()),
                            isEnabled = true,
                            updatedAt = now,
                        ),
                    )
                    current.id
                }
                RuleDestinationCrossRef(
                    ruleId = ruleId,
                    destinationId = destinationId,
                    isEnabled = true,
                    sortOrder = index,
                )
            }
        ruleDestinationDao.insertAll(links)
        ruleId
    }


    suspend fun duplicate(details: RuleWithDetails, newName: String): Long {
        val rule = details.rule
        return save(
            RuleDraft(
                name = newName,
                isEnabled = false,
                priority = rule.priority,
                senderPattern = rule.senderPattern,
                senderMatchMode = rule.senderMatchMode,
                keywordMatchMode = rule.keywordMatchMode,
                keywordLogic = rule.keywordLogic,
                keywords = details.keywords.sortedBy { it.sortOrder }.map { it.value },
                forwardMode = rule.forwardMode,
                otpRegex = rule.otpRegex,
                isCaseSensitive = rule.isCaseSensitive,
                subscriptionId = rule.subscriptionId,
                stopAfterMatch = rule.stopAfterMatch,
                allowSensitiveContent = rule.allowSensitiveContent,
                excludedKeywords = rule.excludedKeywords,
                deliveryModeOverride = rule.deliveryModeOverride,
                activeDaysMask = rule.activeDaysMask,
                activeStartMinute = rule.activeStartMinute,
                activeEndMinute = rule.activeEndMinute,
                maxForwardsPerDay = rule.maxForwardsPerDay,
                prependText = rule.prependText,
                appendText = rule.appendText,
                destinations = details.destinationLinks
                    .sortedBy { it.link.sortOrder }
                    .map {
                        ir.smsforwardmanager.domain.model.DestinationInput(
                            label = it.destination.label,
                            phoneNumber = it.destination.phoneNumber,
                        )
                    },
            ),
        )
    }

    suspend fun setEnabled(ruleId: Long, enabled: Boolean) {
        ruleDao.setEnabled(ruleId, enabled)
    }

    suspend fun delete(ruleId: Long) {
        ruleDao.deleteById(ruleId)
    }
}
