package ir.smsforwardmanager.ui.logs

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.Replay
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.smsforwardmanager.R
import ir.smsforwardmanager.core.model.DeliveryMethod
import ir.smsforwardmanager.core.model.ForwardStatus
import ir.smsforwardmanager.core.util.SensitiveMessageMasker
import ir.smsforwardmanager.data.local.relation.ForwardLogRow
import ir.smsforwardmanager.ui.components.ChoiceChips
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private enum class LogStatusFilter { ALL, SUCCESS, WAITING, FAILED }
private enum class LogMethodFilter { ALL, SMS, INTERNET }
private enum class LogDateFilter { ALL, TODAY }

@Composable
fun LogsScreen(
    modifier: Modifier = Modifier,
    viewModel: LogsViewModel = hiltViewModel(),
) {
    val logs by viewModel.logs.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    var confirmClear by remember { mutableStateOf(false) }
    var attemptToDelete by remember { mutableStateOf<Long?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri -> uri?.let(viewModel::export) }

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            val message = when (event) {
                is LogsEvent.Exported -> context.resources.getQuantityString(
                    R.plurals.logs_exported,
                    event.count,
                    event.count,
                )
                LogsEvent.ExportFailed -> context.getString(R.string.logs_export_failed)
            }
            snackbarHostState.showSnackbar(message)
        }
    }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var statusFilter by rememberSaveable { mutableStateOf(LogStatusFilter.ALL) }
    var methodFilter by rememberSaveable { mutableStateOf(LogMethodFilter.ALL) }
    var dateFilter by rememberSaveable { mutableStateOf(LogDateFilter.ALL) }
    val startOfToday = remember {
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
    val filteredLogs = remember(logs, searchQuery, statusFilter, methodFilter, dateFilter) {
        val normalizedQuery = searchQuery.trim().lowercase()
        logs.filter { log ->
            val matchesSearch = normalizedQuery.isEmpty() || listOfNotNull(
                log.sender,
                log.destination,
                log.ruleName,
            ).any { it.lowercase().contains(normalizedQuery) }
            val matchesStatus = when (statusFilter) {
                LogStatusFilter.ALL -> true
                LogStatusFilter.SUCCESS -> log.status in setOf(
                    ForwardStatus.SENT,
                    ForwardStatus.SENT_WAITING_DELIVERY,
                    ForwardStatus.SENT_DELIVERY_UNKNOWN,
                    ForwardStatus.DELIVERED,
                )
                LogStatusFilter.WAITING -> log.status in setOf(
                    ForwardStatus.PENDING,
                    ForwardStatus.ENQUEUED,
                    ForwardStatus.RETRY_PENDING,
                    ForwardStatus.SENDING,
                )
                LogStatusFilter.FAILED -> log.status in setOf(
                    ForwardStatus.FAILED,
                    ForwardStatus.PARTIALLY_FAILED,
                    ForwardStatus.CANCELLED,
                )
            }
            val matchesMethod = when (methodFilter) {
                LogMethodFilter.ALL -> true
                LogMethodFilter.SMS -> log.deliveredVia == DeliveryMethod.SMS
                LogMethodFilter.INTERNET -> log.deliveredVia == DeliveryMethod.INTERNET
            }
            val matchesDate = dateFilter == LogDateFilter.ALL || log.queuedAt >= startOfToday
            matchesSearch && matchesStatus && matchesMethod && matchesDate
        }
    }

    Scaffold(
        modifier = modifier,
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.logs_title), style = MaterialTheme.typography.headlineMedium)
                    Text(
                        stringResource(R.string.logs_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (logs.isNotEmpty()) {
                    Row {
                        IconButton(
                            onClick = {
                                val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                                exportLauncher.launch("smart-sms-logs-$date.json")
                            },
                        ) {
                            Icon(Icons.Outlined.Download, stringResource(R.string.export_logs))
                        }
                        IconButton(onClick = { confirmClear = true }) {
                            Icon(Icons.Outlined.DeleteSweep, stringResource(R.string.clear_logs))
                        }
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.search_logs)) },
                    leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                    singleLine = true,
                )
                ChoiceChips(
                    options = listOf(
                        LogStatusFilter.ALL to stringResource(R.string.filter_all),
                        LogStatusFilter.SUCCESS to stringResource(R.string.filter_success),
                        LogStatusFilter.WAITING to stringResource(R.string.filter_waiting),
                        LogStatusFilter.FAILED to stringResource(R.string.filter_failed),
                    ),
                    selected = statusFilter,
                    onSelected = { statusFilter = it },
                )
                ChoiceChips(
                    options = listOf(
                        LogMethodFilter.ALL to stringResource(R.string.filter_all_routes),
                        LogMethodFilter.SMS to stringResource(R.string.delivery_method_sms),
                        LogMethodFilter.INTERNET to stringResource(R.string.delivery_method_internet),
                    ),
                    selected = methodFilter,
                    onSelected = { methodFilter = it },
                )
                ChoiceChips(
                    options = listOf(
                        LogDateFilter.ALL to stringResource(R.string.filter_all_dates),
                        LogDateFilter.TODAY to stringResource(R.string.filter_today),
                    ),
                    selected = dateFilter,
                    onSelected = { dateFilter = it },
                )
            }
        }
        if (logs.isEmpty()) {
            item { EmptyLogsCard() }
        } else if (filteredLogs.isEmpty()) {
            item { NoMatchingLogsCard() }
        } else {
            items(filteredLogs, key = { it.attemptId }) { log ->
                LogCard(
                    log = log,
                    onRetry = { viewModel.retry(log.attemptId) },
                    onCancel = { viewModel.cancel(log.attemptId) },
                    onDelete = { attemptToDelete = log.attemptId },
                )
            }
        }
    }
    }

    attemptToDelete?.let { attemptId ->
        AlertDialog(
            onDismissRequest = { attemptToDelete = null },
            title = { Text(stringResource(R.string.delete_log_question)) },
            text = { Text(stringResource(R.string.delete_log_desc)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.remove(attemptId)
                        attemptToDelete = null
                    },
                ) { Text(stringResource(R.string.delete_log)) }
            },
            dismissButton = {
                TextButton(onClick = { attemptToDelete = null }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(stringResource(R.string.clear_logs_question)) },
            text = { Text(stringResource(R.string.clear_logs_desc)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clear()
                    confirmClear = false
                }) { Text(stringResource(R.string.clear_logs)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun EmptyLogsCard() {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(Icons.Outlined.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(stringResource(R.string.no_logs_title), style = MaterialTheme.typography.titleMedium)
            Text(
                stringResource(R.string.no_logs_desc),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun NoMatchingLogsCard() {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Text(
            stringResource(R.string.no_matching_logs),
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun LogCard(
    log: ForwardLogRow,
    onRetry: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
) {
    var expanded by rememberSaveable(log.attemptId) { mutableStateOf(false) }
    val dateText = remember(log.queuedAt) {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(log.queuedAt))
    }
    val maskedForwarded = remember(log.forwardedMessage) {
        SensitiveMessageMasker.mask(log.forwardedMessage)
    }
    val maskedOriginal = remember(log.originalMessage) {
        SensitiveMessageMasker.mask(log.originalMessage)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clickable { expanded = !expanded },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        stringResource(R.string.from_to, log.sender, log.destination),
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = if (expanded) Int.MAX_VALUE else 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        dateText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                StatusPill(log.status)
            }
            log.ruleName?.let {
                Text(stringResource(R.string.matched_rule, it), style = MaterialTheme.typography.labelMedium)
            }
            log.deliveredVia?.let { method ->
                Text(
                    stringResource(
                        R.string.log_delivery_method,
                        stringResource(
                            if (method == DeliveryMethod.SMS) {
                                R.string.delivery_method_sms
                            } else {
                                R.string.delivery_method_internet
                            },
                        ),
                    ),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            }
            Text(
                maskedForwarded,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = if (expanded) Int.MAX_VALUE else 2,
                overflow = TextOverflow.Ellipsis,
            )
            if (expanded) {
                Text(stringResource(R.string.original_message), style = MaterialTheme.typography.labelLarge)
                Text(maskedOriginal, style = MaterialTheme.typography.bodyMedium)
                Text(stringResource(R.string.forwarded_message), style = MaterialTheme.typography.labelLarge)
                Text(maskedForwarded, style = MaterialTheme.typography.bodyMedium)
                Text(
                    if (log.status == ForwardStatus.SENT_DELIVERY_UNKNOWN) {
                        stringResource(
                            R.string.delivery_unknown_summary,
                            log.sentPartCount,
                            log.partCount,
                        )
                    } else {
                        stringResource(
                            R.string.delivery_parts,
                            log.sentPartCount,
                            log.partCount,
                            log.deliveredPartCount,
                        )
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    stringResource(R.string.sensitive_content_masked),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                log.remoteReference?.takeIf(String::isNotBlank)?.let { reference ->
                    Text(
                        stringResource(R.string.remote_reference, reference),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                val errorText = readableError(log.errorMessage)
                if (errorText != null) {
                    Text(
                        stringResource(R.string.error_details, errorText),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                val canRetry = log.status in setOf(
                    ForwardStatus.FAILED,
                    ForwardStatus.PARTIALLY_FAILED,
                    ForwardStatus.RETRY_PENDING,
                )
                val canCancel = log.status in setOf(
                    ForwardStatus.PENDING,
                    ForwardStatus.ENQUEUED,
                    ForwardStatus.RETRY_PENDING,
                    ForwardStatus.SENDING,
                    ForwardStatus.SENT_WAITING_DELIVERY,
                )
                Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                    ) {
                        if (canRetry) {
                            TextButton(onClick = onRetry) {
                                Icon(Icons.Outlined.Replay, contentDescription = null)
                                Text(
                                    stringResource(R.string.retry_send),
                                    modifier = Modifier.padding(start = 6.dp),
                                )
                            }
                        }
                        if (canCancel) {
                            TextButton(onClick = onCancel) {
                                Icon(Icons.Outlined.Cancel, contentDescription = null)
                                Text(
                                    stringResource(R.string.cancel_send),
                                    modifier = Modifier.padding(start = 6.dp),
                                )
                            }
                        }
                        TextButton(onClick = onDelete) {
                            Icon(Icons.Outlined.DeleteSweep, contentDescription = null)
                            Text(
                                stringResource(R.string.delete_log),
                                modifier = Modifier.padding(start = 6.dp),
                            )
                        }
                    }
                }
            }
        }
    }

@Composable
private fun readableError(rawError: String?): String? {
    val raw = rawError?.trim().orEmpty()
    if (raw.isEmpty() || raw == "SMS_DELIVERY_RESULT_0") return null
    return when {
        raw == "OTP_NOT_FOUND" -> stringResource(R.string.otp_not_found)
        raw == "SENSITIVE_CONTENT_BLOCKED" -> stringResource(R.string.sensitive_content_blocked)
        raw == "RULE_DAILY_LIMIT_REACHED" -> stringResource(R.string.rule_daily_limit_reached)
        raw == "SMS_ERROR_GENERIC_FAILURE" -> stringResource(R.string.sms_error_generic_failure)
        raw == "SMS_ERROR_RADIO_OFF" -> stringResource(R.string.sms_error_radio_off)
        raw == "SMS_ERROR_NULL_PDU" -> stringResource(R.string.sms_error_null_pdu)
        raw == "SMS_ERROR_NO_SERVICE" -> stringResource(R.string.sms_error_no_service)
        raw == "SMS_ERROR_LIMIT_EXCEEDED" -> stringResource(R.string.sms_error_limit_exceeded)
        raw == "SMS_ERROR_SHORT_CODE_NOT_ALLOWED" -> stringResource(R.string.sms_error_short_code_not_allowed)
        raw == "SMS_ERROR_SHORT_CODE_NEVER_ALLOWED" -> stringResource(R.string.sms_error_short_code_never_allowed)
        raw == "SMS_ERROR_UNKNOWN" -> stringResource(R.string.sms_error_unknown)
        raw == "SMS_DELIVERY_FAILED" -> stringResource(R.string.sms_delivery_failed)
        raw == "SEND_SMS_PERMISSION_MISSING" -> stringResource(R.string.sms_permission_missing)
        raw == "SMS_HOURLY_LIMIT_REACHED" -> stringResource(R.string.sms_hourly_limit_reached)
        raw == "MAX_SEND_ATTEMPTS_REACHED" -> stringResource(R.string.max_send_attempts_reached)
        raw.startsWith("SMS_SEND_EXCEPTION_") -> stringResource(R.string.sms_send_exception)
        raw == "ONLINE_ENDPOINT_MISSING" -> stringResource(R.string.online_endpoint_missing)
        raw == "ONLINE_ENDPOINT_INVALID" || raw == "HTTPS_REQUIRED" ->
            stringResource(R.string.online_endpoint_invalid)
        raw == "ONLINE_TIMEOUT" -> stringResource(R.string.online_timeout)
        raw == "ONLINE_IO_FAILURE" || raw.startsWith("ONLINE_IO_") ->
            stringResource(R.string.online_io_failure)
        raw == "ONLINE_SERVER_REJECTED" -> stringResource(R.string.online_server_rejected)
        raw.startsWith("ONLINE_HTTP_") || raw == "ONLINE_REQUEST_FAILED" ->
            stringResource(R.string.online_request_failed)
        else -> stringResource(R.string.sms_error_unknown)
    }
}

@Composable
private fun StatusPill(status: ForwardStatus) {
    val (label, color) = when (status) {
        ForwardStatus.PENDING -> stringResource(R.string.status_pending) to MaterialTheme.colorScheme.secondary
        ForwardStatus.ENQUEUED -> stringResource(R.string.status_enqueued) to MaterialTheme.colorScheme.secondary
        ForwardStatus.RETRY_PENDING -> stringResource(R.string.status_retry_pending) to MaterialTheme.colorScheme.tertiary
        ForwardStatus.SENDING -> stringResource(R.string.status_sending) to MaterialTheme.colorScheme.tertiary
        ForwardStatus.SENT -> stringResource(R.string.status_sent) to MaterialTheme.colorScheme.primary
        ForwardStatus.SENT_WAITING_DELIVERY ->
            stringResource(R.string.status_sent_waiting_delivery) to MaterialTheme.colorScheme.tertiary
        ForwardStatus.SENT_DELIVERY_UNKNOWN ->
            stringResource(R.string.status_sent_delivery_unknown) to MaterialTheme.colorScheme.outline
        ForwardStatus.DELIVERED -> stringResource(R.string.status_delivered) to MaterialTheme.colorScheme.primary
        ForwardStatus.PARTIALLY_FAILED ->
            stringResource(R.string.status_partially_failed) to MaterialTheme.colorScheme.error
        ForwardStatus.FAILED -> stringResource(R.string.status_failed) to MaterialTheme.colorScheme.error
        ForwardStatus.CANCELLED -> stringResource(R.string.status_cancelled) to MaterialTheme.colorScheme.outline
    }
    Surface(color = color.copy(alpha = 0.14f), shape = MaterialTheme.shapes.extraLarge) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = color,
        )
    }
}
