package ir.smsforwardmanager.core.util

/** Conservative detector used to keep login, OTP and banking messages blocked by default. */
object SensitiveMessageDetector {
    private val codePattern = Regex("(?<!\\d)\\d{4,8}(?!\\d)")
    private val sensitiveTerms = listOf(
        "otp",
        "one-time",
        "verification code",
        "login code",
        "security code",
        "password",
        "bank",
        "mygov",
        "کد ورود",
        "کد تایید",
        "کد تأیید",
        "رمز یکبار",
        "رمز یک‌بار",
        "رمز پویا",
        "رمز عبور",
        "بانک",
        "محرمانه",
        "پنجره ملی",
    )

    fun isSensitive(message: String): Boolean {
        if (!codePattern.containsMatchIn(message)) return false
        val normalized = PhoneNormalizer.toLatinDigits(message).lowercase()
        return sensitiveTerms.any(normalized::contains)
    }
}
