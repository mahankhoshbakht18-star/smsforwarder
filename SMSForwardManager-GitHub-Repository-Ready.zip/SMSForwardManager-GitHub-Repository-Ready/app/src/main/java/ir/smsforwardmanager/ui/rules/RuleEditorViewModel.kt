package ir.smsforwardmanager.ui.rules

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.smsforwardmanager.core.model.ForwardMode
import ir.smsforwardmanager.core.model.KeywordLogic
import ir.smsforwardmanager.core.model.MatchMode
import ir.smsforwardmanager.core.model.RuleDeliveryMode
import ir.smsforwardmanager.core.util.OtpExtractor
import ir.smsforwardmanager.core.util.PhoneNormalizer
import ir.smsforwardmanager.core.util.SimInfoProvider
import ir.smsforwardmanager.core.util.SimOption
import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import ir.smsforwardmanager.data.repository.RuleRepository
import ir.smsforwardmanager.data.repository.SettingsRepository
import ir.smsforwardmanager.domain.model.DestinationInput
import ir.smsforwardmanager.domain.model.RuleDraft
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class EditorValidationError {
    NAME,
    FILTER,
    DESTINATION,
    REGEX,
    SCHEDULE,
}

data class DestinationForm(
    val key: Long,
    val label: String = "",
    val phoneNumber: String = "",
)

data class RuleEditorUiState(
    val isLoading: Boolean = true,
    val isSaving: Boolean = false,
    val saved: Boolean = false,
    val ruleId: Long = 0,
    val name: String = "",
    val isEnabled: Boolean = true,
    val priority: String = "0",
    val senderPattern: String = "",
    val senderMatchMode: MatchMode = MatchMode.EXACT,
    val keywordMatchMode: MatchMode = MatchMode.CONTAINS,
    val keywordLogic: KeywordLogic = KeywordLogic.ANY,
    val keywordsText: String = "",
    val forwardMode: ForwardMode = ForwardMode.FULL_MESSAGE,
    val otpRegex: String = "",
    val isCaseSensitive: Boolean = false,
    val subscriptionId: Int? = null,
    val stopAfterMatch: Boolean = false,
    val allowSensitiveContent: Boolean = false,
    val excludedKeywordsText: String = "",
    val deliveryModeOverride: RuleDeliveryMode = RuleDeliveryMode.USE_GLOBAL,
    val activeDaysMask: Int = 127,
    val activeStartTime: String = "",
    val activeEndTime: String = "",
    val maxForwardsPerDay: String = "0",
    val prependText: String = "",
    val appendText: String = "",
    val destinations: List<DestinationForm> = listOf(DestinationForm(key = 1L)),
    val simOptions: List<SimOption> = emptyList(),
    val validationError: EditorValidationError? = null,
    val saveError: String? = null,
)

@HiltViewModel
class RuleEditorViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val ruleRepository: RuleRepository,
    private val settingsRepository: SettingsRepository,
    private val simInfoProvider: SimInfoProvider,
) : ViewModel() {
    private val ruleId: Long = savedStateHandle.get<Long>("ruleId") ?: 0L
    private val _uiState = MutableStateFlow(RuleEditorUiState(ruleId = ruleId))
    val uiState: StateFlow<RuleEditorUiState> = _uiState.asStateFlow()
    private var nextDestinationKey = 10L

    init {
        viewModelScope.launch {
            val settings = settingsRepository.get()
            val details = ruleId.takeIf { it > 0 }?.let { ruleRepository.getRule(it) }
            _uiState.update { current ->
                if (details == null) {
                    current.copy(
                        isLoading = false,
                        otpRegex = settings.defaultOtpRegex,
                        simOptions = simInfoProvider.getActiveSims(),
                    )
                } else {
                    val rule = details.rule
                    val destinations = details.destinationLinks
                        .sortedBy { it.link.sortOrder }
                        .map { link ->
                            DestinationForm(
                                key = nextDestinationKey++,
                                label = link.destination.label,
                                phoneNumber = link.destination.phoneNumber,
                            )
                        }
                    current.copy(
                        isLoading = false,
                        name = rule.name,
                        isEnabled = rule.isEnabled,
                        priority = rule.priority.toString(),
                        senderPattern = rule.senderPattern.orEmpty(),
                        senderMatchMode = rule.senderMatchMode,
                        keywordMatchMode = rule.keywordMatchMode,
                        keywordLogic = rule.keywordLogic,
                        keywordsText = details.keywords.sortedBy { it.sortOrder }
                            .joinToString("\n") { it.value },
                        forwardMode = rule.forwardMode,
                        otpRegex = rule.otpRegex ?: settings.defaultOtpRegex,
                        isCaseSensitive = rule.isCaseSensitive,
                        subscriptionId = rule.subscriptionId,
                        stopAfterMatch = rule.stopAfterMatch,
                        allowSensitiveContent = rule.allowSensitiveContent,
                        excludedKeywordsText = rule.excludedKeywords.joinToString("\n"),
                        deliveryModeOverride = rule.deliveryModeOverride,
                        activeDaysMask = rule.activeDaysMask,
                        activeStartTime = formatMinutes(rule.activeStartMinute),
                        activeEndTime = formatMinutes(rule.activeEndMinute),
                        maxForwardsPerDay = rule.maxForwardsPerDay.toString(),
                        prependText = rule.prependText,
                        appendText = rule.appendText,
                        destinations = destinations.ifEmpty {
                            listOf(DestinationForm(key = nextDestinationKey++))
                        },
                        simOptions = simInfoProvider.getActiveSims(),
                    )
                }
            }
        }
    }

    fun update(transform: (RuleEditorUiState) -> RuleEditorUiState) {
        _uiState.update { transform(it).copy(validationError = null, saveError = null) }
    }

    fun addDestination() {
        update { it.copy(destinations = it.destinations + DestinationForm(nextDestinationKey++)) }
    }

    fun updateDestination(key: Long, label: String? = null, phoneNumber: String? = null) {
        update { state ->
            state.copy(
                destinations = state.destinations.map { destination ->
                    if (destination.key == key) destination.copy(
                        label = label ?: destination.label,
                        phoneNumber = phoneNumber ?: destination.phoneNumber,
                    ) else destination
                },
            )
        }
    }

    fun removeDestination(key: Long) {
        update { state ->
            val remaining = state.destinations.filterNot { it.key == key }
            state.copy(
                destinations = remaining.ifEmpty { listOf(DestinationForm(nextDestinationKey++)) },
            )
        }
    }

    fun toggleActiveDay(bitIndex: Int) {
        if (bitIndex !in 0..6) return
        update { state ->
            val bit = 1 shl bitIndex
            state.copy(activeDaysMask = state.activeDaysMask xor bit)
        }
    }

    fun refreshSims() {
        _uiState.update { it.copy(simOptions = simInfoProvider.getActiveSims()) }
    }

    fun save() {
        val state = _uiState.value
        val keywords = state.keywordsText.lineSequence()
            .flatMap { line -> line.split(',').asSequence() }
            .map(String::trim)
            .filter(String::isNotBlank)
            .distinct()
            .toList()
        val excludedKeywords = state.excludedKeywordsText.lineSequence()
            .flatMap { line -> line.split(',').asSequence() }
            .map(String::trim)
            .filter(String::isNotBlank)
            .distinct()
            .toList()
        val destinations = state.destinations
            .filter { it.label.isNotBlank() || it.phoneNumber.isNotBlank() }
        val startMinute = parseTime(state.activeStartTime)
        val endMinute = parseTime(state.activeEndTime)
        val hasAnyTime = state.activeStartTime.isNotBlank() || state.activeEndTime.isNotBlank()
        val maxForwards = state.maxForwardsPerDay.toIntOrNull()

        val validation = when {
            state.name.isBlank() -> EditorValidationError.NAME
            state.senderPattern.isBlank() && keywords.isEmpty() -> EditorValidationError.FILTER
            destinations.isEmpty() || destinations.any {
                !PhoneNormalizer.isPlausibleDestination(it.phoneNumber)
            } -> EditorValidationError.DESTINATION
            state.forwardMode == ForwardMode.EXTRACT_OTP &&
                !OtpExtractor.isValidPattern(state.otpRegex) -> EditorValidationError.REGEX
            state.activeDaysMask == 0 ||
                (hasAnyTime && (startMinute == null || endMinute == null)) ||
                maxForwards == null || maxForwards !in 0..10_000 -> EditorValidationError.SCHEDULE
            else -> null
        }
        if (validation != null) {
            _uiState.update { it.copy(validationError = validation) }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, saveError = null) }
            runCatching {
                ruleRepository.save(
                    RuleDraft(
                        id = state.ruleId,
                        name = state.name,
                        isEnabled = state.isEnabled,
                        priority = state.priority.toIntOrNull() ?: 0,
                        senderPattern = state.senderPattern,
                        senderMatchMode = state.senderMatchMode,
                        keywordMatchMode = state.keywordMatchMode,
                        keywordLogic = state.keywordLogic,
                        keywords = keywords,
                        forwardMode = state.forwardMode,
                        otpRegex = state.otpRegex,
                        isCaseSensitive = state.isCaseSensitive,
                        subscriptionId = state.subscriptionId,
                        stopAfterMatch = state.stopAfterMatch,
                        allowSensitiveContent = state.allowSensitiveContent,
                        excludedKeywords = excludedKeywords,
                        deliveryModeOverride = state.deliveryModeOverride,
                        activeDaysMask = state.activeDaysMask,
                        activeStartMinute = if (hasAnyTime) startMinute else null,
                        activeEndMinute = if (hasAnyTime) endMinute else null,
                        maxForwardsPerDay = maxForwards ?: 0,
                        prependText = state.prependText,
                        appendText = state.appendText,
                        destinations = destinations.map {
                            DestinationInput(label = it.label, phoneNumber = it.phoneNumber)
                        },
                    ),
                )
            }.onSuccess {
                _uiState.update { it.copy(isSaving = false, saved = true) }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(isSaving = false, saveError = error.message ?: error.javaClass.simpleName)
                }
            }
        }
    }

    private fun parseTime(value: String): Int? {
        val match = TIME_PATTERN.matchEntire(PhoneNormalizer.toLatinDigits(value.trim())) ?: return null
        val hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues[2].toIntOrNull() ?: return null
        if (hour !in 0..23 || minute !in 0..59) return null
        return hour * 60 + minute
    }

    private fun formatMinutes(value: Int?): String = value?.let { minutes ->
        "%02d:%02d".format(minutes / 60, minutes % 60)
    }.orEmpty()

    private companion object {
        val TIME_PATTERN = Regex("^(\\d{1,2}):(\\d{2})$")
    }

}
