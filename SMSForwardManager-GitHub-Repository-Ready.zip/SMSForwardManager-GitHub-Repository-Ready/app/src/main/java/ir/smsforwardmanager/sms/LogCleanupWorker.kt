package ir.smsforwardmanager.sms

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import ir.smsforwardmanager.data.repository.LogRepository
import ir.smsforwardmanager.data.repository.SettingsRepository

@HiltWorker
class LogCleanupWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val settingsRepository: SettingsRepository,
    private val logRepository: LogRepository,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = runCatching {
        val settings = settingsRepository.get()
        logRepository.removeExpired(settings.logRetentionDays)
        Result.success()
    }.getOrElse { Result.retry() }
}
