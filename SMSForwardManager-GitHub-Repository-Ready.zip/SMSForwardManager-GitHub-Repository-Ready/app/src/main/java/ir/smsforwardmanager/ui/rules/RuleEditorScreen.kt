package ir.smsforwardmanager.ui.rules

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.FilterAlt
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.PhoneForwarded
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.smsforwardmanager.R
import ir.smsforwardmanager.core.model.ForwardMode
import ir.smsforwardmanager.core.model.KeywordLogic
import ir.smsforwardmanager.core.model.MatchMode
import ir.smsforwardmanager.ui.components.ChoiceChips
import ir.smsforwardmanager.ui.components.ExpandableSectionCard
import ir.smsforwardmanager.ui.components.LabeledSwitch
import ir.smsforwardmanager.ui.components.SectionCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RuleEditorScreen(
    onBack: () -> Unit,
    viewModel: RuleEditorViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var confirmSensitiveForwarding by remember { mutableStateOf(false) }
    val validationMessage = when (state.validationError) {
        EditorValidationError.NAME -> stringResource(R.string.validation_name)
        EditorValidationError.FILTER -> stringResource(R.string.validation_filter)
        EditorValidationError.DESTINATION -> stringResource(R.string.validation_destination)
        EditorValidationError.REGEX -> stringResource(R.string.validation_regex)
        EditorValidationError.SCHEDULE -> stringResource(R.string.validation_schedule)
        null -> null
    }
    val errorMessage = state.saveError?.let { stringResource(R.string.save_failed, it) }
    LaunchedEffect(validationMessage, errorMessage) {
        (validationMessage ?: errorMessage)?.let { snackbarHostState.showSnackbar(it) }
    }
    LaunchedEffect(state.saved) { if (state.saved) onBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(stringResource(if (state.ruleId > 0) R.string.edit_rule else R.string.add_rule))
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, stringResource(R.string.back))
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { innerPadding ->
        if (state.isLoading) {
            Column(
                modifier = Modifier.fillMaxSize().padding(innerPadding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) { CircularProgressIndicator() }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(innerPadding),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                item {
                    SectionCard(
                        title = stringResource(R.string.basic_section),
                        description = stringResource(R.string.basic_section_desc),
                        icon = Icons.Outlined.Badge,
                    ) {
                        OutlinedTextField(
                            value = state.name,
                            onValueChange = { value -> viewModel.update { it.copy(name = value) } },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(stringResource(R.string.rule_name)) },
                            placeholder = { Text(stringResource(R.string.rule_name_hint)) },
                            singleLine = true,
                            shape = MaterialTheme.shapes.medium,
                        )
                        LabeledSwitch(
                            title = stringResource(R.string.rule_enabled),
                            checked = state.isEnabled,
                            onCheckedChange = { enabled -> viewModel.update { it.copy(isEnabled = enabled) } },
                        )
                    }
                }

                item {
                    SectionCard(
                        title = stringResource(R.string.filters_section),
                        description = stringResource(R.string.filters_section_desc_compact),
                        icon = Icons.Outlined.FilterAlt,
                    ) {
                        OutlinedTextField(
                            value = state.senderPattern,
                            onValueChange = { value -> viewModel.update { it.copy(senderPattern = value) } },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(stringResource(R.string.sender_pattern)) },
                            placeholder = { Text(stringResource(R.string.sender_pattern_hint)) },
                            singleLine = true,
                            shape = MaterialTheme.shapes.medium,
                        )
                        OutlinedTextField(
                            value = state.keywordsText,
                            onValueChange = { value -> viewModel.update { it.copy(keywordsText = value) } },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(stringResource(R.string.keywords)) },
                            placeholder = { Text(stringResource(R.string.keywords_hint_compact)) },
                            minLines = 2,
                            maxLines = 4,
                            shape = MaterialTheme.shapes.medium,
                        )
                        Text(
                            stringResource(R.string.filters_quick_note),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                item {
                    SectionCard(
                        title = stringResource(R.string.forward_section),
                        description = stringResource(R.string.forward_section_desc_compact),
                        icon = Icons.Outlined.Send,
                    ) {
                        ChoiceChips(
                            options = listOf(
                                ForwardMode.FULL_MESSAGE to stringResource(R.string.full_message),
                                ForwardMode.EXTRACT_OTP to stringResource(R.string.otp_only),
                            ),
                            selected = state.forwardMode,
                            onSelected = { mode -> viewModel.update { it.copy(forwardMode = mode) } },
                        )
                        LabeledSwitch(
                            title = stringResource(R.string.allow_sensitive_content_compact),
                            description = stringResource(R.string.allow_sensitive_content_desc_compact),
                            checked = state.allowSensitiveContent,
                            onCheckedChange = { enabled ->
                                if (enabled) {
                                    confirmSensitiveForwarding = true
                                } else {
                                    viewModel.update { it.copy(allowSensitiveContent = false) }
                                }
                            },
                        )
                    }
                }

                item {
                    SectionCard(
                        title = stringResource(R.string.destinations_section),
                        description = stringResource(R.string.destinations_section_desc_compact),
                        icon = Icons.Outlined.PhoneForwarded,
                    ) {
                        state.destinations.forEachIndexed { index, destination ->
                            DestinationEditor(
                                index = index,
                                destination = destination,
                                canRemove = state.destinations.size > 1,
                                onLabelChange = { viewModel.updateDestination(destination.key, label = it) },
                                onPhoneChange = { viewModel.updateDestination(destination.key, phoneNumber = it) },
                                onRemove = { viewModel.removeDestination(destination.key) },
                            )
                        }
                        OutlinedButton(
                            onClick = viewModel::addDestination,
                            modifier = Modifier.fillMaxWidth(),
                            shape = MaterialTheme.shapes.medium,
                        ) {
                            Icon(Icons.Outlined.Add, contentDescription = null)
                            Text(stringResource(R.string.add_destination), modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                }

                item {
                    ExpandableSectionCard(
                        title = stringResource(R.string.advanced_section_compact),
                        description = stringResource(R.string.advanced_section_desc_compact),
                        icon = Icons.Outlined.MoreHoriz,
                    ) {
                        Text(stringResource(R.string.matching_details_title), style = MaterialTheme.typography.labelLarge)
                        Text(stringResource(R.string.sender_match_method), style = MaterialTheme.typography.labelMedium)
                        ChoiceChips(
                            options = matchOptions(),
                            selected = state.senderMatchMode,
                            onSelected = { mode -> viewModel.update { it.copy(senderMatchMode = mode) } },
                        )
                        OutlinedTextField(
                            value = state.excludedKeywordsText,
                            onValueChange = { value -> viewModel.update { it.copy(excludedKeywordsText = value) } },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(stringResource(R.string.excluded_keywords)) },
                            placeholder = { Text(stringResource(R.string.excluded_keywords_hint)) },
                            minLines = 2,
                            maxLines = 4,
                            shape = MaterialTheme.shapes.medium,
                        )
                        Text(stringResource(R.string.keyword_match_method), style = MaterialTheme.typography.labelMedium)
                        ChoiceChips(
                            options = matchOptions(),
                            selected = state.keywordMatchMode,
                            onSelected = { mode -> viewModel.update { it.copy(keywordMatchMode = mode) } },
                        )
                        ChoiceChips(
                            options = listOf(
                                KeywordLogic.ANY to stringResource(R.string.logic_any_compact),
                                KeywordLogic.ALL to stringResource(R.string.logic_all_compact),
                            ),
                            selected = state.keywordLogic,
                            onSelected = { logic -> viewModel.update { it.copy(keywordLogic = logic) } },
                        )
                        LabeledSwitch(
                            title = stringResource(R.string.case_sensitive),
                            checked = state.isCaseSensitive,
                            onCheckedChange = { enabled -> viewModel.update { it.copy(isCaseSensitive = enabled) } },
                        )

                        if (state.forwardMode == ForwardMode.EXTRACT_OTP) {
                            OutlinedTextField(
                                value = state.otpRegex,
                                onValueChange = { value -> viewModel.update { it.copy(otpRegex = value) } },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text(stringResource(R.string.otp_regex)) },
                                supportingText = { Text(stringResource(R.string.otp_regex_desc_compact)) },
                                singleLine = true,
                                shape = MaterialTheme.shapes.medium,
                            )
                        }
                        OutlinedTextField(
                            value = state.prependText,
                            onValueChange = { value -> viewModel.update { it.copy(prependText = value) } },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(stringResource(R.string.prepend_text_compact)) },
                            minLines = 1,
                            maxLines = 3,
                            shape = MaterialTheme.shapes.medium,
                        )
                        OutlinedTextField(
                            value = state.appendText,
                            onValueChange = { value -> viewModel.update { it.copy(appendText = value) } },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(stringResource(R.string.append_text_compact)) },
                            minLines = 1,
                            maxLines = 3,
                            shape = MaterialTheme.shapes.medium,
                        )

                        Text(stringResource(R.string.schedule_and_priority), style = MaterialTheme.typography.labelLarge)
                        OutlinedTextField(
                            value = state.priority,
                            onValueChange = { value ->
                                if (value.isEmpty() || value.toIntOrNull() != null) {
                                    viewModel.update { it.copy(priority = value) }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(stringResource(R.string.priority)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = MaterialTheme.shapes.medium,
                        )
                        LabeledSwitch(
                            title = stringResource(R.string.stop_after_match_compact),
                            checked = state.stopAfterMatch,
                            onCheckedChange = { enabled -> viewModel.update { it.copy(stopAfterMatch = enabled) } },
                        )
                        Text(stringResource(R.string.active_days), style = MaterialTheme.typography.labelMedium)
                        ActiveDaysSelector(mask = state.activeDaysMask, onToggle = viewModel::toggleActiveDay)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            OutlinedTextField(
                                value = state.activeStartTime,
                                onValueChange = { value -> viewModel.update { it.copy(activeStartTime = value) } },
                                modifier = Modifier.weight(1f),
                                label = { Text(stringResource(R.string.active_start_time)) },
                                placeholder = { Text(stringResource(R.string.active_start_time_hint)) },
                                singleLine = true,
                                shape = MaterialTheme.shapes.medium,
                            )
                            OutlinedTextField(
                                value = state.activeEndTime,
                                onValueChange = { value -> viewModel.update { it.copy(activeEndTime = value) } },
                                modifier = Modifier.weight(1f),
                                label = { Text(stringResource(R.string.active_end_time)) },
                                placeholder = { Text(stringResource(R.string.active_end_time_hint)) },
                                singleLine = true,
                                shape = MaterialTheme.shapes.medium,
                            )
                        }
                        OutlinedTextField(
                            value = state.maxForwardsPerDay,
                            onValueChange = { value ->
                                if (value.isEmpty() || value.all(Char::isDigit)) {
                                    viewModel.update { it.copy(maxForwardsPerDay = value) }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(stringResource(R.string.max_forwards_per_day)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = MaterialTheme.shapes.medium,
                        )
                        Text(stringResource(R.string.sending_sim), style = MaterialTheme.typography.labelMedium)
                        ChoiceChips(
                            options = buildList<Pair<Int?, String>> {
                                add(null to stringResource(R.string.sim_automatic))
                                state.simOptions.forEach { sim ->
                                    val name = sim.displayName.ifBlank { sim.carrierName.ifBlank { "SIM" } }
                                    add(sim.subscriptionId to stringResource(R.string.sim_slot, sim.slotIndex + 1, name))
                                }
                            },
                            selected = state.subscriptionId,
                            onSelected = { subscriptionId ->
                                viewModel.update { it.copy(subscriptionId = subscriptionId) }
                            },
                        )
                    }
                }

                item {
                    Button(
                        onClick = viewModel::save,
                        enabled = !state.isSaving,
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 15.dp),
                        shape = MaterialTheme.shapes.large,
                    ) {
                        if (state.isSaving) CircularProgressIndicator(modifier = Modifier.padding(end = 10.dp))
                        else Icon(Icons.Outlined.Save, contentDescription = null)
                        Text(
                            stringResource(if (state.isSaving) R.string.saving else R.string.save_condition),
                            modifier = Modifier.padding(start = 8.dp),
                        )
                    }
                }
            }
        }
    }

    if (confirmSensitiveForwarding) {
        AlertDialog(
            onDismissRequest = { confirmSensitiveForwarding = false },
            title = { Text(stringResource(R.string.sensitive_forwarding_warning_title)) },
            text = { Text(stringResource(R.string.sensitive_forwarding_warning_text)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmSensitiveForwarding = false
                        viewModel.update { it.copy(allowSensitiveContent = true) }
                    },
                ) { Text(stringResource(R.string.sensitive_forwarding_enable)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmSensitiveForwarding = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
    }
}

@Composable
private fun ActiveDaysSelector(mask: Int, onToggle: (Int) -> Unit) {
    val days = listOf(
        7 to R.string.day_saturday,
        1 to R.string.day_sunday,
        2 to R.string.day_monday,
        3 to R.string.day_tuesday,
        4 to R.string.day_wednesday,
        5 to R.string.day_thursday,
        6 to R.string.day_friday,
    )
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        days.forEach { (calendarDay, labelRes) ->
            val bitIndex = calendarDay - 1
            val selected = mask and (1 shl bitIndex) != 0
            FilterChip(
                selected = selected,
                onClick = { onToggle(bitIndex) },
                label = { Text(stringResource(labelRes)) },
            )
        }
    }
}

@Composable
private fun matchOptions(): List<Pair<MatchMode, String>> = listOf(
    MatchMode.CONTAINS to stringResource(R.string.match_contains),
    MatchMode.STARTS_WITH to stringResource(R.string.match_starts_with),
    MatchMode.EXACT to stringResource(R.string.match_exact),
)

@Composable
private fun DestinationEditor(
    index: Int,
    destination: DestinationForm,
    canRemove: Boolean,
    onLabelChange: (String) -> Unit,
    onPhoneChange: (String) -> Unit,
    onRemove: () -> Unit,
) {
    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    pluralStringResource(R.plurals.destination_count, index + 1, index + 1),
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.weight(1f),
                )
                if (canRemove) {
                    IconButton(onClick = onRemove) {
                        Icon(Icons.Outlined.Delete, stringResource(R.string.remove_destination))
                    }
                }
            }
            OutlinedTextField(
                value = destination.label,
                onValueChange = onLabelChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.destination_label)) },
                placeholder = { Text(stringResource(R.string.destination_label_hint)) },
                singleLine = true,
                shape = MaterialTheme.shapes.medium,
            )
            OutlinedTextField(
                value = destination.phoneNumber,
                onValueChange = onPhoneChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text(stringResource(R.string.phone_number)) },
                placeholder = { Text(stringResource(R.string.phone_number_hint)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                shape = MaterialTheme.shapes.medium,
            )
        }
    }
}
