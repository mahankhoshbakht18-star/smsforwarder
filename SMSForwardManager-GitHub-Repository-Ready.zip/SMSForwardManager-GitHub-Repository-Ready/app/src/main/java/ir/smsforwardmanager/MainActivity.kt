package ir.smsforwardmanager

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FilterAlt
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import dagger.hilt.android.AndroidEntryPoint
import ir.smsforwardmanager.core.model.AppLanguage
import ir.smsforwardmanager.remote.customer.RemoteJoinInput
import ir.smsforwardmanager.remote.customer.ScreenShareService
import ir.smsforwardmanager.sms.ForwardingStatusService
import ir.smsforwardmanager.ui.MainViewModel
import ir.smsforwardmanager.ui.about.AboutScreen
import ir.smsforwardmanager.ui.dashboard.DashboardScreen
import ir.smsforwardmanager.ui.logs.LogsScreen
import ir.smsforwardmanager.ui.remote.RemoteAssistScreen
import ir.smsforwardmanager.ui.rules.RuleEditorScreen
import ir.smsforwardmanager.ui.rules.RulesScreen
import ir.smsforwardmanager.ui.settings.SettingsScreen
import ir.smsforwardmanager.ui.theme.SmsForwardManagerTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    private var isUnlocked by mutableStateOf(false)
    private var lockEnabledForSession = false
    private var promptShowing = false

    private val mutableRemoteJoinInput = MutableStateFlow(RemoteJoinInput())
    private val remoteJoinInput = mutableRemoteJoinInput.asStateFlow()
    private val mutableRemoteActivityMessage = MutableStateFlow<String?>(null)
    private val remoteActivityMessage = mutableRemoteActivityMessage.asStateFlow()
    private var pendingRemoteShare: RemoteJoinInput? = null

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            launchProjectionPrompt()
        } else {
            mutableRemoteActivityMessage.value = getString(
                R.string.customer_remote_notification_required,
            )
        }
    }

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        val pending = pendingRemoteShare
        if (result.resultCode != Activity.RESULT_OK || result.data == null || pending == null) {
            mutableRemoteActivityMessage.value = getString(
                R.string.customer_remote_projection_cancelled,
            )
            pendingRemoteShare = null
            return@registerForActivityResult
        }

        val serviceIntent = Intent(this, ScreenShareService::class.java)
            .setAction(ScreenShareService.ACTION_START)
            .putExtra(ScreenShareService.EXTRA_RESULT_CODE, result.resultCode)
            .putExtra(ScreenShareService.EXTRA_RESULT_DATA, result.data)
            .putExtra(ScreenShareService.EXTRA_SERVER_URL, pending.server)
            .putExtra(ScreenShareService.EXTRA_CLIENT_TOKEN, pending.token)
        ContextCompat.startForegroundService(this, serviceIntent)
        mutableRemoteActivityMessage.value = null
        pendingRemoteShare = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        consumeRemoteJoinIntent(intent)

        setContent {
            val viewModel: MainViewModel = hiltViewModel()
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            val initialized by viewModel.isInitialized.collectAsStateWithLifecycle()
            val currentRemoteJoin by remoteJoinInput.collectAsStateWithLifecycle()
            val currentRemoteMessage by remoteActivityMessage.collectAsStateWithLifecycle()

            LaunchedEffect(initialized, settings.masterForwardingEnabled) {
                if (!initialized) return@LaunchedEffect
                val serviceIntent = Intent(this@MainActivity, ForwardingStatusService::class.java)
                    .setAction(ForwardingStatusService.ACTION_START)
                if (settings.masterForwardingEnabled) {
                    ContextCompat.startForegroundService(this@MainActivity, serviceIntent)
                } else {
                    stopService(serviceIntent)
                }
            }

            LaunchedEffect(initialized, settings.appLockEnabled) {
                if (!initialized) return@LaunchedEffect
                lockEnabledForSession = settings.appLockEnabled
                if (settings.appLockEnabled) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    isUnlocked = false
                    authenticateForAppLock()
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    isUnlocked = true
                    promptShowing = false
                }
            }

            SmsForwardManagerTheme(
                themeMode = settings.themeMode,
                dynamicColor = false,
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    when {
                        !initialized -> LoadingScreen()
                        !settings.appLockEnabled || isUnlocked -> {
                            SmsForwardApp(
                                remoteJoinInput = currentRemoteJoin,
                                remoteActivityMessage = currentRemoteMessage,
                                onStartRemoteShare = ::requestRemoteScreenShare,
                                onRemoteServiceAction = ::sendRemoteServiceAction,
                                onLanguageChange = ::applyLanguage,
                            )
                        }
                        else -> LockedScreen(onUnlock = ::authenticateForAppLock)
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        consumeRemoteJoinIntent(intent)
    }

    override fun onStop() {
        super.onStop()
        if (lockEnabledForSession && !isChangingConfigurations && !promptShowing) {
            isUnlocked = false
        }
    }

    private fun requestRemoteScreenShare(joinInput: RemoteJoinInput) {
        if (!joinInput.isComplete) return
        pendingRemoteShare = joinInput
        mutableRemoteActivityMessage.value = null
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchProjectionPrompt()
        }
    }

    private fun launchProjectionPrompt() {
        if (pendingRemoteShare == null) return
        val manager = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun sendRemoteServiceAction(action: String) {
        startService(Intent(this, ScreenShareService::class.java).setAction(action))
    }

    private fun consumeRemoteJoinIntent(sourceIntent: Intent?) {
        val parsed = parseRemoteJoinInput(sourceIntent?.data) ?: return
        mutableRemoteJoinInput.value = parsed
        mutableRemoteActivityMessage.value = null
        sourceIntent?.setData(null)
    }

    private fun parseRemoteJoinInput(data: Uri?): RemoteJoinInput? {
        data ?: return null
        if (data.scheme != REMOTE_JOIN_SCHEME || data.host != REMOTE_JOIN_HOST) return null
        val server = data.getQueryParameter("server").orEmpty().trim().trimEnd('/')
        val token = data.getQueryParameter("token").orEmpty().trim()
        return RemoteJoinInput(server = server, token = token).takeIf { it.isComplete }
    }

    private fun authenticateForAppLock() {
        if (promptShowing || isUnlocked) return

        val authenticators = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else {
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        }
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            isUnlocked = true
            return
        }

        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    promptShowing = false
                    isUnlocked = true
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    promptShowing = false
                }
            },
        )

        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_prompt_title))
            .setSubtitle(getString(R.string.biometric_prompt_subtitle))
            .setAllowedAuthenticators(authenticators)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            builder.setNegativeButtonText(getString(android.R.string.cancel))
        }

        promptShowing = true
        prompt.authenticate(builder.build())
    }

    private fun applyLanguage(language: AppLanguage) {
        val locales = when (language) {
            AppLanguage.SYSTEM -> LocaleListCompat.getEmptyLocaleList()
            AppLanguage.PERSIAN -> LocaleListCompat.forLanguageTags("fa")
            AppLanguage.ENGLISH -> LocaleListCompat.forLanguageTags("en")
        }
        if (AppCompatDelegate.getApplicationLocales().toLanguageTags() != locales.toLanguageTags()) {
            AppCompatDelegate.setApplicationLocales(locales)
        }
    }

    companion object {
        private const val REMOTE_JOIN_SCHEME = "smsforwardremote"
        private const val REMOTE_JOIN_HOST = "join"
    }
}

@Composable
private fun LoadingScreen() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
private fun LockedScreen(onUnlock: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Icon(Icons.Outlined.Lock, contentDescription = null)
            Text(
                text = stringResource(R.string.app_locked_title),
                textAlign = TextAlign.Center,
            )
            Text(
                text = stringResource(R.string.app_locked_desc),
                textAlign = TextAlign.Center,
            )
            Button(onClick = onUnlock) {
                Text(stringResource(R.string.unlock_app))
            }
        }
    }
}

private object Routes {
    const val DASHBOARD = "dashboard"
    const val RULES = "rules"
    const val LOGS = "logs"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
    const val REMOTE_ASSIST = "remote_assist"
    const val RULE_EDITOR = "rule_editor/{ruleId}"

    fun editor(ruleId: Long) = "rule_editor/$ruleId"
}

private data class NavigationItem(
    val route: String,
    val label: Int,
    val icon: ImageVector,
)

@Composable
private fun SmsForwardApp(
    remoteJoinInput: RemoteJoinInput,
    remoteActivityMessage: String?,
    onStartRemoteShare: (RemoteJoinInput) -> Unit,
    onRemoteServiceAction: (String) -> Unit,
    onLanguageChange: (AppLanguage) -> Unit,
) {
    val navController = rememberNavController()
    val items = listOf(
        NavigationItem(Routes.DASHBOARD, R.string.nav_home, Icons.Outlined.Home),
        NavigationItem(Routes.RULES, R.string.nav_rules, Icons.Outlined.FilterAlt),
        NavigationItem(Routes.LOGS, R.string.nav_logs, Icons.Outlined.History),
        NavigationItem(
            Routes.REMOTE_ASSIST,
            R.string.remote_dashboard_action,
            Icons.Outlined.SupportAgent,
        ),
        NavigationItem(Routes.SETTINGS, R.string.nav_settings, Icons.Outlined.Settings),
    )
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute in items.map { it.route }

    LaunchedEffect(remoteJoinInput) {
        if (remoteJoinInput.isComplete) {
            navController.navigate(Routes.REMOTE_ASSIST) {
                launchSingleTop = true
            }
        }
    }

    Scaffold(
        bottomBar = {
            if (showBottomBar) AppBottomNavigation(navController, items, currentRoute)
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.DASHBOARD,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(Routes.DASHBOARD) {
                DashboardScreen(
                    onOpenRules = { navController.navigate(Routes.RULES) },
                    onOpenLogs = { navController.navigate(Routes.LOGS) },
                    onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                    onOpenRemoteAssist = { navController.navigate(Routes.REMOTE_ASSIST) },
                )
            }
            composable(Routes.RULES) {
                RulesScreen(
                    onAddRule = { navController.navigate(Routes.editor(0)) },
                    onEditRule = { navController.navigate(Routes.editor(it)) },
                    onViewLogs = { navController.navigate(Routes.LOGS) },
                )
            }
            composable(Routes.LOGS) { LogsScreen() }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    onLanguageChange = onLanguageChange,
                    onOpenAbout = { navController.navigate(Routes.ABOUT) },
                )
            }
            composable(Routes.ABOUT) { AboutScreen() }
            composable(Routes.REMOTE_ASSIST) {
                RemoteAssistScreen(
                    joinInput = remoteJoinInput,
                    activityMessage = remoteActivityMessage,
                    onStartShare = onStartRemoteShare,
                    onServiceAction = onRemoteServiceAction,
                )
            }
            composable(
                route = Routes.RULE_EDITOR,
                arguments = listOf(navArgument("ruleId") {
                    type = NavType.LongType
                    defaultValue = 0L
                }),
            ) {
                RuleEditorScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}

@Composable
private fun AppBottomNavigation(
    navController: NavHostController,
    items: List<NavigationItem>,
    currentRoute: String?,
) {
    NavigationBar {
        items.forEach { item ->
            NavigationBarItem(
                selected = currentRoute == item.route,
                onClick = {
                    navController.navigate(item.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { Icon(item.icon, contentDescription = stringResource(item.label)) },
                label = { Text(stringResource(item.label)) },
            )
        }
    }
}
