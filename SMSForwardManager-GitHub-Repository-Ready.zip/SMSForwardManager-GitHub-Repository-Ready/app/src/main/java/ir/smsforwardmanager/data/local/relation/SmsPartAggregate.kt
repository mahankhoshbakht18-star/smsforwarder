package ir.smsforwardmanager.data.local.relation

data class SmsPartAggregate(
    val totalParts: Int,
    val sentParts: Int,
    val failedSentParts: Int,
    val deliveredParts: Int,
    val failedDeliveryParts: Int,
    val unknownDeliveryParts: Int,
    val pendingDeliveryParts: Int,
)
