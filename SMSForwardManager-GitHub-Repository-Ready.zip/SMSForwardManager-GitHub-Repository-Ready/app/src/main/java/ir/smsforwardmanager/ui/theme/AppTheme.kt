package ir.smsforwardmanager.ui.theme

import android.os.Build
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import ir.smsforwardmanager.core.model.ThemeMode

private val LightColors = lightColorScheme(
    primary = Color(0xFF008F86),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB8F3EC),
    onPrimaryContainer = Color(0xFF00201E),
    secondary = Color(0xFF216A65),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFC7EEE9),
    onSecondaryContainer = Color(0xFF08201E),
    tertiary = Color(0xFF3F6381),
    tertiaryContainer = Color(0xFFD2E7FF),
    background = Color(0xFFF3FCFA),
    onBackground = Color(0xFF16201F),
    surface = Color(0xFFFAFFFE),
    onSurface = Color(0xFF16201F),
    surfaceVariant = Color(0xFFD8E8E5),
    onSurfaceVariant = Color(0xFF3E4947),
    outline = Color(0xFF6F7977),
    outlineVariant = Color(0xFFBEC9C7),
    error = Color(0xFFBA1A1A),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF63DAD1),
    onPrimary = Color(0xFF003734),
    primaryContainer = Color(0xFF00504B),
    onPrimaryContainer = Color(0xFF9CF2EA),
    secondary = Color(0xFFA9D7D2),
    onSecondary = Color(0xFF0B3733),
    secondaryContainer = Color(0xFF234E4A),
    onSecondaryContainer = Color(0xFFC5F3ED),
    tertiary = Color(0xFFA7C9EA),
    tertiaryContainer = Color(0xFF294B67),
    background = Color(0xFF091513),
    onBackground = Color(0xFFDCE5E3),
    surface = Color(0xFF0E1917),
    onSurface = Color(0xFFDCE5E3),
    surfaceVariant = Color(0xFF3F4947),
    onSurfaceVariant = Color(0xFFBEC9C6),
    outline = Color(0xFF899390),
    outlineVariant = Color(0xFF3F4947),
    error = Color(0xFFFFB4AB),
)

private val BrandShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun SmsForwardManagerTheme(
    themeMode: ThemeMode,
    dynamicColor: Boolean,
    content: @Composable () -> Unit,
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current
    val colors = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colors,
        shapes = BrandShapes,
        typography = MaterialTheme.typography,
        content = content,
    )
}
