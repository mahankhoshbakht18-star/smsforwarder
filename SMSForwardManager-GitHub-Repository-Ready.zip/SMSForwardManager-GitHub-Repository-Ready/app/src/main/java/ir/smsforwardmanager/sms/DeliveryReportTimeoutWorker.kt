package ir.smsforwardmanager.sms

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

@HiltWorker
class DeliveryReportTimeoutWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val tracker: SmsDeliveryTracker,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val attemptId = inputData.getLong(KEY_ATTEMPT_ID, -1L)
        if (attemptId <= 0) return Result.failure()
        tracker.markTimedOut(attemptId)
        return Result.success()
    }

    companion object {
        const val KEY_ATTEMPT_ID = "attempt_id"
    }
}
