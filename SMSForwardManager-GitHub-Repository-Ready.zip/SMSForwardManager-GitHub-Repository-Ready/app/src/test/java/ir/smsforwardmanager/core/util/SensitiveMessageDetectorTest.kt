package ir.smsforwardmanager.core.util

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SensitiveMessageDetectorTest {
    @Test
    fun detectsPersianLoginCode() {
        assertTrue(SensitiveMessageDetector.isSensitive("پنجره ملی خدمات دولت کد ورود 20409"))
    }

    @Test
    fun detectsEnglishOtp() {
        assertTrue(SensitiveMessageDetector.isSensitive("Your OTP is 381044"))
    }

    @Test
    fun doesNotBlockOrdinaryNumbers() {
        assertFalse(SensitiveMessageDetector.isSensitive("Meeting starts at 1405/04/20"))
    }
}
