package ir.smsforwardmanager.network

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SecureEndpointValidatorTest {
    @Test
    fun acceptsPublicHttpsEndpoint() {
        assertTrue(SecureEndpointValidator.isValid("https://example.com/api/v1/messages/forward"))
    }

    @Test
    fun rejectsClearTextAndLocalAddresses() {
        assertFalse(SecureEndpointValidator.isValid("http://example.com/api"))
        assertFalse(SecureEndpointValidator.isValid("https://localhost/api"))
        assertFalse(SecureEndpointValidator.isValid("https://127.0.0.1/api"))
        assertFalse(SecureEndpointValidator.isValid("https://192.168.1.10/api"))
    }
}
