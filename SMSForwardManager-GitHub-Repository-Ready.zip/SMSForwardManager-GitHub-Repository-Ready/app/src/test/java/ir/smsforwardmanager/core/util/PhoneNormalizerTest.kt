package ir.smsforwardmanager.core.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneNormalizerTest {
    @Test
    fun `normalizes Iranian mobile numbers and Persian digits`() {
        assertEquals("+989121234567", PhoneNormalizer.normalizePhoneNumber("۰۹۱۲ ۱۲۳ ۴۵۶۷"))
        assertEquals("+989121234567", PhoneNormalizer.normalizePhoneNumber("0098-912-123-4567"))
    }

    @Test
    fun `keeps alphanumeric sender IDs comparable`() {
        assertEquals("mymedu", PhoneNormalizer.normalizeSender(" My Medu "))
    }

    @Test
    fun `validates destination length`() {
        assertTrue(PhoneNormalizer.isPlausibleDestination("09121234567"))
        assertFalse(PhoneNormalizer.isPlausibleDestination("123"))
    }
}
