package ir.smsforwardmanager.network

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MahanBotEndpointValidatorTest {
    @Test
    fun normalizesPrivateLanBaseAddressInDebug() {
        assertEquals(
            "http://192.168.1.10:8010/api/v1/sms/otp",
            MahanBotEndpointValidator.normalize("http://192.168.1.10:8010"),
        )
    }

    @Test
    fun doesNotDuplicateOtpPath() {
        assertEquals(
            "http://10.0.0.5:8010/api/v1/sms/otp",
            MahanBotEndpointValidator.normalize("http://10.0.0.5:8010/api/v1/sms/otp/"),
        )
        assertEquals(
            "http://10.0.0.5:8010/api/v1/sms/otp/status",
            MahanBotEndpointValidator.statusUrl("http://10.0.0.5:8010"),
        )
    }

    @Test
    fun acceptsHttpsAndRejectsCredentialsOrPublicHttp() {
        assertTrue(MahanBotEndpointValidator.isValid("https://bot.example.com"))
        assertFalse(MahanBotEndpointValidator.isValid("http://example.com"))
        assertNull(MahanBotEndpointValidator.normalize("https://user:pass@bot.example.com"))
    }
}
