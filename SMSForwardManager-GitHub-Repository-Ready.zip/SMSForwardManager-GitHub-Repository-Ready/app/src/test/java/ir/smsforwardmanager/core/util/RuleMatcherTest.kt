package ir.smsforwardmanager.core.util

import ir.smsforwardmanager.core.model.KeywordLogic
import ir.smsforwardmanager.core.model.MatchMode
import ir.smsforwardmanager.data.local.entity.RuleEntity
import ir.smsforwardmanager.data.local.entity.RuleKeywordEntity
import ir.smsforwardmanager.data.local.relation.RuleWithDetails
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class RuleMatcherTest {
    @Test
    fun `matches normalized sender and any keyword`() {
        val rule = details(
            sender = "09121234567",
            senderMode = MatchMode.EXACT,
            keywords = listOf("کد ورود", "مدرسه"),
            keywordLogic = KeywordLogic.ANY,
        )
        assertTrue(RuleMatcher.matches(rule, "+98 912 123 4567", "کد ورود شما 1234 است"))
        assertFalse(RuleMatcher.matches(rule, "09120000000", "کد ورود شما 1234 است"))
    }

    @Test
    fun `all keyword logic requires every keyword`() {
        val rule = details(
            sender = null,
            senderMode = MatchMode.EXACT,
            keywords = listOf("school", "code"),
            keywordLogic = KeywordLogic.ALL,
        )
        assertTrue(RuleMatcher.matches(rule, "Portal", "Your SCHOOL code is 1234"))
        assertFalse(RuleMatcher.matches(rule, "Portal", "Your code is 1234"))
    }


    @Test
    fun `blocked phrase prevents a match`() {
        val base = details(
            sender = null,
            senderMode = MatchMode.EXACT,
            keywords = listOf("code"),
        )
        val rule = base.copy(rule = base.rule.copy(excludedKeywords = listOf("do not forward")))
        assertFalse(RuleMatcher.matches(rule, "Portal", "code 1234 - do not forward"))
        assertTrue(RuleMatcher.matches(rule, "Portal", "code 1234"))
    }

    @Test
    fun `schedule supports selected day and overnight range`() {
        val calendar = Calendar.getInstance().apply {
            set(2026, Calendar.JULY, 12, 23, 30, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val dayBit = 1 shl (calendar.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY)
        val base = details(
            sender = null,
            senderMode = MatchMode.EXACT,
            keywords = listOf("code"),
        )
        val scheduled = base.copy(
            rule = base.rule.copy(
                activeDaysMask = dayBit,
                activeStartMinute = 22 * 60,
                activeEndMinute = 6 * 60,
            ),
        )
        assertTrue(RuleMatcher.matches(scheduled, "Portal", "code 1234", calendar.timeInMillis))

        calendar.add(Calendar.DAY_OF_MONTH, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 12)
        assertFalse(RuleMatcher.matches(scheduled, "Portal", "code 1234", calendar.timeInMillis))
    }

    @Test
    fun `disabled rule never matches`() {
        val rule = details(null, MatchMode.EXACT, listOf("code"), isEnabled = false)
        assertFalse(RuleMatcher.matches(rule, "Portal", "code 1234"))
    }

    private fun details(
        sender: String?,
        senderMode: MatchMode,
        keywords: List<String>,
        keywordLogic: KeywordLogic = KeywordLogic.ANY,
        isEnabled: Boolean = true,
    ): RuleWithDetails {
        val rule = RuleEntity(
            id = 1,
            name = "Test",
            isEnabled = isEnabled,
            senderPattern = sender,
            senderMatchMode = senderMode,
            keywordMatchMode = MatchMode.CONTAINS,
            keywordLogic = keywordLogic,
        )
        return RuleWithDetails(
            rule = rule,
            keywords = keywords.mapIndexed { index, keyword ->
                RuleKeywordEntity(id = index + 1L, ruleId = 1, value = keyword, sortOrder = index)
            },
            destinationLinks = emptyList(),
        )
    }
}
