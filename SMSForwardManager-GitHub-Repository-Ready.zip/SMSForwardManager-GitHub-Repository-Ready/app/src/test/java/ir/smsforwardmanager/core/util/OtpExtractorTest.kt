package ir.smsforwardmanager.core.util

import ir.smsforwardmanager.data.local.entity.AppSettingsEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OtpExtractorTest {
    @Test
    fun `extracts standalone OTP and converts Persian digits`() {
        assertEquals(
            "483921",
            OtpExtractor.extract("کد ورود شما ۴۸۳۹۲۱ است", AppSettingsEntity.DEFAULT_OTP_REGEX),
        )
    }

    @Test
    fun `returns first capture group for custom pattern`() {
        assertEquals("7788", OtpExtractor.extract("Code: 7788", "Code:\\s*(\\d{4})"))
    }

    @Test
    fun `invalid pattern is rejected safely`() {
        assertNull(OtpExtractor.extract("1234", "["))
        assertTrue(OtpExtractor.isValidPattern("\\d{4}"))
    }
}
