package ir.smsforwardmanager.core.util

import org.junit.Assert.assertEquals
import org.junit.Test

class SensitiveMessageMaskerTest {
    @Test
    fun masksFourToEightDigitCodes() {
        assertEquals("Your code is •••••", SensitiveMessageMasker.mask("Your code is 20409"))
        assertEquals("شناسه 123 باقی می‌ماند", SensitiveMessageMasker.mask("شناسه 123 باقی می‌ماند"))
    }

    @Test
    fun doesNotSplitLongNumbers() {
        assertEquals("09157835288", SensitiveMessageMasker.mask("09157835288"))
    }
}
