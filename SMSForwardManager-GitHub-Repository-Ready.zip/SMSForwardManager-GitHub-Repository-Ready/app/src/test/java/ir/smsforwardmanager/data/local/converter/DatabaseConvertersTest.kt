package ir.smsforwardmanager.data.local.converter

import ir.smsforwardmanager.core.model.ForwardMode
import ir.smsforwardmanager.core.model.ForwardStatus
import ir.smsforwardmanager.core.model.KeywordLogic
import ir.smsforwardmanager.core.model.MatchMode
import ir.smsforwardmanager.core.model.MessageProcessingState
import ir.smsforwardmanager.core.model.RuleDeliveryMode
import ir.smsforwardmanager.core.model.ThemeMode
import org.junit.Assert.assertEquals
import org.junit.Test

class DatabaseConvertersTest {
    private val converters = DatabaseConverters()

    @Test
    fun `enum converters round trip known values`() {
        assertEquals(MatchMode.EXACT, converters.toMatchMode(converters.fromMatchMode(MatchMode.EXACT)))
        assertEquals(KeywordLogic.ALL, converters.toKeywordLogic(converters.fromKeywordLogic(KeywordLogic.ALL)))
        assertEquals(
            ForwardMode.EXTRACT_OTP,
            converters.toForwardMode(converters.fromForwardMode(ForwardMode.EXTRACT_OTP)),
        )
        assertEquals(
            MessageProcessingState.COMPLETED,
            converters.toMessageProcessingState(
                converters.fromMessageProcessingState(MessageProcessingState.COMPLETED),
            ),
        )
        assertEquals(
            ForwardStatus.DELIVERED,
            converters.toForwardStatus(converters.fromForwardStatus(ForwardStatus.DELIVERED)),
        )
        assertEquals(ThemeMode.DARK, converters.toThemeMode(converters.fromThemeMode(ThemeMode.DARK)))
        assertEquals(
            RuleDeliveryMode.SMS_THEN_INTERNET,
            converters.toRuleDeliveryMode(
                converters.fromRuleDeliveryMode(RuleDeliveryMode.SMS_THEN_INTERNET),
            ),
        )
        assertEquals(
            listOf("one", "دو"),
            converters.toStringList(converters.fromStringList(listOf("one", "دو"))),
        )
    }

    @Test
    fun `unknown persisted values fall back safely`() {
        assertEquals(MatchMode.CONTAINS, converters.toMatchMode("UNKNOWN"))
        assertEquals(ForwardStatus.PENDING, converters.toForwardStatus("UNKNOWN"))
        assertEquals(ThemeMode.SYSTEM, converters.toThemeMode("UNKNOWN"))
    }
}

