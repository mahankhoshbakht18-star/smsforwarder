# Room, Hilt and Compose ship their required consumer rules.
# Keep enum values because they are serialized into the local Room database.
-keepclassmembers enum ir.smsforwardmanager.core.model.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

